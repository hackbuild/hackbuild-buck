# BUCK bench v3.1

A talking white-tail trophy you print, wire and hang on pegboard. One HTML file: open `buck.html` from disk (it works offline), shape the head, check the fit audit, and export 3MF plates.

## What's printed and what isn't

You buy: an SG90 or MG90S servo, a controller (ESP32-S3 SuperMini, Waveshare RP2040-Zero, S3-Zero, XIAO S3, QT Py S3, or a custom size), the NULLLAB NS4168 I2S amp and 3W speaker kit, a USB-C cable and hookup wire. Screws: the servo's own two, two M3 x 6 with washers for the amp, two M2 x 6 self tappers (or #2 x 1/4 in) for the speaker ears, three M3 x 16 flat head screws (or #4 x 5/8 in flat head wood screws) to hold the head to the plaque. The horn screw is optional.

## The kit, and where the numbers come from

| part | numbers | source |
|---|---|---|
| NS4168 amp | 38.4 x 22.4 x 1.6, two 4.7 mm holes 16.0 apart on one line 15.2 from the input end, 3.2 in from each long edge | NULLLAB CAD drawing (github.com/nulllaborg/i2s_audio_amplifier_module) |
| NS4168 parts | 5 pin PH2.0 input on one end; speaker PH2.0 and a 2 way screw terminal on the other | vendor photo; heights assumed: 10 mm for the terminal, 6 mm for the PH housings, 2 mm of pins under the board |
| 3W speaker | 30 mm square frame, ears 39 mm apart, 2.2 mm ear holes, 7.5 mm deep, 20.8 mm cone, dome 2 mm proud | taken off the listing photo, never calipered. All six are sliders under SPEAKER |

Measure your speaker's frame, ear spacing and depth before printing the mount; the seat, bosses, shelf and grille follow the sliders.

Everything else is printed, and every part is a single material. Print each part in its own filament, or print everything in one colour and paint it using the paint view as your guide.

| part | qty | prints | default filament |
|---|---|---|---|
| head | 1 | neck rim on the bed | brown |
| jaw | 1 | mouth face on the bed; shelled and channelled like a real lower jaw, the trough floor tented to an 8 mm bridge, no support | brown |
| ears | 2 | lying on their flat back, cup up (the back is flat with a steep bevel to the rim) | brown |
| antlers | 2 | flat side down (round on top, 45 degrees underneath) | bone |
| eyes | 2 | flat back down, dome up | black |
| nose cap | 1 | cut face down | black |
| mount (plaque, fin, controller plinth, speaker seat, amp shelf, lip) | 1 | flat back down | walnut |
| pivot pin | 1 | on its flat | walnut |
| pegboard hooks | 2 | on their side | walnut |

Nothing needs supports. Parts are nested on their real footprints: in one colour mode the whole kit fits on one 256 x 256 bed at the default size. Overhangs that are left are a few small 45 to 60 degree patches: under the brow hoods, the backs of the pedicles and the ear roots, and the bridges over the hook channel and the cable groove.

## How it goes together

1. Press the eyes into their sockets, pointed corner toward the nose, then press the nose cap onto the muzzle peg.
2. Press the ears and antlers into their keyed sockets.
3. Screw the servo to the fin with its own two screws, gear tower toward the right cheek. Leave the horn off for now.
4. Slide the speaker in under the amp shelf from the right side (the servo horn side), face down: lift it over the seat ring, push it back against the stop by the plaque, drop it, and screw both ears down through the holes in the shelf.
5. Slide the NS4168 in from the same side, components up, input connector leading. Drop it onto the two spigots and screw it down with two M3 x 6 and washers, then plug in the speaker lead. The screwdriver goes straight down beside the fin.
6. Stick the controller onto the plinth on the left face of the fin with foam tape or hot glue, USB toward the plaque. The plinth is 9 mm wide, narrower than the pin rows, so every pin and edge pad stays free. Wire everything and tuck the leads through the slot in the fin.
7. Feed the USB-C cable through the plaque slot into the controller and lay it in the groove on the back.
8. Slide the head over the fin onto the locating lip, then drive the three M3 x 16 flat head screws in from the back of the plaque until they sit flush in their countersinks. To take the head off later, slide the plaque off its hooks and undo the three screws.
9. Drive the servo to its closed angle. Reach in through the mouth and press the horn onto the spline, pointing forward and down.
10. Slide the jaw up and back through the mouth so its right arm takes the horn. Push the pivot pin in through the left cheek until it clicks.
11. Roll the two printed hooks into the pegboard a whole number of inches apart (4 by default): hold each one tilted up, put the tip in a hole and roll it down. Then slide the plaque's back channel onto both hooks from the side. The head's weight winds the hooks tighter.

Suggested wiring on an S3: servo signal to GPIO 7, amp BCLK to GPIO 5, LRCLK to GPIO 6 and DIN to GPIO 4. On the RP2040-Zero: servo GP2, BCLK GP6, LRCLK GP7 (PIO I2S wants it right after BCLK), DIN GP8. The amp input is the kit's 5 pin lead: G, V, BCLK, LRCLK, DIN. The servo and the amp both run on 5 V from USB. The speaker output is bridge tied: never tie either leg to GND.

## Fits and dimensions

| what | value |
|---|---|
| servo window in the fin | body + 0.3 per side; pilot holes 1.7 mm for the servo's 2 mm screws |
| horn groove in the jaw arm | horn outline + 0.3, with 0.7 mm of slack across for clone servos |
| pivot pin | 4.0 mm with print flats; cheek hole 4.1 (snug once printed), jaw bore 4.5; slit tip with a 4.9 mm barb that clicks behind the arm |
| eyes | almond pocket 2.6 mm deep; clearance is set per side, default 0.10 |
| nose | 5.0 mm peg, 4.0 deep; socket clearance 0.15 per side |
| ears, antlers | keyed tenons, 0.20 per side |
| head to mount | locating lip 4.5 mm deep with a 0.5 mm gap takes all the shear; 3 x M3 x 16 flat head screws from the back (one top centre, two low either side of the grille) clamp the rim to the plaque. 3.5 mm clearance holes, 90 degree countersinks printed on the bed side, 9.2 mm bosses inside the rim with 2.5 mm pilots 11 mm deep. The old snap beads are still an option |
| plaque size | sized off the neck: the neck takes 62 percent of the plaque width by default (neck fill slider), with the top, sides and point following from that. The default is 158 x 196 mm |
| jaw | channelled by default: a 2.2 mm skin opened through the mouth face as a U trough, with the lip rim 1 mm thicker over its last 3 mm and the tongue groove down the middle; about 47 percent less plastic than solid. The hinge, arms, horn groove and pin bore stay solid. Sealed (closed void under a solid mouth face) and solid are options |
| pegboard hooks | 1/4 in board: 4.6 mm octagonal prong (5.28 across corners) for 6.35 mm holes; 1/8 in board: 3.4 mm prong for 4.76 mm holes; the prong is a 12 mm radius arc |
| hook channel | dovetail, 4.2 deep, 0.15 per side |
| controller plinth | 9 mm wide, 3.6 mm tall, 45 degree underside; leaves the pin rows (15.24 apart) and edge pads open; notched where the screwdriver passes |
| amp posts | 6.8 mm teardrop posts, 3.5 mm tall; spigot 4.4 mm (flat underside so it prints lying down) in the 4.7 mm holes; 2.5 mm pilot for M3, 6.2 mm deep |
| amp shelf | 2 mm plate 3 mm above the speaker's back (room to lift the speaker over its seat ring) |
| speaker seat | ring 2.6 mm tall (dome + 0.6) under the flange, stop wall at the plaque, two ear bosses with 1.7 mm pilots for M2, 6.6 mm deep |

## What the audit checks on every build

- the jaw at closed, half and full swing clears the head, fin, servo and pin
- the jaw slides in along its path onto the horn, and the horn sits in its groove
- the pin is snug in the cheek and free in the jaw arm, and its barb stops short of the servo
- the eye pockets are blind, and the eyes, nose, ears and antlers seat without overlap
- the speaker sits on its seat and ears, and comes out sideways (lift, back off past the lip, slide right) without touching the mount
- the NS4168 sits on its posts and comes out the same way; a screwdriver reaches all four screws straight down
- the controller clears the servo, the amp and the USB plug's path, and its plinth stands on solid fin
- the head slides straight onto the mount past the fin, boards, speaker and servo, including its screw bosses
- the three head screws clear every part inside, their bosses keep plastic all round the pilot, and the top screw stays clear of the hook channel
- the jaw's shell keeps its full wall everywhere, and no thin slivers are left between the keep-outs
- a search over angle and position shows the hook can roll into a hole, and that a straight pull cannot draw it back out

Every exported 3MF was run through `validate_3mf.py` (watertight after vertex merge, no non-manifold vertices, Orca dialect settings) across a parameter sweep.

## What only you can check

- The slicer round trip: does the filament list import as expected in your slicer?
- Your servo's flange height and horn length. Clones vary, and the groove allows 0.7 mm across.
- Your speaker. Frame, ear span and depth are from a photo. Caliper them.
- The NS4168's screw terminal height, which the drawing does not give. 10 mm is allowed.
- The real pegboard. Hardboard thickness varies; the hooks assume 6.35 mm for 1/4 in board and 3.2 mm for 1/8 in board.

## Source

| file | what it does |
|---|---|
| `src/sdf.js` | the sculpt, the antler and ear fields, and the paint map |
| `src/engine.js` | every part, the fit audit and the hook planner |
| `src/app.js` | bench UI, viewer, jaw sim, plates and exports |
| `src/shell.html` | the hack.build app shell |
| `build.py` | assembles `buck.html` with three r128, JSZip, manifold-3d 3.5.4 (Apache-2.0) and the fonts inlined |
| `dev/` | node sweeps, the overhang audit and the headless smoke test |
