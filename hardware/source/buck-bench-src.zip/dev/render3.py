import json, numpy as np, sys, matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
d=json.load(open('/tmp/claude-0/dump.json'))
col={'mount':'#7a5236','hw_servo':'#2f5fbf','hw_horn':'#eeeeee','hw_esp':'#1f9a4a','hw_amp':'#202020','hw_speaker':'#888888','hw_usb':'#aaaaaa'}
views=[(20,-60),(15,30),(70,-90),(5,-90)]
fig=plt.figure(figsize=(16,13))
L=np.array([0.4,-0.6,0.7]); L/=np.linalg.norm(L)
for vi,(el,az) in enumerate(views):
    ax=fig.add_subplot(2,2,vi+1,projection='3d')
    for k,c in col.items():
        if k not in d: continue
        P=np.array(d[k]['p']).reshape(-1,3); I=np.array(d[k]['i']).reshape(-1,3)
        tri=P[I]
        if k=='mount':
            m=(tri[:,:,1].max(1)>-0.3)  # inside part only
            tri=tri[m]
        n=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]); n/= (np.linalg.norm(n,axis=1,keepdims=True)+1e-9)
        sh=0.45+0.55*np.abs(n@L)
        base=np.array(matplotlib.colors.to_rgb(c))
        fc=np.clip(base[None,:]*sh[:,None],0,1)
        pc=Poly3DCollection(tri,facecolors=fc,edgecolors='none',linewidths=0)
        ax.add_collection3d(pc)
    ax.set_xlim(-40,40); ax.set_ylim(-5,75); ax.set_zlim(-35,45)
    ax.set_box_aspect((80,80,80)); ax.view_init(el,az); ax.set_xlabel('x'); ax.set_ylabel('y'); ax.set_zlabel('z')
plt.tight_layout(); plt.savefig(sys.argv[1] if len(sys.argv)>1 else '/tmp/claude-0/guts.png',dpi=70)
