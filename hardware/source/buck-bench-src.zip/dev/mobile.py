import asyncio
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(args=['--use-gl=swiftshader','--enable-webgl','--ignore-gpu-blocklist'])
        pg = await b.new_page(viewport={'width':390,'height':844}); pg.set_default_timeout(400000)
        errs=[]; pg.on('pageerror', lambda e: errs.append(str(e)))
        await pg.goto('file:///home/claude/deer/out/buck.html')
        await pg.wait_for_function('globalThis.BENCH && BENCH.ready', timeout=400000)
        await pg.evaluate("document.querySelector('#welcome').classList.add('hide')")
        print('sw390', await pg.evaluate('document.documentElement.scrollWidth'))
        await pg.screenshot(path='/tmp/claude-0/m390.png')
        await pg.click('#steps button[data-step="3"]')
        await pg.click('#printMode .chip[data-v="single"]'); await pg.wait_for_timeout(1500)
        print('plates single', await pg.evaluate('BENCH.view.plates().map(p=>p.label+":"+p.items.length)'))
        await pg.set_viewport_size({'width':768,'height':900}); await pg.wait_for_timeout(400)
        print('sw768', await pg.evaluate('document.documentElement.scrollWidth'))
        print('errs', errs)
        await b.close()
asyncio.run(main())
