import Module from '/home/claude/deer/node_modules/manifold-3d/manifold.js';
import fs from 'fs'; import { createRequire } from 'module';
const require = createRequire(import.meta.url); const JSZip = require('jszip');
eval(fs.readFileSync('/home/claude/deer/src/sdf.js','utf8'));
eval(fs.readFileSync('/home/claude/deer/src/engine.js','utf8'));
eval(fs.readFileSync('/mnt/skills/plugins/print-forge/assets/orca3mf.js','utf8'));
const M=await Module(); M.setup();
const st=globalThis.BUCK.defaults();
const over=process.argv[2]?JSON.parse(process.argv[2]):{};
for (const k in over) Object.assign(st[k],over[k]);
const r=globalThis.BUCK.build(M,st,{});
console.log('ms',r.info.ms,'errs',r.errs,'warns',r.warns);
let x=10; const objs=[];
for (const o of r.objects){ objs.push({name:o.name,positions:[[x+o.size[0]/2, 150, 0]],parts:o.parts.map(p=>({name:p.name,slot:p.slot,positions:p.print.positions,indices:p.print.indices}))}); x+=o.size[0]+5; }
const pkg=globalThis.Orca3MF.build({filaments:st.slots,objects:objs,title:'test'});
fs.writeFileSync(process.argv[3]||'/tmp/claude-0/test.3mf', await pkg.zip(JSZip,'nodebuffer'));
