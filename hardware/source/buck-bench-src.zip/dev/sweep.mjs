import Module from '/home/claude/deer/node_modules/manifold-3d/manifold.js';
import fs from 'fs'; import { createRequire } from 'module'; import { execSync } from 'child_process';
const require = createRequire(import.meta.url); const JSZip = require('jszip');
eval(fs.readFileSync('/home/claude/deer/src/sdf.js','utf8'));
eval(fs.readFileSync('/home/claude/deer/src/engine.js','utf8'));
eval(fs.readFileSync('/mnt/skills/plugins/print-forge/assets/orca3mf.js','utf8'));
const M=await Module(); M.setup();
const V=JSON.parse(fs.readFileSync(process.argv[2],'utf8'));
const sig=r=>r.objects.map(o=>o.parts.map(p=>p.print.tris+':'+p.print.volume.toFixed(1)).join(',')).join('|');
const base=globalThis.BUCK.build(M,globalThis.BUCK.defaults(),{}); const s0=sig(base);
for (const [name,over] of V){
  const st=globalThis.BUCK.defaults();
  for (const k in over){ if (typeof over[k]==='object') Object.assign(st[k],over[k]); else st[k]=over[k]; }
  let r; try { r=globalThis.BUCK.build(M,st,{}); } catch(e){ console.log(name,'THREW',e.message); continue; }
  const bad=r.checks.filter(c=>!c.ok).map(c=>c.k+'='+c.v.toFixed(2)+(c.by?JSON.stringify(c.by):''));
  let x=10; const objs=[];
  for (const o of r.objects){ objs.push({name:o.name,positions:[[x+o.size[0]/2,150,0]],parts:o.parts.map(p=>({name:p.name,slot:p.slot,positions:p.print.positions,indices:p.print.indices}))}); x+=o.size[0]+5; }
  fs.writeFileSync('/tmp/claude-0/sw.3mf', await globalThis.Orca3MF.build({filaments:st.slots,objects:objs,title:'t'}).zip(JSZip,'nodebuffer'));
  let v=''; try { execSync('python3 /mnt/skills/plugins/print-forge/scripts/validate_3mf.py /tmp/claude-0/sw.3mf --overlap',{stdio:'pipe'}); v='3mf ok'; } catch(e){ v='3MF FAIL: '+e.stdout.toString().split('FAILURES')[1]?.trim().split('\n').slice(0,4).join(' ; '); }
  console.log(name.padEnd(18), r.info.ms+'ms', 'dead='+(sig(r)===s0), 'a='+r.info.a.toFixed(1), r.errs.join(';'), bad.join(';'), v);
}
