import Module from '/home/claude/deer/node_modules/manifold-3d/manifold.js';
import fs from 'fs';
eval(fs.readFileSync('/home/claude/deer/src/sdf.js', 'utf8'));
eval(fs.readFileSync('/home/claude/deer/src/engine.js', 'utf8'));
const M = await Module(); M.setup();
const st = globalThis.BUCK.defaults();
const over = process.argv[2] ? JSON.parse(process.argv[2]) : {};
for (const k in over) { if (typeof over[k] === 'object') Object.assign(st[k], over[k]); else st[k] = over[k]; }
const r = globalThis.BUCK.build(M, st, {});
const out = {};
const pick = (m) => ({ p: Array.from(m.positions), i: Array.from(m.indices) });
for (const o of r.objects) out[o.name.replace(' ', '_')] = pick(o.world);
for (const k in r.hardware) out['hw_' + k] = pick(r.hardware[k]);
fs.writeFileSync('/tmp/claude-0/dump.json', JSON.stringify(out));
console.log(Object.keys(out), r.errs, r.checks.filter(c => !c.ok).map(c => c.k));
