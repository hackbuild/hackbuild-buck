import asyncio, base64, os, sys
from playwright.async_api import async_playwright
OUT='/tmp/claude-0/smoke2'; os.makedirs(OUT, exist_ok=True)
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(args=['--use-gl=swiftshader','--enable-webgl','--ignore-gpu-blocklist'])
        pg = await b.new_page(viewport={'width':1400,'height':900}); pg.set_default_timeout(240000)
        errs=[]
        pg.on('console', lambda m: errs.append(m.type+': '+m.text) if m.type=='error' else None)
        pg.on('pageerror', lambda e: errs.append('pageerror: '+str(e)))
        await pg.goto('file:///home/claude/deer/out/buck.html')
        await pg.wait_for_function('globalThis.BENCH && BENCH.ready', timeout=180000)
        await pg.click('[data-preset=buck]'); await pg.wait_for_timeout(800)
        await pg.wait_for_function('!document.querySelector("#busy").classList.contains("on")', timeout=180000)
        await pg.wait_for_timeout(500)
        await pg.screenshot(path=OUT+'/1-head.png')
        print('checks', await pg.evaluate('JSON.stringify(BENCH.result().checks.map(c=>[c.k,c.ok]))'))
        print('errs', await pg.evaluate('JSON.stringify(BENCH.result().errs.concat(BENCH.result().warns))'))
        for i,step in enumerate([1,2,3]):
            await pg.click(f'#steps button[data-step="{step}"]'); await pg.wait_for_timeout(300)
            await pg.screenshot(path=OUT+f'/{2+i}-step{step}.png')
        await pg.click('[data-mode=print]'); await pg.wait_for_timeout(800); await pg.screenshot(path=OUT+'/5-print.png')
        await pg.click('#plNext'); await pg.wait_for_timeout(500); await pg.screenshot(path=OUT+'/5b-print.png')
        await pg.click('[data-mode=explode]'); await pg.wait_for_timeout(1500); await pg.screenshot(path=OUT+'/6-explode.png')
        await pg.click('[data-mode=assembled]'); await pg.click('[data-tog=xray]'); await pg.wait_for_timeout(800); await pg.screenshot(path=OUT+'/7-xray.png')
        await pg.click('[data-tog=xray]'); await pg.click('[data-tog=paint]'); await pg.wait_for_timeout(600); await pg.screenshot(path=OUT+'/8-filament.png')
        await pg.click('[data-tog=paint]')
        if len(sys.argv)>1:
            for kind,ext in [('3mf','zip'),('stl','zip'),('card','txt'),('paint','png'),('parts','zip')]:
                b64 = await pg.evaluate(f'BENCH.exportBytes("{kind}")')
                open(f'{OUT}/export-{kind}.{ext}','wb').write(base64.b64decode(b64))
        if len(sys.argv)>1:
            await pg.evaluate("BENCH.set('print.mode','single')"); await pg.wait_for_timeout(500)
            await pg.click('[data-mode=print]'); await pg.wait_for_timeout(3000); await pg.screenshot(path=OUT+'/9-single.png')
            b64 = await pg.evaluate('BENCH.exportBytes("3mf")')
            open(f'{OUT}/export-single3mf.3mf','wb').write(base64.b64decode(b64))
        print('\n'.join(errs[:20]))
        await b.close()
asyncio.run(main())
