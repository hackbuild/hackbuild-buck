import asyncio, base64, sys, json, os
from playwright.async_api import async_playwright
OUT='/tmp/claude-0/smoke'; os.makedirs(OUT, exist_ok=True)
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(args=['--use-gl=swiftshader','--enable-webgl','--ignore-gpu-blocklist'])
        pg = await b.new_page(viewport={'width':1400,'height':900})
        errs=[]
        pg.on('console', lambda m: errs.append(m.type+': '+m.text) if m.type in ('error','warning') else None)
        pg.on('pageerror', lambda e: errs.append('pageerror: '+str(e)))
        await pg.goto('file:///home/claude/deer/out/buck.html')
        await pg.wait_for_function('globalThis.BENCH && BENCH.ready', timeout=120000)
        await pg.screenshot(path=OUT+'/0-welcome.png')
        await pg.click('[data-preset=buck]')
        await pg.wait_for_timeout(500)
        await pg.wait_for_function('!document.querySelector("#busy").classList.contains("on")', timeout=60000)
        await pg.wait_for_timeout(400)
        await pg.screenshot(path=OUT+'/1-head.png')
        info = await pg.evaluate('JSON.stringify(BENCH.result().checks.map(c=>[c.k,c.ok,+c.v.toFixed(2)]))')
        print('checks', info)
        print('errs', await pg.evaluate('JSON.stringify(BENCH.result().errs.concat(BENCH.result().warns))'))
        for i,step in enumerate([1,2,3]):
            await pg.click(f'#steps button[data-step="{step}"]'); await pg.wait_for_timeout(300)
            await pg.screenshot(path=OUT+f'/{2+i}-step{step}.png')
        await pg.click('[data-mode=print]'); await pg.wait_for_timeout(600); await pg.screenshot(path=OUT+'/5-print.png')
        await pg.click('[data-mode=assembled]'); await pg.click('[data-tog=section]'); await pg.wait_for_timeout(600); await pg.screenshot(path=OUT+'/6-section.png')
        for kind in ['3mf','stl','card','parts']:
            b64 = await pg.evaluate(f'BENCH.exportBytes("{kind}")')
            ext={'3mf':'3mf','stl':'zip','card':'txt','parts':'zip'}[kind]
            open(f'{OUT}/export-{kind}.{ext}','wb').write(base64.b64decode(b64))
        print('\n'.join(errs[:20]))
        await b.close()
asyncio.run(main())
