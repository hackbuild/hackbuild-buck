import Module from '/home/claude/deer/node_modules/manifold-3d/manifold.js';
import fs from 'fs';
eval(fs.readFileSync('/home/claude/deer/src/sdf.js','utf8'));
const B=globalThis.BUCKSDF;
const M=await Module(); M.setup(); const {Manifold}=M;
const over=process.argv[2]?JSON.parse(process.argv[2]):{};
const sh=Object.assign({s:1.15,muzzle:1,neck:1,crown:1,cheek:1,tilt:12,eye:1,eyeMode:'sculpted',antler:'crown',antlerSize:1,spread:1,earSize:1},over);
const H=B.makeHead(sh); const S=sh.s, F=H.F;
const out=[];
const norm=v=>{const l=Math.hypot(...v);return v.map(a=>a/l)}; const cross=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];
const toW=p=>{ const [y,z]=H.headWorld(p[1],p[2]); return [p[0]*S,y*S,z*S]; };
const dirW=v=>{ const a=toW([0,0,0]), b=toW(v); return norm([b[0]-a[0],b[1]-a[1],b[2]-a[2]]); };
let t=Date.now();
const m=Manifold.levelSet(p=>-H.d(p[0],p[1],p[2]),{min:[-60,-3,-75],max:[60,170,75]},+(process.argv[3]||1.0),0).simplify(0.03);
{ const me=m.getMesh(),P=me.vertProperties,np=me.numProp,pos=[],vc=[]; for(let i=0;i<P.length/np;i++){const x=P[i*np],y=P[i*np+1],z=P[i*np+2];pos.push(x,y,z);vc.push(...B.paintHead(H,x,y,z));} out.push({p:pos,i:Array.from(me.triVerts),vc}); }
console.log('head ms',Date.now()-t);
// antlers
const sk=B.antlerSkel(sh.antler), k=S*sh.antlerSize;
const burr=B.antlerBurr(sk.strokes[0][0][2]);
const strokes=sk.strokes.concat(burr.strokes).map(L=>L.map(([u,v,r])=>[u*k,v*k,Math.max(1.1,r*Math.min(1.25,k))]));
const knobs=burr.knobs.map(([u,v,r])=>[u*k,v*k,r*Math.min(1.25,k)]);
const af=B.antlerField(strokes,knobs);
t=Date.now();
const am=Manifold.levelSet(p=>-af(p[0],p[1],p[2]),{min:[-20*k,-2,-0.5],max:[35*k,65*k,12]},0.45,0);
console.log('antler ms',Date.now()-t,am.numTri());
const zc=0.62*strokes[0][0][2];
for (const sg of [1,-1]){
  const o=toW([sg*F.pedicle[0],F.pedicle[1],F.pedicle[2]]);
  let V=dirW([sg*(F.pedicleDir[0]+0.25*(sh.spread-1)),F.pedicleDir[1],F.pedicleDir[2]]);
  V=norm([V[0]+sg*0.35*sh.spread,V[1],V[2]]);
  let U=dirW([-sg*0.42,1,0.1]); U=norm(U.map((u,i)=>u-V[i]*(U[0]*V[0]+U[1]*V[1]+U[2]*V[2])));
  let W=cross(U,V); if (W[0]*sg<0) W=W.map(a=>-a);
  const me=am.getMesh(),P=me.vertProperties,np=me.numProp,pos=[],vc=[];
  for(let i=0;i<P.length/np;i++){const u=P[i*np],v=P[i*np+1],z=P[i*np+2]-zc; for(let c=0;c<3;c++) pos.push(o[c]+U[c]*u+V[c]*v+W[c]*z); vc.push(...B.paintAntler(Math.max(0,v)/(sk.tip*k)));}
  const I=Array.from(me.triVerts); // keep winding: frame handedness
  const det=U[0]*(V[1]*W[2]-V[2]*W[1])-U[1]*(V[0]*W[2]-V[2]*W[0])+U[2]*(V[0]*W[1]-V[1]*W[0]);
  if(det<0) for(let i=0;i<I.length;i+=3){const a=I[i+1];I[i+1]=I[i+2];I[i+2]=a;}
  out.push({p:pos,i:I,vc});
}
// ears
const ke=S*sh.earSize, Le=47*ke, We=23*ke;
const ef=B.earField(Le,We,3.2*ke);
t=Date.now();
const em=Manifold.levelSet(p=>-ef(p[0],p[1],p[2]),{min:[-We/2-2,-1,-8*ke],max:[We/2+2,Le+1,4]},0.45,0);
console.log('ear ms',Date.now()-t,em.numTri());
for (const sg of [1,-1]){
  const o=toW([sg*F.earRoot[0],F.earRoot[1],F.earRoot[2]]);
  const V=dirW([sg*F.earDir[0],F.earDir[1],F.earDir[2]]);
  let Wf=dirW([sg*0.45,1,0.15]); Wf=norm(Wf.map((w,i)=>w-V[i]*(Wf[0]*V[0]+Wf[1]*V[1]+Wf[2]*V[2])));
  const U=cross(V,Wf);
  const me=em.getMesh(),P=me.vertProperties,np=me.numProp,pos=[],vc=[];
  for(let i=0;i<P.length/np;i++){const u=P[i*np],v=P[i*np+1],w=P[i*np+2]; for(let c=0;c<3;c++) pos.push(o[c]+U[c]*u+V[c]*v+Wf[c]*w); const hw=We/2; vc.push(...B.paintEar(u,v,w,hw,Le,w>-1.6*ke)); }
  const I=Array.from(me.triVerts);
  out.push({p:pos,i:I,vc});
}
fs.writeFileSync('/tmp/claude-0/m.json',JSON.stringify(out));
