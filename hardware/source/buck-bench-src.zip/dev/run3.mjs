import Module from '/home/claude/deer/node_modules/manifold-3d/manifold.js';
import fs from 'fs';
eval(fs.readFileSync('/home/claude/deer/src/sdf.js', 'utf8'));
eval(fs.readFileSync('/home/claude/deer/src/engine.js', 'utf8'));
const M = await Module(); M.setup(); globalThis.BUCK_DBG = 1;
const st = globalThis.BUCK.defaults();
const over = process.argv[2] ? JSON.parse(process.argv[2]) : {};
for (const k in over) { if (typeof over[k] === 'object') Object.assign(st[k], over[k]); else st[k] = over[k]; }
const r = globalThis.BUCK.build(M, st, {});
console.log('ms', r.info.ms, 'errs', r.errs, 'warns', r.warns);
for (const c of r.checks) console.log(c.ok ? ' ok ' : 'FAIL', c.k, (c.v || 0).toFixed(2), c.by ? JSON.stringify(c.by) : '', c.at ? JSON.stringify(c.at) : '');
const I = r.info; console.log('trayZ', I.trayZ, 'stack', JSON.stringify(I.stack), 'spY', I.spY, 'esp', I.esp, 'usb', I.usb);
console.log('TM', JSON.stringify(r.info.tm));
