// standalone hook insertion experiments
import Module from '/home/claude/deer/node_modules/manifold-3d/manifold.js';
const M=await Module(); M.setup(); const {CrossSection}=M;
const D2R=Math.PI/180;
function fixWind(pts){let a=0;for(let i=0;i<pts.length;i++){const p=pts[i],q=pts[(i+1)%pts.length];a+=p[0]*q[1]-q[0]*p[1];}return new CrossSection([a<0?pts.slice().reverse():pts],'Positive');}
const circ2=(r,x,y)=>CrossSection.circle(r,32).translate([x,y]);
function profile(P, tip, sh, round){
  const tb=P.board, sL=tb+0.7, D=4.2,w0=7,w1=10,cl=0.15;
  const tongue=fixWind([[0.1,-w0/2+cl],[D-cl,-w1/2+cl+0.1],[D-cl,w1/2-cl-0.1],[0.1,w0/2-cl]]);
  const stem=fixWind([[-sL,-sh/2],[0.3,-sh/2],[0.3,sh/2],[-sL,sh/2]]);
  const drop=fixWind([[-sL-sh,-sh/2-tip+(round?sh/2:0)],[-sL,-sh/2-tip+(round?sh/2:0)],[-sL,sh/2-0.01],[-sL-sh,sh/2-0.01]]);
  let p=tongue.add(stem).add(drop).add(circ2(sh/2,-sL-sh/2,0));
  if(round) p=p.add(circ2(sh/2,-sL-sh/2,-sh/2-tip+sh/2));
  return p;
}
function plan(prof,P,opt){
  const polys=prof.toPolygons(),pts=[];
  for(const poly of polys)for(let i=0;i<poly.length;i++){const A=poly[i],B=poly[(i+1)%poly.length];const n=Math.max(1,Math.ceil(Math.hypot(B[0]-A[0],B[1]-A[1])/0.25));for(let k=0;k<n;k++)pts.push([A[0]+(B[0]-A[0])*k/n,A[1]+(B[1]-A[1])*k/n]);}
  const tb=P.board,hr=P.hole/2-0.1;
  const AS=opt.as||2, A0=-120, NA=Math.round(240/AS)+1, RS=opt.rs||0.25, Y0=-16, NY=Math.round(46/RS), Z0=-16, NZ=Math.round(32/RS);
  const seen=new Uint8Array(NA*NY*NZ); const idx=(a,y,z)=>(a*NY+y)*NZ+z;
  const free=(ai,yi,zi)=>{const th=(A0+ai*AS)*D2R,c=Math.cos(th),s=Math.sin(th),ty=Y0+yi*RS,tz=Z0+zi*RS;for(const [y,z] of pts){const Y=y*c-z*s+ty;if(Y<-0.02&&Y>-tb+0.02){const Z=y*s+z*c+tz;if(Math.abs(Z)>hr)return false;}}return true;};
  const out=(ai,yi,zi)=>{const th=(A0+ai*AS)*D2R,c=Math.cos(th),s=Math.sin(th),ty=Y0+yi*RS;for(const [y,z] of pts)if(y*c-z*s+ty<0.2)return false;return true;};
  const a0=Math.round(-A0/AS),y0=Math.round(-Y0/RS),z0=Math.round(-Z0/RS);
  if(!free(a0,y0,z0)) return {ok:false,why:'seated collides'};
  const q=[idx(a0,y0,z0)];seen[q[0]]=1;let h=0, maxA=0;
  while(h<q.length){const id=q[h++],zi=id%NZ,yi=((id-zi)/NZ)%NY,ai=Math.floor(id/(NY*NZ)); maxA=Math.max(maxA,Math.abs(A0+ai*AS));
    if(out(ai,yi,zi))return{ok:true,angle:A0+ai*AS,states:h};
    for(const [da,dy,dz] of [[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]]){const na=ai+da,ny=yi+dy,nz=zi+dz;if(na<0||na>=NA||ny<0||ny>=NY||nz<0||nz>=NZ)continue;const ni=idx(na,ny,nz);if(seen[ni])continue;seen[ni]=1;if(free(na,ny,nz))q.push(ni);}}
  return {ok:false,states:q.length,maxA};
}
const PEG={'1/4':{hole:6.35,board:6.35},'1/8':{hole:4.76,board:3.2}};
if(0) for (const [bk,sh] of [["1/4",4.6],["1/8",3.4]]) for (const tip of [2.5,3.5,4.5,5.5]) for (const round of [false,true]) {
  const t=Date.now(); const r=plan(profile(PEG[bk],tip,sh,round),PEG[bk],{});
  console.log(bk,'tip',tip,'round',round,JSON.stringify(r),Date.now()-t,'ms');
}
console.log('--- sanity: straight peg');
{ const P=PEG['1/4']; const sh=4.6, sL=P.board+0.7;
  const p=fixWind([[-sL-4.6,-sh/2],[3,-sh/2],[3,sh/2],[-sL-4.6,sh/2]]);
  console.log(JSON.stringify(plan(p,P,{}))); }
console.log('--- thinner board 5.0 (real hardboard), tip variations');
for (const tip of [1.5,2.5,3.5]) { const P={hole:6.35,board:5.0}; console.log(tip, JSON.stringify(plan(profile(P,tip,4.6,true),P,{}))); }
console.log('--- round shank 4.0');
for (const tip of [1.5,2.5,3.5]) { const P={hole:6.35,board:6.35}; console.log(tip, JSON.stringify(plan(profile(P,tip,4.0,true),P,{}))); }
console.log('--- arc hooks');
function arcProfile(P, sh, Rc, phiTip){
  const tb=P.board, yC=-tb/2, zC=Rc, D=4.2,w0=7,w1=10,cl=0.15;
  const tongue=fixWind([[0.1,-w0/2+cl],[D-cl,-w1/2+cl+0.1],[D-cl,w1/2-cl-0.1],[0.1,w0/2-cl]]);
  const ri=Rc-sh/2, ro=Rc+sh/2;
  const phF=Math.acos(Math.min(1,(0.6-yC)/Rc))*-1; // front end (radians, negative)
  const a0=phF, a1=phiTip*Math.PI/180, n=48, pts=[];
  for(let i=0;i<=n;i++){const a=a0+(a1-a0)*i/n; pts.push([yC+ro*Math.cos(a), zC+ro*Math.sin(a)]);}
  for(let i=n;i>=0;i--){const a=a0+(a1-a0)*i/n; pts.push([yC+ri*Math.cos(a), zC+ri*Math.sin(a)]);}
  const arc=fixWind(pts);
  const tipC=[yC+Rc*Math.cos(a1), zC+Rc*Math.sin(a1)];
  return tongue.add(arc).add(circ2(sh/2,tipC[0],tipC[1]));
}
for (const [bk,sh] of [['1/4',4.6],['1/8',3.4]]) for (const Rc of [11,12,14]) for (const tip of [-135,-150,-165]) {
  const P=PEG[bk]; const t=Date.now(); const r=plan(arcProfile(P,sh,Rc,tip),P,{});
  console.log(bk,'Rc',Rc,'tip',tip,JSON.stringify(r),Date.now()-t,'ms');
}
