import zipfile, re, sys, numpy as np, trimesh, collections
z=zipfile.ZipFile(sys.argv[1]); x=z.read('3D/3dmodel.model').decode()
objs=re.findall(r'<object id="(\d+)"[^>]*>\s*<mesh>(.*?)</mesh>',x,re.S)
for oid,body in objs:
    vs=np.array([[float(a),float(b),float(c)] for a,b,c in re.findall(r'<vertex x="([^"]+)" y="([^"]+)" z="([^"]+)"',body)])
    fs=np.array([[int(a),int(b),int(c)] for a,b,c in re.findall(r'<triangle v1="(\d+)" v2="(\d+)" v3="(\d+)"',body)])
    a,b,c=vs[fs[:,0]],vs[fs[:,1]],vs[fs[:,2]]
    ar=np.linalg.norm(np.cross(b-a,c-a),axis=1)
    deg=np.where(ar<1e-12)[0]
    # duplicate positions with different indices
    _,inv,cnt=np.unique(np.round(vs,6),axis=0,return_inverse=True,return_counts=True)
    dup=(cnt>1).sum()
    m=trimesh.Trimesh(vs,fs,process=True)
    print('mesh',oid,'tris',len(fs),'degen',len(deg),'dup positions',dup,'watertight',m.is_watertight)
    for i in deg[:4]: print('   degen', np.round(vs[fs[i]],4).tolist())
    if dup: 
        idx=np.where(cnt[inv]>1)[0][:6]; print('   dup at', np.round(vs[idx],3).tolist())
