import Module from '/home/claude/deer/node_modules/manifold-3d/manifold.js';
import fs from 'fs';
eval(fs.readFileSync('/home/claude/deer/src/sdf.js','utf8'));
eval(fs.readFileSync('/home/claude/deer/src/engine.js','utf8'));
const M=await Module(); M.setup();
const st=globalThis.BUCK.defaults();
const r=globalThis.BUCK.build(M,st,{});
const O=r.objects.find(o=>o.name==='head'); const P=O.world.positions, I=O.world.indices;
const pts=[];
for(let t=0;t<I.length;t+=3){const a=I[t]*3,b=I[t+1]*3,c=I[t+2]*3;
 const ux=P[b]-P[a],uy=P[b+1]-P[a+1],uz=P[b+2]-P[a+2],vx=P[c]-P[a],vy=P[c+1]-P[a+1],vz=P[c+2]-P[a+2];
 const nx=uy*vz-uz*vy,ny=uz*vx-ux*vz,nz=ux*vy-uy*vx,l=Math.hypot(nx,ny,nz);
 if(ny/l<-0.72 && Math.min(P[a+1],P[b+1],P[c+1])>0.3) pts.push([(P[a]+P[b]+P[c])/3,(P[a+1]+P[b+1]+P[c+1])/3,(P[a+2]+P[b+2]+P[c+2])/3,l/2]);}
// cluster on a 6mm grid
const g={}; for(const p of pts){const k=[Math.round(p[0]/6),Math.round(p[1]/6),Math.round(p[2]/6)].join(','); (g[k]=g[k]||[0,0,0,0]); g[k][0]+=p[3]; g[k][1]+=p[0]*p[3]; g[k][2]+=p[1]*p[3]; g[k][3]+=p[2]*p[3];}
const L=Object.values(g).sort((a,b)=>b[0]-a[0]).slice(0,14);
for(const [A,x,y,z] of L) console.log(A.toFixed(0)+' mm2 at x '+(x/A).toFixed(1)+' y '+(y/A).toFixed(1)+' z '+(z/A).toFixed(1));
console.log('hinge',r.info.hinge.map(v=>v.toFixed(1)));
