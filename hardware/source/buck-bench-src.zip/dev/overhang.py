import zipfile, re, sys, numpy as np, collections
# per object overhang audit on a 3MF in print pose: faces steeper than 45 deg facing down, above the first layer,
# grouped into connected patches; reports the largest patches and their extent
def load(f):
    z=zipfile.ZipFile(f); x=z.read('3D/3dmodel.model').decode()
    ms=z.read('Metadata/model_settings.config').decode()
    names=dict(re.findall(r'<part id="(\d+)" subtype="normal_part">\s*<metadata key="name" value="([^"]+)"',ms))
    for oid,body in re.findall(r'<object id="(\d+)"[^>]*>\s*<mesh>(.*?)</mesh>',x,re.S):
        vs=np.array(re.findall(r'<vertex x="([^"]+)" y="([^"]+)" z="([^"]+)"',body),float)
        fs=np.array(re.findall(r'<triangle v1="(\d+)" v2="(\d+)" v3="(\d+)"',body),int)
        yield names.get(oid,oid), vs, fs
for f in sys.argv[1:]:
  for name,vs,fs in load(f):
    a,b,c=vs[fs[:,0]],vs[fs[:,1]],vs[fs[:,2]]
    n=np.cross(b-a,c-a); ar=np.linalg.norm(n,axis=1); nz=n[:,2]/np.maximum(ar,1e-12)
    zmin=np.minimum(np.minimum(a[:,2],b[:,2]),c[:,2])-vs[:,2].min()
    m=(nz<-0.72)&(zmin>0.3)
    idx=np.where(m)[0]
    # connectivity via shared vertices
    parent={i:i for i in idx}
    def find(i):
        while parent[i]!=i: parent[i]=parent[parent[i]]; i=parent[i]
        return i
    byv=collections.defaultdict(list)
    for i in idx:
        for v in fs[i]: byv[v].append(i)
    for v,L in byv.items():
        for j in L[1:]:
            ri,rj=find(L[0]),find(j)
            if ri!=rj: parent[ri]=rj
    groups=collections.defaultdict(list)
    for i in idx: groups[find(i)].append(i)
    pats=[]
    for g,L in groups.items():
        L=np.array(L); A=ar[L].sum()/2
        pts=np.concatenate([a[L],b[L],c[L]]); ext=pts.max(0)-pts.min(0)
        flat=(nz[L]<-0.95).sum()/len(L)
        pats.append((A,ext,pts.mean(0),flat))
    pats.sort(key=lambda p:-p[0])
    tot=ar[m].sum()/2
    print(f'{name:12s} overhang {tot:7.0f} mm2 in {len(pats)} patches; biggest:', '; '.join(f'{p[0]:.0f}mm2 {p[1][0]:.0f}x{p[1][1]:.0f}x{p[1][2]:.0f} at ({p[2][0]-vs[:,0].mean():.0f},{p[2][1]-vs[:,1].mean():.0f},{p[2][2]:.0f}) flat{p[3]:.0%}' for p in pats[:6]))
