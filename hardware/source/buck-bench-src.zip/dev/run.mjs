import Module from '/home/claude/deer/node_modules/manifold-3d/manifold.js';
import fs from 'fs';
eval(fs.readFileSync('/home/claude/deer/src/sdf.js','utf8'));
eval(fs.readFileSync('/home/claude/deer/src/engine.js','utf8'));
const M=await Module(); M.setup();
const st=globalThis.BUCK.defaults();
const over=process.argv[2]?JSON.parse(process.argv[2]):{};
for (const k in over) Object.assign(st[k],over[k]);
const t=Date.now();
const r=globalThis.BUCK.build(M,st,{});
console.log('ms',Date.now()-t, JSON.stringify(r.info));
console.log('errs',r.errs,'warns',r.warns,'notes',r.notes);
console.log(r.checks.map(c=>c.k+': '+c.v.toFixed(2)+(c.ok?' ok':' FAIL')+(c.by?' '+JSON.stringify(c.by)+' '+JSON.stringify(c.at):'')).join('\n'));
const cols={body:'#c9a37a',antler:'#f4f1ea',plaque:'#333333',accent:'#fe0386'};
const out=[];
for (const o of r.objects){ console.log(o.name, o.size.map(v=>v.toFixed(1)).join('x'), o.parts.map(p=>p.name+':'+p.world.tris+':'+p.world.volume.toFixed(0)).join(' '));
 for (const p of o.parts) out.push({p:Array.from(p.world.positions),i:Array.from(p.world.indices),c:cols[p.role]}); }
for (const k in r.hardware){ const h=r.hardware[k]; out.push({p:Array.from(h.positions),i:Array.from(h.indices),c:'#3fbf6f'}); }
fs.writeFileSync('/tmp/claude-0/m.json',JSON.stringify(out));
fs.writeFileSync('/tmp/claude-0/r.json',JSON.stringify({objects:r.objects.map(o=>({name:o.name,parts:o.parts.map(p=>({name:p.name,role:p.role,p:Array.from(p.print.positions),i:Array.from(p.print.indices)}))}))}));
