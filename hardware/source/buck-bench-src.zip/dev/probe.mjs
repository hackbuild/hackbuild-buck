import Module from '/home/claude/deer/node_modules/manifold-3d/manifold.js';
import fs from 'fs';
eval(fs.readFileSync('/home/claude/deer/src/sdf.js', 'utf8'));
eval(fs.readFileSync('/home/claude/deer/src/engine.js', 'utf8'));
const M = await Module(); M.setup();
const st = globalThis.BUCK.defaults();
const over = process.argv[2] ? JSON.parse(process.argv[2]) : {};
for (const k in over) { if (typeof over[k] === 'object') Object.assign(st[k], over[k]); else st[k] = over[k]; }
const r = globalThis.BUCK.build(M, st, {});
const P = r.probe, I = r.info;
console.log('fails', r.checks.filter(c => !c.ok).map(c => c.k), r.errs);
console.log('spine x', P.spineX0.toFixed(1), P.spineX1.toFixed(1), 'trayZ', I.trayZ, 'esp', I.esp, 'amp', I.amp, 'hinge', I.hinge.map(v=>v.toFixed(1)));
const flw = P.flP.map(q=>q.map(v=>v.toFixed(1))); console.log('servo flange holes world', JSON.stringify(flw));
// cavity map: for y in steps, z range, and free x extent left and right of the fin
for (const y of [2, 10, 20, 30, 40, 50]) {
  let line = 'y' + y + ': ';
  for (let z = -60; z <= 60; z += 6) {
    if (P.dIn(0, y, z) > -0.5) { continue; }
    let xr = 0; while (P.dIn(xr, y, z) < -0.5 && xr < 90) xr += 0.5;
    let xl = 0; while (P.dIn(-xl, y, z) < -0.5 && xl < 90) xl += 0.5;
    line += `z${z}[${(-xl).toFixed(0)},${xr.toFixed(0)}] `;
  }
  console.log(line);
}
