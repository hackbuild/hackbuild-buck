import asyncio
from playwright.async_api import async_playwright
OUT='/tmp/claude-0/smoke'
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(args=['--use-gl=swiftshader','--enable-webgl','--ignore-gpu-blocklist'])
        pg = await b.new_page(viewport={'width':1400,'height':900})
        await pg.goto('file:///home/claude/deer/out/buck.html')
        await pg.wait_for_function('globalThis.BENCH && BENCH.ready', timeout=120000)
        await pg.click('[data-preset=buck]'); await pg.wait_for_timeout(500)
        await pg.wait_for_function('!document.querySelector("#busy").classList.contains("on")', timeout=60000)
        await pg.click('[data-tog=board]'); await pg.click('[data-cam=side]')
        await pg.evaluate('document.querySelector("#jawA").value=100; document.querySelector("#jawA").dispatchEvent(new Event("input"))')
        await pg.wait_for_timeout(500); await pg.screenshot(path=OUT+'/7-jawopen.png')
        await pg.click('[data-tog=xray]'); await pg.click('[data-cam=iso]'); await pg.wait_for_timeout(500); await pg.screenshot(path=OUT+'/8-xray.png')
        await pg.click('[data-tog=xray]'); await pg.click('[data-mode=explode]'); await pg.wait_for_timeout(1500); await pg.screenshot(path=OUT+'/9-explode.png')
        await pg.click('[data-mode=assembled]'); await pg.click('[data-cam=under]'); await pg.wait_for_timeout(800); await pg.screenshot(path=OUT+'/10-under.png')
        for w in [390,768]:
            await pg.set_viewport_size({'width':w,'height':844}); await pg.wait_for_timeout(500)
            sw = await pg.evaluate('document.documentElement.scrollWidth'); print(w,'scrollWidth',sw)
            await pg.screenshot(path=OUT+f'/m{w}.png')
        await b.close()
asyncio.run(main())
