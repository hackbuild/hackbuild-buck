import sys, json, base64, asyncio
from playwright.async_api import async_playwright
async def main(meshfile, views, prefix):
    async with async_playwright() as p:
        b = await p.chromium.launch(args=['--use-gl=swiftshader','--enable-webgl','--ignore-gpu-blocklist'])
        pg = await b.new_page(viewport={'width':1200,'height':800})
        await pg.goto('file:///home/claude/deer/dev/viewer.html')
        meshes = json.load(open(meshfile))
        outs = await pg.evaluate('([m,v])=>render(m,v)', [meshes, views])
        for i,o in enumerate(outs):
            open(f'{prefix}{i}.png','wb').write(base64.b64decode(o.split(',')[1]))
        await b.close()
views=json.loads(sys.argv[2]) if len(sys.argv)>2 else [{"dir":[0.6,0.5,0.9]},{"dir":[1,0.05,0.0]},{"dir":[0.0,0.1,1]},{"dir":[0.0,1,0.15]}]
asyncio.run(main(sys.argv[1], views, sys.argv[3] if len(sys.argv)>3 else '/tmp/claude-0/shot'))
