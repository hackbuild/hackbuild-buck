import Module from '/home/claude/deer/node_modules/manifold-3d/manifold.js';
import fs from 'fs'; import { createRequire } from 'module'; import { execSync } from 'child_process';
const require = createRequire(import.meta.url); const JSZip = require('jszip');
eval(fs.readFileSync('/home/claude/deer/src/sdf.js','utf8'));
eval(fs.readFileSync('/home/claude/deer/src/engine.js','utf8'));
eval(fs.readFileSync('/mnt/skills/plugins/print-forge/assets/orca3mf.js','utf8'));
const M=await Module(); M.setup();
const V=JSON.parse(fs.readFileSync(process.argv[2],'utf8'));
const tag=process.argv[3]||'sw';
const sig=r=>r.objects.map(o=>o.name+':'+o.print.tris+':'+o.print.volume.toFixed(1)).join('|');
let s0=null;
for (const [name,over] of V){
  const st=globalThis.BUCK.defaults();
  for (const k in over){ if (typeof over[k]==='object') Object.assign(st[k],over[k]); else st[k]=over[k]; }
  let r; const t=Date.now();
  try { r=globalThis.BUCK.build(M,st,{}); } catch(e){ console.log(name.padEnd(16),'THREW',e.message); continue; }
  const sg=sig(r); if (s0===null) s0=sg;
  const bad=r.checks.filter(c=>!c.ok).map(c=>c.k.slice(0,40)+'='+c.v.toFixed(2));
  let x=10, y=10, rowH=0; const objs=[];
  for (const o of r.objects){ if (x+o.size[0]>500){x=10;y+=rowH+5;rowH=0;} objs.push({name:o.name,positions:[[x+o.size[0]/2,y+o.size[1]/2,0]],parts:[{name:o.name,slot:o.slot,positions:o.print.positions,indices:o.print.indices}]}); x+=o.size[0]+5; rowH=Math.max(rowH,o.size[1]); }
  const f='/tmp/claude-0/'+tag+'.3mf';
  fs.writeFileSync(f, await globalThis.Orca3MF.build({filaments:st.slots,objects:objs,title:'t'}).zip(JSZip,'nodebuffer'));
  let v=''; try { execSync('python3 /mnt/skills/plugins/print-forge/scripts/validate_3mf.py '+f,{stdio:'pipe'}); v='3mf ok'; } catch(e){ v='3MF FAIL: '+(e.stdout.toString().split('FAILURES')[1]||'').trim().split('\n').slice(0,3).join(' ; '); }
  console.log(name.padEnd(16), (Date.now()-t)+'ms', name==='default'?'':'dead='+(sg===s0), r.errs.join(';'), bad.join(';'), v);
}
