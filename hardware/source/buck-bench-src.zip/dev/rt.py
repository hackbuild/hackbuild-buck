import asyncio, base64, json
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(args=['--use-gl=swiftshader','--enable-webgl','--ignore-gpu-blocklist'])
        pg = await b.new_page(viewport={'width':1300,'height':850})
        errs=[]; pg.on('pageerror', lambda e: errs.append(str(e)))
        pg.on('console', lambda m: errs.append(m.text) if m.type=='error' else None)
        await pg.goto('file:///home/claude/deer/out/buck.html')
        await pg.wait_for_function('globalThis.BENCH && BENCH.ready', timeout=120000)
        await pg.click('[data-preset=stag]'); await pg.wait_for_timeout(600)
        await pg.wait_for_function('!document.querySelector("#busy").classList.contains("on")', timeout=90000)
        j1 = base64.b64decode(await pg.evaluate('BENCH.exportBytes("json")')).decode()
        await pg.click('#steps button[data-step="1"]'); await pg.wait_for_timeout(200)
        await pg.fill('input[type=number][data-p="jaw.open"]', '18'); await pg.press('input[type=number][data-p="jaw.open"]','Tab')
        await pg.wait_for_timeout(800); await pg.wait_for_function('!document.querySelector("#busy").classList.contains("on")', timeout=90000)
        print('open after edit', await pg.evaluate('BENCH.result().info.open'))
        # undo back
        await pg.wait_for_timeout(600); await pg.click('#bUndo'); await pg.wait_for_timeout(900)
        await pg.wait_for_function('!document.querySelector("#busy").classList.contains("on")', timeout=90000)
        j2 = base64.b64decode(await pg.evaluate('BENCH.exportBytes("json")')).decode()
        print('undo round trip', json.loads(j1)['state']==json.loads(j2)['state'])
        await pg.click('#steps button[data-step="3"]'); await pg.wait_for_timeout(300)
        await pg.screenshot(path='/tmp/claude-0/smoke/stag.png')
        print('errors', errs)
        await b.close()
asyncio.run(main())
