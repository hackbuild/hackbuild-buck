import asyncio, json, sys
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(args=['--use-gl=swiftshader','--enable-webgl','--ignore-gpu-blocklist'])
        pg = await b.new_page(viewport={'width':1400,'height':1000})
        await pg.add_init_script(('window.SOLID=1;' if len(sys.argv)>2 else '') + ('window.HIDE=' + sys.argv[3] + ';' if len(sys.argv)>3 else '') + 'window.DUMP=' + open('/tmp/claude-0/dump.json').read())
        await pg.goto('file:///home/claude/deer/dev/guts.html')
        views = json.loads(sys.argv[1])
        for i,v in enumerate(views):
            await pg.evaluate(f'shot({",".join(map(str,v))})'); await pg.wait_for_timeout(300)
            await pg.screenshot(path=f'/tmp/claude-0/g{i}.png')
        await b.close()
asyncio.run(main())
