import Module from '/home/claude/deer/node_modules/manifold-3d/manifold.js';
import fs from 'fs';
eval(fs.readFileSync('/home/claude/deer/src/sdf.js','utf8'));
const M=await Module(); M.setup(); const {Manifold}=M;
const over=process.argv[2]?JSON.parse(process.argv[2]):{};
const sh=Object.assign({s:1.15,muzzle:1,neck:1,crown:1,cheek:1,tilt:12,eye:1,eyeMode:'sculpted'},over); const FN=process.argv[4]==='coarse'?'dCoarse':'d';
const H=globalThis.BUCKSDF.makeHead(sh);
let t=Date.now();
const m=Manifold.levelSet(p=>-H[FN](p[0],p[1],p[2]),{min:[-60,-3,-75],max:[60,170,75]},+(process.argv[3]||0.8),0).simplify(0.03);
const mesh=m.getMesh(); const P=mesh.vertProperties, np=mesh.numProp;
const vc=[]; const pos=[];
for(let i=0;i<P.length/np;i++){ const x=P[i*np],y=P[i*np+1],z=P[i*np+2]; pos.push(x,y,z); vc.push(...globalThis.BUCKSDF.paintHead(H,x,y,z)); }
console.log('ms',Date.now()-t,m.numTri(),JSON.stringify(m.boundingBox()));
fs.writeFileSync('/tmp/claude-0/m.json',JSON.stringify([{p:pos,i:Array.from(mesh.triVerts),vc}]));
