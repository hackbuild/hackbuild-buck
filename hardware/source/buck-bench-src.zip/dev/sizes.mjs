import Module from '/home/claude/deer/node_modules/manifold-3d/manifold.js';
import fs from 'fs';
eval(fs.readFileSync('/home/claude/deer/src/sdf.js', 'utf8'));
eval(fs.readFileSync('/home/claude/deer/src/engine.js', 'utf8'));
const M = await Module(); M.setup();
const st = globalThis.BUCK.defaults();
const over = process.argv[2] ? JSON.parse(process.argv[2]) : {}; for (const k in over) Object.assign(st[k], over[k]);
const r = globalThis.BUCK.build(M, st, {});
for (const o of r.objects) { const P = o.world.positions; const mn=[1e9,1e9,1e9], mx=[-1e9,-1e9,-1e9]; for (let i=0;i<P.length;i+=3) for (let c=0;c<3;c++){mn[c]=Math.min(mn[c],P[i+c]);mx[c]=Math.max(mx[c],P[i+c]);} console.log(o.name.padEnd(10), mn.map(v=>v.toFixed(0)).join(','), '..', mx.map(v=>v.toFixed(0)).join(','), 'print', o.size.map(v=>v.toFixed(0)).join('x')); }
console.log(JSON.stringify(r.info.plaque), r.warns);
