import Module from '/home/claude/deer/node_modules/manifold-3d/manifold.js';
import fs from 'fs';
eval(fs.readFileSync('/home/claude/deer/src/sdf.js','utf8'));
eval(fs.readFileSync('/home/claude/deer/src/engine.js','utf8'));
const M=await Module(); M.setup();
const st=globalThis.BUCK.defaults();
const over=process.argv[2]?JSON.parse(process.argv[2]):{};
for (const k in over){ if (typeof over[k]==='object') Object.assign(st[k],over[k]); else st[k]=over[k]; }
const cache={};
const t=Date.now();
const r=globalThis.BUCK.build(M,st,cache);
console.log('ms',Date.now()-t, JSON.stringify(r.info.tm));
console.log('errs',r.errs,'warns',r.warns,'notes',r.notes);
for (const c of r.checks) console.log((c.ok?'  ok ':'FAIL ')+c.k+'  '+c.v.toFixed(2)+(c.by?' '+JSON.stringify(c.by):''));
const out=[];
for (const o of r.objects){ console.log(o.name.padEnd(10), o.size.map(v=>v.toFixed(1)).join('x'), o.world.tris, o.world.volume.toFixed(0));
  out.push({p:Array.from(o.world.positions),i:Array.from(o.world.indices),vc:o.paint?Array.from(o.paint):undefined,c:'#444444'}); }
for (const k in r.hardware){ const h=r.hardware[k]; out.push({p:Array.from(h.positions),i:Array.from(h.indices),c:'#3fbf6f'}); }
fs.writeFileSync('/tmp/claude-0/m.json',JSON.stringify(out));
globalThis.R=r;
if (process.argv[3]) { const ex=await import(process.argv[3]); await ex.default(r,st); }
