import asyncio, os, sys
from playwright.async_api import async_playwright
OUT='/tmp/claude-0/shots3'; os.makedirs(OUT, exist_ok=True)
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(args=['--use-gl=swiftshader','--enable-webgl','--ignore-gpu-blocklist'])
        pg = await b.new_page(viewport={'width':1300,'height':900}); pg.set_default_timeout(240000)
        await pg.goto('file:///home/claude/deer/out/buck.html')
        await pg.wait_for_function('globalThis.BENCH && BENCH.ready', timeout=180000)
        await pg.click('[data-preset=buck]'); await pg.wait_for_timeout(800)
        await pg.wait_for_function('!document.querySelector("#busy").classList.contains("on")', timeout=180000)
        await pg.click('[data-tog=xray]'); await pg.wait_for_timeout(500)
        cams = [(2.2, 0.15, 230), (0.9, 0.25, 230), (1.57, -0.9, 230), (3.4, 0.5, 230)]
        for i,(th,ph,r) in enumerate(cams):
            await pg.evaluate(f'(()=>{{const c=BENCH.view.camState(); c.theta={th}; c.phi={ph}; c.r={r}; c.target.set(0, -2, -20); BENCH.view.setCam(c);}})()')
            await pg.wait_for_timeout(700)
            await pg.screenshot(path=f'{OUT}/x{i}.png', clip={'x':330,'y':60,'width':700,'height':780})
        await b.close()
asyncio.run(main())
