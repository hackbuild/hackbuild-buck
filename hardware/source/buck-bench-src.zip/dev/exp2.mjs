import Module from '/home/claude/deer/node_modules/manifold-3d/manifold.js';
import fs from 'fs'; import { createRequire } from 'module';
const require = createRequire(import.meta.url); const JSZip = require('jszip');
eval(fs.readFileSync('/home/claude/deer/src/sdf.js', 'utf8'));
eval(fs.readFileSync('/home/claude/deer/src/engine.js', 'utf8'));
eval(fs.readFileSync('/mnt/skills/plugins/print-forge/assets/orca3mf.js', 'utf8'));
const M = await Module(); M.setup();
const st = globalThis.BUCK.defaults();
const over = process.argv[2] ? JSON.parse(process.argv[2]) : {};
for (const k in over) { if (typeof over[k] === 'object') Object.assign(st[k], over[k]); else st[k] = over[k]; }
const r = globalThis.BUCK.build(M, st, {});
console.log('ms', r.info.ms, 'errs', r.errs, 'fails', r.checks.filter(c => !c.ok).map(c => c.k));
let x = 10, y = 10, rowH = 0; const objs = [];
for (const o of r.objects) { if (x + o.size[0] > 500) { x = 10; y += rowH + 5; rowH = 0; } objs.push({ name: o.name, positions: [[x + o.size[0] / 2, y + o.size[1] / 2, 0]], parts: [{ name: o.name, slot: o.slot, positions: o.print.positions, indices: o.print.indices }] }); x += o.size[0] + 5; rowH = Math.max(rowH, o.size[1]); }
fs.writeFileSync(process.argv[3] || '/tmp/claude-0/v2.3mf', await globalThis.Orca3MF.build({ filaments: st.slots, objects: objs, title: 't' }).zip(JSZip, 'nodebuffer'));
