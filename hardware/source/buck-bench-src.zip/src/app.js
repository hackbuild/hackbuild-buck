/* BUCK bench app v3: state, rail wiring, three viewer, jaw sim, plates, exports. Plain script. */
(function () {
  'use strict';
  const $ = s => document.querySelector(s), $$ = s => Array.from(document.querySelectorAll(s));
  const D2R = Math.PI / 180;
  let M = null;
  const CACHE = {};
  let ST = BUCK.defaults();
  ST.ui = { step: 0, mode: 'assembled', paint: true, xray: false, section: false, hw: true, board: true, secX: 0, plate: 0 };
  let R = null;
  let building = false, rev = 0, builtRev = -1, freshQ = null;

  const PRESETS = {
    buck: {},
    fork: { antlers: { style: 'fork', size: 1.05 } },
    spike: { antlers: { style: 'spike', size: 1.0, spread: 0.8 }, shape: { muzzle: 0.96 } },
    doe: { antlers: { style: 'none' }, ears: { size: 1.12 }, shape: { muzzle: 0.94 } }
  };
  function applyPreset(k) {
    const ui = ST.ui; ST = BUCK.defaults(); ST.ui = ui;
    const p = PRESETS[k] || {};
    for (const g in p) Object.assign(ST[g], p[g]);
    ST.preset = k;
  }

  /* ---------------------------------------------------------------- undo */
  const design = () => { const o = JSON.parse(JSON.stringify(ST)); delete o.ui; return o; };
  const hist = [], fut = []; let snapT = 0, lastSnap = null;
  function snapshot() { clearTimeout(snapT); snapT = setTimeout(() => { const s = JSON.stringify(design()); if (s !== lastSnap) { if (lastSnap) hist.push(lastSnap); if (hist.length > 60) hist.shift(); lastSnap = s; fut.length = 0; } }, 400); }
  function restore(s) { const ui = ST.ui; ST = merge(BUCK.defaults(), JSON.parse(s)); ST.ui = ui; lastSnap = s; UI.refresh(); rev++; schedule(0); }
  function merge(base, s) { for (const k in s) { if (s[k] && typeof s[k] === 'object' && !Array.isArray(s[k]) && base[k]) Object.assign(base[k], s[k]); else base[k] = s[k]; } return base; }
  function undo() { if (!hist.length) return; fut.push(lastSnap); restore(hist.pop()); }
  function redo() { if (!fut.length) return; hist.push(lastSnap); restore(fut.pop()); }

  /* ---------------------------------------------------------------- build loop */
  let schedT = 0;
  function commit() { rev++; snapshot(); schedule(320); }
  function schedule(ms) { clearTimeout(schedT); schedT = setTimeout(runBuild, ms); }
  function runBuild() {
    if (!M) return;
    if (building) { schedule(200); return; }
    building = true; $('#busy').textContent = 'BUILDING'; $('#busy').classList.add('on');
    const myRev = rev;
    setTimeout(() => {
      try { R = BUCK.build(M, ST, CACHE); builtRev = myRev; freshQ = ST.print.quality; VIEW.setResult(R); UI.afterBuild(); }
      catch (e) { console.error(e); UI.status('build failed: ' + (e && e.message || e), 'err'); }
      building = false; $('#busy').classList.remove('on');
      if (rev !== builtRev) schedule(60);
    }, 40);
  }
  async function ensureFine() {
    if (R && builtRev === rev && freshQ === 'fine') return R;
    $('#busy').textContent = 'FINE MESH FOR EXPORT'; $('#busy').classList.add('on');
    await new Promise(r => setTimeout(r, 40));
    const prev = ST.print.quality; ST.print.quality = 'fine';
    try { R = BUCK.build(M, ST, CACHE); builtRev = rev; freshQ = 'fine'; }
    finally { ST.print.quality = prev; $('#busy').classList.remove('on'); }
    VIEW.setResult(R); UI.afterBuild();
    return R;
  }

  /* ---------------------------------------------------------------- colours */
  const single = () => ST.print.mode === 'single';
  const slotOf = role => single() ? 1 : (ST.roles[role] || 1);
  const colOfSlot = s => { const c = (ST.slots[s - 1] || {}).color || '#888888'; return c.toUpperCase() === '#FFFFFF' ? '#F4F1EA' : c; };
  const colOf = role => colOfSlot(slotOf(role));

  /* ---------------------------------------------------------------- viewer */
  const VIEW = {};
  (function () {
    const cv = $('#cv');
    const renderer = new THREE.WebGLRenderer({ canvas: cv, antialias: true, alpha: true, preserveDrawingBuffer: true });
    renderer.setPixelRatio(Math.min(2, window.devicePixelRatio || 1));
    renderer.setClearColor(0x000000, 0);
    renderer.localClippingEnabled = true;
    renderer.outputEncoding = THREE.sRGBEncoding;
    renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = 0.92;
    renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    const scene = new THREE.Scene();
    // a small studio for reflections: warm key panel, cool fill, dark floor
    {
      const pm = new THREE.PMREMGenerator(renderer), room = new THREE.Scene();
      room.add(new THREE.Mesh(new THREE.BoxGeometry(20, 20, 20), new THREE.MeshBasicMaterial({ color: 0x2a2624, side: THREE.BackSide })));
      const panel = (c, i, p, r) => { const m = new THREE.Mesh(new THREE.PlaneGeometry(6, 6), new THREE.MeshBasicMaterial({ color: new THREE.Color(c).multiplyScalar(i), side: THREE.DoubleSide })); m.position.set(...p); m.lookAt(0, 0, 0); if (r) m.scale.set(r[0], r[1], 1); room.add(m); };
      panel(0xfff1df, 9, [-6, 7, 6], [1.4, 0.8]); panel(0xdfe9ff, 3.5, [8, 2, -4]); panel(0xffe0f0, 2.0, [0, -6, 8], [2, 0.5]);
      scene.environment = pm.fromScene(room, 0.03).texture;
    }
    const cam = new THREE.PerspectiveCamera(28, 1, 2, 8000);
    scene.add(new THREE.HemisphereLight(0xfff4ea, 0x2c2622, 0.35));
    const key = new THREE.DirectionalLight(0xfff0e0, 1.6); key.position.set(-260, 420, 380); key.castShadow = true;
    key.shadow.mapSize.set(2048, 2048); key.shadow.bias = -0.0004; key.shadow.normalBias = 0.6;
    Object.assign(key.shadow.camera, { left: -260, right: 260, top: 260, bottom: -260, near: 50, far: 1600 });
    scene.add(key); scene.add(key.target);
    const rim = new THREE.DirectionalLight(0xffd6ea, 0.55); rim.position.set(360, 160, -260); scene.add(rim);
    const root = new THREE.Group(); root.rotation.x = -Math.PI / 2; scene.add(root);
    const asm = new THREE.Group(); root.add(asm);
    const jawPivot = new THREE.Group(); asm.add(jawPivot);
    const hwG = new THREE.Group(); asm.add(hwG);
    const boardG = new THREE.Group(); root.add(boardG);
    const printG = new THREE.Group(); root.add(printG); printG.visible = false;
    const clip = new THREE.Plane(new THREE.Vector3(-1, 0, 0), 1e5);
    const orbit = { target: new THREE.Vector3(0, 0, 0), r: 420, theta: 2.35, phi: 0.3 };
    const presets = { iso: [2.3, 0.28], front: [Math.PI, 0.06], side: [Math.PI / 2, 0.04], top: [Math.PI, 1.42], under: [2.55, -0.7] };
    function applyCam() {
      const o = orbit, c = Math.cos(o.phi);
      cam.position.set(o.target.x + o.r * c * Math.sin(o.theta), o.target.y + o.r * Math.sin(o.phi), o.target.z + o.r * c * Math.cos(o.theta));
      cam.lookAt(o.target);
    }
    VIEW.preset = k => { const p = presets[k]; if (p) { orbit.theta = p[0]; orbit.phi = p[1]; applyCam(); } };
    function resize() { const w = cv.clientWidth || 1, h = cv.clientHeight || 1; renderer.setSize(w, h, false); cam.aspect = w / h; cam.updateProjectionMatrix(); }
    window.addEventListener('resize', resize);
    let drag = null;
    cv.addEventListener('contextmenu', e => e.preventDefault());
    cv.addEventListener('pointerdown', e => { drag = { x: e.clientX, y: e.clientY, b: e.button, shift: e.shiftKey }; cv.setPointerCapture(e.pointerId); });
    cv.addEventListener('pointerup', e => { drag = null; try { cv.releasePointerCapture(e.pointerId); } catch (_) { } });
    cv.addEventListener('pointermove', e => {
      if (!drag) return; const dx = e.clientX - drag.x, dy = e.clientY - drag.y; drag.x = e.clientX; drag.y = e.clientY;
      if (drag.b === 0 && !drag.shift) { orbit.theta -= dx * 0.008; orbit.phi = Math.max(-1.5, Math.min(1.5, orbit.phi + dy * 0.008)); }
      else { const k = orbit.r * 0.0014; const right = new THREE.Vector3().setFromMatrixColumn(cam.matrix, 0), up = new THREE.Vector3().setFromMatrixColumn(cam.matrix, 1); orbit.target.addScaledVector(right, -dx * k).addScaledVector(up, dy * k); }
      applyCam();
    });
    cv.addEventListener('wheel', e => { e.preventDefault(); orbit.r = Math.max(60, Math.min(3000, orbit.r * Math.exp(e.deltaY * 0.0012))); applyCam(); }, { passive: false });
    cv.addEventListener('dblclick', () => VIEW.fit());

    // per corner normals averaged across faces within the crease angle: smooth skin, crisp cuts
    function creased(P, I, deg, C) {
      const nf = I.length / 3, fn = new Float32Array(nf * 3), cosT = Math.cos(deg * D2R), nv = P.length / 3, cnt = new Uint32Array(nv + 1);
      for (let f = 0; f < nf; f++) {
        const a = I[f * 3] * 3, b = I[f * 3 + 1] * 3, c = I[f * 3 + 2] * 3;
        const ux = P[b] - P[a], uy = P[b + 1] - P[a + 1], uz = P[b + 2] - P[a + 2], vx = P[c] - P[a], vy = P[c + 1] - P[a + 1], vz = P[c + 2] - P[a + 2];
        let x = uy * vz - uz * vy, y = uz * vx - ux * vz, z = ux * vy - uy * vx; const l = Math.hypot(x, y, z) || 1;
        fn[f * 3] = x / l; fn[f * 3 + 1] = y / l; fn[f * 3 + 2] = z / l; cnt[I[f * 3]]++; cnt[I[f * 3 + 1]]++; cnt[I[f * 3 + 2]]++;
      }
      const off = new Uint32Array(nv + 1); for (let i = 0; i < nv; i++) off[i + 1] = off[i] + cnt[i];
      const adj = new Uint32Array(off[nv]), fill = off.slice(0, nv);
      for (let f = 0; f < nf; f++) for (let k = 0; k < 3; k++) { const v = I[f * 3 + k]; adj[fill[v]++] = f; }
      const pos = new Float32Array(nf * 9), nor = new Float32Array(nf * 9), col = C ? new Float32Array(nf * 9) : null;
      for (let f = 0; f < nf; f++) for (let k = 0; k < 3; k++) {
        const v = I[f * 3 + k]; let x = 0, y = 0, z = 0;
        for (let j = off[v]; j < off[v + 1]; j++) { const g = adj[j]; if (fn[f * 3] * fn[g * 3] + fn[f * 3 + 1] * fn[g * 3 + 1] + fn[f * 3 + 2] * fn[g * 3 + 2] >= cosT) { x += fn[g * 3]; y += fn[g * 3 + 1]; z += fn[g * 3 + 2]; } }
        const l = Math.hypot(x, y, z) || 1, o = (f * 3 + k) * 3;
        nor[o] = x / l; nor[o + 1] = y / l; nor[o + 2] = z / l;
        pos[o] = P[v * 3]; pos[o + 1] = P[v * 3 + 1]; pos[o + 2] = P[v * 3 + 2];
        if (col) { col[o] = srgb(C[v * 3]); col[o + 1] = srgb(C[v * 3 + 1]); col[o + 2] = srgb(C[v * 3 + 2]); }
      }
      return { pos, nor, col };
    }
    const srgb = c => c <= 0.04045 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);   // vertex colours are authored in sRGB
    function geom(mesh, smooth, shift, C) {
      const c = creased(mesh.positions, mesh.indices, smooth ? 40 : 18, C);
      const g = new THREE.BufferGeometry();
      g.setAttribute('position', new THREE.BufferAttribute(c.pos, 3)); g.setAttribute('normal', new THREE.BufferAttribute(c.nor, 3));
      if (c.col) g.setAttribute('color', new THREE.BufferAttribute(c.col, 3));
      if (shift) g.translate(shift[0], shift[1], shift[2]);
      return g;
    }
    function clear(gr) { for (let i = gr.children.length - 1; i >= 0; i--) { const c = gr.children[i]; if (c === jawPivot || c === hwG) continue; gr.remove(c); c.traverse(o => { if (o.geometry) o.geometry.dispose(); }); } }
    // walnut for the plaque in paint view
    const wood = (() => {
      const c = document.createElement('canvas'); c.width = 512; c.height = 1024; const x = c.getContext('2d');
      x.fillStyle = '#4a2f1d'; x.fillRect(0, 0, 512, 1024);
      for (let i = 0; i < 140; i++) { const y0 = Math.random() * 1024; x.strokeStyle = 'rgba(' + (30 + Math.random() * 40 | 0) + ',' + (16 + Math.random() * 20 | 0) + ',8,' + (0.15 + Math.random() * 0.25) + ')'; x.lineWidth = 1 + Math.random() * 3; x.beginPath(); for (let px = 0; px <= 512; px += 16) x.lineTo(px, y0 + Math.sin(px * 0.01 + i) * 12 + Math.sin(px * 0.043 + i * 3) * 4); x.stroke(); }
      const t = new THREE.CanvasTexture(c); t.encoding = THREE.sRGBEncoding; t.wrapS = t.wrapT = THREE.RepeatWrapping; return t;
    })();
    const parts = [];   // {mesh, O}
    const objG = {};
    function matFor(O) {
      const paint = ST.ui.paint && !single() ? true : ST.ui.paint;
      const glossy = O.name === 'nose' || O.name.startsWith('eye');
      if (paint && O.paint) return new THREE.MeshPhysicalMaterial({ vertexColors: true, roughness: glossy ? 0.18 : 0.72, clearcoat: glossy ? 1 : 0, clearcoatRoughness: 0.06, metalness: 0, clippingPlanes: [clip], side: THREE.DoubleSide, envMapIntensity: glossy ? 1.2 : 0.6 });
      if (paint && O.role === 'plaque') return new THREE.MeshPhysicalMaterial({ map: wood, roughness: 0.45, clearcoat: 0.6, clearcoatRoughness: 0.25, clippingPlanes: [clip], side: THREE.DoubleSide });
      if (paint && O.role === 'pin') return new THREE.MeshStandardMaterial({ color: lin('#3a2a1e'), roughness: 0.6, clippingPlanes: [clip], side: THREE.DoubleSide });
      return new THREE.MeshStandardMaterial({ color: lin(colOf(O.role)), roughness: 0.55, metalness: 0.02, clippingPlanes: [clip], side: THREE.DoubleSide, envMapIntensity: 0.5 });
    }
    const lin = h => new THREE.Color(h).convertSRGBToLinear();
    function plaqueUV(g) { const p = g.attributes.position.array, uv = new Float32Array(p.length / 3 * 2); for (let i = 0, j = 0; i < p.length; i += 3, j += 2) { uv[j] = p[i] / 140 + 0.5; uv[j + 1] = p[i + 2] / 180 + 0.5; } g.setAttribute('uv', new THREE.BufferAttribute(uv, 2)); }

    function pegboard(info) {
      clear(boardG);
      if (info.hookMode === 'none') return;
      const T = info.plaque.t, peg = info.peg, th = info.hookMode === 'hooks' ? peg.board : 6.35, hd = info.hookMode === 'hooks' ? peg.hole : 6.35;
      const W = 18 * 25.4, Hh = 15 * 25.4, hz = info.hookZ, x0 = -W / 2, z0 = hz - 25.4 * 10.5;
      const cols = 18, rowsN = 15, ox = (info.pitch / 2) % 25.4;      // a hole column lands on each hook
      const c = document.createElement('canvas'); c.width = 18 * 48; c.height = 15 * 48;
      const x = c.getContext('2d'); x.fillStyle = '#a5845d'; x.fillRect(0, 0, c.width, c.height);
      for (let i = 0; i < 6000; i++) { x.fillStyle = 'rgba(70,45,20,' + (Math.random() * 0.07) + ')'; x.fillRect(Math.random() * c.width, Math.random() * c.height, 5, 1); }
      x.fillStyle = '#16100a';
      for (let i = -cols; i <= cols; i++) for (let k = -rowsN; k <= rowsN; k++) {
        const gx = ox + i * 25.4, gz = hz + k * 25.4; if (gx < x0 + 6 || gx > x0 + W - 6 || gz < z0 + 6 || gz > z0 + Hh - 6) continue;
        x.beginPath(); x.arc((gx - x0) / W * c.width, (1 - (gz - z0) / Hh) * c.height, hd / 2 / W * c.width, 0, 7); x.fill();
      }
      const tex = new THREE.CanvasTexture(c); tex.encoding = THREE.sRGBEncoding; tex.anisotropy = 4;
      const face = new THREE.Mesh(new THREE.PlaneGeometry(W, Hh).rotateX(Math.PI / 2), new THREE.MeshStandardMaterial({ map: tex, roughness: 0.92, side: THREE.DoubleSide }));
      face.position.set(x0 + W / 2, -T - 0.05, z0 + Hh / 2); face.receiveShadow = true; boardG.add(face);
      const slab = new THREE.Mesh(new THREE.BoxGeometry(W, th - 0.2, Hh), new THREE.MeshStandardMaterial({ color: 0x6e5236, roughness: 0.9 }));
      slab.position.set(x0 + W / 2, -T - 0.1 - th / 2, z0 + Hh / 2); boardG.add(slab);
      if (info.hookMode === 'holes') for (const sx of [-1, 1]) {
        const hm = new THREE.MeshStandardMaterial({ color: 0xc9ccd1, metalness: 0.85, roughness: 0.3 });
        const L = 70, r = 2.4, shaft = new THREE.Mesh(new THREE.CylinderGeometry(r, r, L, 16), hm);
        shaft.position.set(sx * info.pitch / 2, -T + L / 2 - 4, info.hookZ); shaft.rotation.x = 8 * D2R; shaft.castShadow = true; boardG.add(shaft);
      }
    }

    VIEW.setResult = function (R) {
      clear(asm); clear(jawPivot); clear(hwG); clear(printG);
      parts.length = 0; for (const k in objG) delete objG[k];
      const H = R.info.hinge;
      jawPivot.position.set(H[0], H[1], H[2]);
      for (const O of R.objects) {
        const isJaw = O.name === 'jaw';
        const smooth = !['mount', 'pivot pin', 'hook L', 'hook R'].includes(O.name);
        const g = geom(O.world, smooth, isJaw ? [-H[0], -H[1], -H[2]] : null, O.paint);
        if (O.role === 'plaque') plaqueUV(g);
        const m = new THREE.Mesh(g, matFor(O));
        m.castShadow = true; m.receiveShadow = true; m.userData.O = O;
        parts.push(m);
        const grp = new THREE.Group(); grp.add(m); objG[O.name] = { g: grp, O };
        (isJaw ? jawPivot : asm).add(grp);
      }
      const hwCol = { servo: '#2f5fbf', horn: '#f2f2f2', esp: '#1f7a3a', amp: '#5b2a86', speaker: '#2b2b2b', usb: '#6d6d6d' };
      for (const k in R.hardware) {
        const m = new THREE.Mesh(geom(R.hardware[k], false, k === 'horn' ? [-H[0], -H[1], -H[2]] : null), new THREE.MeshStandardMaterial({ color: lin(hwCol[k] || '#999999'), roughness: 0.5, clippingPlanes: [clip], side: THREE.DoubleSide }));
        m.userData.hw = k; m.castShadow = true;
        (k === 'horn' ? jawPivot : hwG).add(m);
      }
      pegboard(R.info);
      buildPrint(R);
      VIEW.apply();
      if (!VIEW._fitted) { VIEW.fit(); VIEW._fitted = true; }
      VIEW.legend();
    };
    VIEW.restyle = function () { for (const m of parts) { m.material.dispose(); m.material = matFor(m.userData.O); } VIEW.apply(); buildPrint(R); VIEW.legend(); };
    /* print bed */
    let plates = [];
    function buildPrint(R) {
      clear(printG);
      plates = PLATES.layout(R);
      const pl = plates[Math.min(ST.ui.plate, plates.length - 1)] || plates[0];
      if (!pl) return;
      const bw = ST.print.bedW, bd = ST.print.bedD;
      const bed = new THREE.Mesh(new THREE.BoxGeometry(bw, bd, 1), new THREE.MeshStandardMaterial({ color: lin('#2a2a30'), roughness: 0.85 }));
      bed.position.set(bw / 2, bd / 2, -0.55); bed.receiveShadow = true; printG.add(bed);
      const edges = new THREE.LineSegments(new THREE.EdgesGeometry(new THREE.BoxGeometry(bw, bd, 1)), new THREE.LineBasicMaterial({ color: 0xFE0386 }));
      edges.position.copy(bed.position); printG.add(edges);
      for (const it of pl.items) {
        const O = it.obj, P = rotPart(O, it.rot), Q = new Float32Array(P.length);
        for (let i = 0; i < P.length; i += 3) { Q[i] = P[i] + it.x; Q[i + 1] = P[i + 1] + it.y; Q[i + 2] = P[i + 2]; }
        const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.BufferAttribute(Q, 3)); g.setIndex(new THREE.BufferAttribute(O.print.indices, 1));
        const ng = g.toNonIndexed(); ng.computeVertexNormals();
        // steep downward faces above the bed are amber: overhangs to look at
        const pos = ng.attributes.position.array, nor = ng.attributes.normal.array, col = new Float32Array(pos.length);
        const base = new THREE.Color(colOfSlot(pl.slot || slotOf(O.role))).convertSRGBToLinear(), warn = new THREE.Color('#ffb020').convertSRGBToLinear();
        for (let f = 0; f < pos.length; f += 9) {
          const ux = pos[f + 3] - pos[f], uy = pos[f + 4] - pos[f + 1], uz = pos[f + 5] - pos[f + 2], vx = pos[f + 6] - pos[f], vy = pos[f + 7] - pos[f + 1], vz = pos[f + 8] - pos[f + 2];
          const nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx, l = Math.hypot(nx, ny, nz) || 1;
          const c = (nz / l < -0.74 && Math.min(pos[f + 2], pos[f + 5], pos[f + 8]) > 0.4) ? warn : base;
          for (let k = 0; k < 3; k++) { col[f + k * 3] = c.r; col[f + k * 3 + 1] = c.g; col[f + k * 3 + 2] = c.b; }
        }
        void nor;
        ng.setAttribute('color', new THREE.BufferAttribute(col, 3));
        const mesh = new THREE.Mesh(ng, new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.6, side: THREE.DoubleSide }));
        mesh.castShadow = true; printG.add(mesh);
      }
      $('#plName').textContent = pl.label + '  (' + (Math.min(ST.ui.plate, plates.length - 1) + 1) + ' of ' + plates.length + ')';
    }
    VIEW.plates = () => plates;
    VIEW.showPlate = i => { ST.ui.plate = (i + plates.length) % plates.length; buildPrint(R); VIEW.fit(); };
    VIEW.fit = function () {
      const box = new THREE.Box3();
      if (ST.ui.mode === 'print') box.setFromObject(printG);
      else for (const c of asm.children) box.expandByObject(c);
      if (box.isEmpty()) return;
      const c = box.getCenter(new THREE.Vector3()), s = box.getSize(new THREE.Vector3()).length();
      orbit.target.copy(c); orbit.r = s * (ST.ui.mode === 'print' ? 1.5 : 1.85); applyCam();
    };
    let expT = 0, expGoal = 0;
    VIEW.apply = function () {
      const ui = ST.ui, pr = ui.mode === 'print';
      printG.visible = pr; asm.visible = !pr;
      expGoal = ui.mode === 'explode' ? 1 : 0;
      hwG.visible = ui.hw; boardG.visible = ui.board && !pr && ui.mode !== 'explode';
      for (const m of jawPivot.children) if (m.userData && m.userData.hw) m.visible = ui.hw;
      clip.constant = ui.section ? ui.secX : 1e5;
      for (const m of parts) {
        const O = m.userData.O, x = ui.xray && !['mount', 'pivot pin', 'hook L', 'hook R'].includes(O.name);
        m.material.transparent = x; m.material.opacity = x ? 0.2 : 1; m.material.depthWrite = !x; m.material.needsUpdate = true;
        m.castShadow = !x;
      }
      $('#secbar').classList.toggle('on', ui.section && !pr);
      $('#platebar').classList.toggle('on', pr);
      $('#jawbar').style.display = pr ? 'none' : '';
    };
    VIEW.legend = function () {
      if (!R) return;
      const rows = [];
      if (ST.ui.mode === 'print' || !ST.ui.paint) {
        const used = {}; for (const O of R.objects) used[slotOf(O.role)] = 1;
        for (const s in used) rows.push('<div>' + ((ST.slots[s - 1] || {}).name || 'slot ' + s) + ' / slot ' + s + ' <i style="background:' + colOfSlot(+s) + '"></i></div>');
        if (ST.ui.mode === 'print') rows.push('<div>overhang <i style="background:#ffb020"></i></div>');
      } else rows.push('<div>paint guide</div>');
      $('#legend').innerHTML = rows.join('');
    };
    VIEW.jaw = 0; VIEW.paused = false;
    function loop() {
      expT += (expGoal - expT) * 0.16;
      if (R) for (const k in objG) {
        const { g, O } = objG[k], e = O.ex || [0, 0, 0];
        if (k === 'jaw') jawPivot.position.set(R.info.hinge[0] + e[0] * expT, R.info.hinge[1] + e[1] * expT, R.info.hinge[2] + e[2] * expT);
        else g.position.set(e[0] * expT, e[1] * expT, e[2] * expT);
      }
      jawPivot.rotation.x = -VIEW.jaw * D2R;
      if (!VIEW.paused) renderer.render(scene, cam);
      requestAnimationFrame(loop);
    }
    resize(); applyCam(); requestAnimationFrame(loop);
    VIEW.snapshot = (w, h) => { const ow = cv.width, oh = cv.height; if (w) { renderer.setSize(w, h, false); cam.aspect = w / h; cam.updateProjectionMatrix(); } renderer.render(scene, cam); const url = cv.toDataURL('image/png'); if (w) { renderer.setSize(ow / renderer.getPixelRatio(), oh / renderer.getPixelRatio(), false); resize(); } return url; };
    VIEW.camState = () => ({ ...orbit, target: orbit.target.clone() });
    VIEW.setCam = s => { orbit.theta = s.theta; orbit.phi = s.phi; orbit.r = s.r; orbit.target.copy(s.target); applyCam(); };
    VIEW.resize = resize;
    VIEW.pose = (theta, phi) => { orbit.theta = theta; orbit.phi = phi; applyCam(); };
  })();

  /* ---------------------------------------------------------------- plates */
  const PLATES = {
    groups(R) {
      // per filament: one group per slot; one colour: a single group
      const g = {};
      for (const O of R.objects) { const s = slotOf(O.role); (g[s] = g[s] || []).push(O); }
      return Object.keys(g).map(s => ({ slot: +s, objs: g[s] }));
    },
    layout(R) {
      const key = [ST.print.bedW, ST.print.bedD, ST.print.mode, JSON.stringify(ST.roles)].join('|');
      if (PLATES._R === R && PLATES._k === key) return PLATES._v;
      const v = PLATES.layout0(R); PLATES._R = R; PLATES._k = key; PLATES._v = v; return v;
    },
    layout0(R) {
      // nest every group on the real part footprints; one colour mode packs everything onto as few beds as it can
      const out = [];
      for (const grp of PLATES.groups(R)) {
        const plates = BUCK.pack(grp.objs, ST.print.bedW, ST.print.bedD, { gap: 4, margin: 5 });
        const nm = single() ? 'all parts' : ((ST.slots[grp.slot - 1] || {}).name || 'slot ' + grp.slot);
        plates.forEach((pl, i) => { pl.slot = grp.slot; pl.label = nm + (plates.length > 1 ? ' ' + (i + 1) : ''); out.push(pl); });
      }
      return out;
    }
  };

  /* ---------------------------------------------------------------- exports */
  function filamentsFor(slots) { return slots.map(s => { const f = ST.slots[s - 1] || ST.slots[0]; return { color: f.color, type: f.type, name: f.name }; }); }
  function rotPart(O, rot) { const a = (rot === true ? 90 : +rot || 0) * Math.PI / 180; if (!a) return O.print.positions; const c = Math.cos(a), s = Math.sin(a), P = O.print.positions, Q = new Float32Array(P.length); for (let i = 0; i < P.length; i += 3) { Q[i] = P[i] * c - P[i + 1] * s; Q[i + 1] = P[i] * s + P[i + 1] * c; Q[i + 2] = P[i + 2]; } return Q; }
  function pkg(items, title, slots) {
    const map = {}; slots.forEach((s, i) => map[s] = i + 1);
    return Orca3MF.build({
      filaments: filamentsFor(slots),
      printer: { printer_settings_id: ST.print.printer || '', print_settings_id: ST.print.process || '' },
      presetPattern: ST.print.pattern || undefined, writeFilaments: ST.print.writeFilaments, layerHeight: +ST.print.layer, title,
      objects: items.map(it => ({ name: it.obj.name, positions: [[it.x, it.y, 0]], parts: [{ name: it.obj.name, slot: map[slotOf(it.obj.role)] || 1, positions: rotPart(it.obj, it.rot), indices: it.obj.print.indices }] }))
    });
  }
  const stamp = () => 'buck-' + (ST.preset || 'custom');
  const fileSafe = s => s.replace(/\s+/g, '-').toLowerCase();
  async function exportPlates() {
    await ensureFine();
    const plates = PLATES.layout(R);
    VIEW.paused = true;
    try {
      const files = [];
      for (let i = 0; i < plates.length; i++) files.push([stamp() + '-' + fileSafe(plates[i].label) + '.3mf', await pkg(plates[i].items, 'BUCK ' + plates[i].label, [plates[i].slot]).zip()]);
      return files;
    } finally { VIEW.paused = false; }
  }
  async function exportParts() {
    await ensureFine(); VIEW.paused = true;
    try {
      const files = [];
      for (const O of R.objects) files.push([stamp() + '-' + fileSafe(O.name) + '.3mf', await pkg([{ obj: O, x: ST.print.bedW / 2, y: ST.print.bedD / 2 }], 'BUCK ' + O.name, [slotOf(O.role)]).zip()]);
      return files;
    } finally { VIEW.paused = false; }
  }
  async function exportStl() {
    await ensureFine(); VIEW.paused = true;
    try {
      const z = new JSZip();
      for (const O of R.objects) z.file('stl/' + fileSafe(O.name) + '__' + fileSafe((ST.slots[slotOf(O.role) - 1] || {}).name || 'slot') + '.stl', Orca3MF.stl(O.print, O.name));
      z.file('print-card.txt', printCard());
      z.file('design.json', JSON.stringify({ app: 'buck-bench', v: 2, state: design() }, null, 1));
      return await z.generateAsync({ type: 'blob', compression: 'DEFLATE' });
    } finally { VIEW.paused = false; }
  }
  async function zipFiles(files, extra) { const z = new JSZip(); for (const [n, b] of files) z.file(n, b); z.file('print-card.txt', printCard()); if (extra) for (const [n, b] of extra) z.file(n, b); return z.generateAsync({ type: 'blob', compression: 'DEFLATE' }); }
  async function save(name, data, mime) {
    const blob = data instanceof Blob ? data : new Blob([data], { type: mime || 'application/octet-stream' });
    const ext = name.split('.').pop().toLowerCase();
    if (window.claude && typeof window.claude.use === 'function') {
      try {
        const dl = await window.claude.use('downloads');
        if (dl) {
          let fn = name, out = blob;
          if (!/^(zip|txt|json|png)$/.test(ext)) { const z = new JSZip(); z.file(name, blob); out = await z.generateAsync({ type: 'blob', compression: 'DEFLATE' }); fn = name + '.zip'; }
          await dl.save({ filename: fn, data: out }); UI.status('saved ' + fn, 'ok'); return;
        }
      } catch (e) { UI.status('download ' + (e && e.code || 'failed'), 'warn'); return; }
    }
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name; document.body.appendChild(a); a.click();
    setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1500);
  }

  /* ---------------------------------------------------------------- text: print card, hardware, assembly, wiring */
  const ORIENT = { head: 'neck rim on the bed', jaw: 'mouth face on the bed', mount: 'flat back on the bed', nose: 'cut face on the bed', eye: 'flat back on the bed, dome up', antler: 'flat side on the bed', ear: 'lying on its flat back, cup up', 'pivot pin': 'on its flat', hook: 'on its side' };
  const orientOf = n => ORIENT[n] || ORIENT[n.split(' ')[0]] || 'as exported';
  function printCard() {
    const L = ['BUCK PRINT CARD', '========================================', 'printer : ' + (ST.print.printer || '(unchanged)'), 'process : ' + (ST.print.process || '(unchanged)'), 'layer   : ' + (+ST.print.layer).toFixed(2) + ' mm', 'mode    : ' + (single() ? 'one colour, paint after' : 'one filament per plate'), '', 'PLATES'];
    const plates = PLATES.layout(R);
    plates.forEach((pl, i) => { const f = ST.slots[pl.slot - 1] || {}; let g = 0; for (const it of pl.items) g += it.obj.print.volume / 1000 * ((Orca3MF.MATERIALS[f.type] || { density: 1.27 }).density) * 0.6; L.push('  ' + (i + 1) + '. ' + pl.label + ' (' + f.type + ' ' + f.color + ', about ' + g.toFixed(0) + ' g at 40 percent infill): ' + pl.items.map(it => it.obj.name).join(', ')); });
    L.push('', 'ORIENTATION (no supports anywhere)');
    for (const O of R.objects) L.push('  ' + O.name.padEnd(10) + ': ' + orientOf(O.name));
    L.push('', 'FITS', '  eyes press into their sockets with ' + ST.eyes.fit.toFixed(2) + ' mm design clearance; a drop of CA if loose', '  nose cap presses onto the muzzle peg; ears and antlers press into keyed sockets (0.20 mm per side)', (ST.mount.attach === 'snap' ? '  head snaps over the plaque lip, ' + ST.mount.snap.toFixed(2) + ' mm bead overlap on each flank' : '  head slides over the plaque lip (0.5 mm gap) and is held by 3 x M3 x 16 flat head screws from the back into 2.5 mm pilots, 11 mm deep'), '',
      'HARDWARE', ...bomRows().map(r => '  ' + (r[0] + '').padEnd(3) + r[1]), '', 'ASSEMBLY', ...assemblySteps().map((s, i) => '  ' + (i + 1) + '. ' + s), '', 'WIRING', ...wiringRows().map(r => '  ' + r[0] + ' -> ' + r[1]), '',
      'fallback if a 3MF imports with one filament: open the STLs from the STL zip instead; every part is a single body.');
    return L.join('\n') + '\n';
  }
  function bomRows() {
    const B = ST.board.type === 'CUSTOM' ? 'custom controller' : BUCK.HW.board[ST.board.type].name, A = BUCK.HW.amp.NS4168.name, sp = ST.speaker;
    return [['1', 'SG90 or MG90S 9 g servo, its single arm horn and its two mounting screws (the horn screw is optional)'], ['1', B + ', stuck down with foam tape or hot glue'], ['1', A], ['1', 'the kit speaker: ' + sp.frame + ' mm square frame, ears ' + sp.span + ' mm apart, ' + sp.depth + ' mm deep'],
      ['2', 'M3 x 6 screws for the amp (self tapping, or a machine screw that cuts its own thread), with M3 washers'], ['2', 'M2 x 6 self tapping screws for the speaker ears (or #2 x 1/4 in)'], ...(ST.mount.attach === 'snap' ? [] : [['3', 'M3 x 16 flat head (countersunk) screws, self tapping or machine, to hold the head to the plaque (or #4 x 5/8 in flat head wood screws)']]), ['1', 'USB-C cable'], ['', 'hookup wire and the kit\'s PH2.0 leads']];
  }
  function assemblySteps() {
    const s = [];
    if (ST.eyes.mode === 'separate') s.push('press the eyes into their sockets, pointed corner toward the nose');
    if (ST.nose.mode === 'separate') s.push('press the nose cap onto the peg at the end of the muzzle');
    s.push('press the ears' + (ST.antlers.style !== 'none' ? ' and antlers' : '') + ' into their keyed sockets');
    s.push('screw the servo to the fin with its own two screws, gear tower toward the right cheek; leave the horn off');
    s.push('slide the speaker in under the amp shelf from the right side (the servo horn side): lift it over the seat ring, push it back against the stop and drop it; screw both ears down through the holes in the shelf');
    s.push('slide the NS4168 in from the same side, components up, input connector leading; drop it onto the two spigots and screw it down with two M3 x 6 and washers, then plug in the speaker lead');
    s.push('stick the controller onto the plinth on the left face of the fin, USB toward the plaque; the plinth is narrower than the pin rows, so every pin stays free. Wire it, and tuck the leads through the slot in the fin');
    s.push('feed the USB-C cable through the plaque slot into the controller and lay it in the groove on the back');
    if (ST.mount.attach === 'snap') s.push('slide the head over the fin until it snaps onto the lip');
    else s.push('slide the head over the fin onto the locating lip, then drive the three M3 x 16 flat head screws in from the back of the plaque until they sit flush. To take the head off later: slide the plaque off its hooks and undo those three screws');
    s.push('drive the servo to its closed angle, reach in through the mouth and press the horn onto the spline pointing forward and down');
    s.push('slide the jaw up and back through the mouth so its right arm takes the horn, then push the pivot pin in through the left cheek until it clicks');
    if (ST.mount.hang === 'hooks') s.push('roll the two printed hooks into the pegboard ' + ST.mount.pitchIn + ' inches apart, then slide the plaque onto them from the side');
    else if (ST.mount.hang === 'holes') s.push('hang the plaque on two straight peghooks ' + ST.mount.pitchIn + ' inches apart');
    return s;
  }
  function wiringRows() {
    if (ST.board.type === 'RP2040Z') return [['servo signal', 'GP2'], ['servo +', '5V (USB)'], ['amp V', '5V'], ['amp G, servo -', 'GND'], ['amp BCLK', 'GP6'], ['amp LRCLK', 'GP7 (PIO I2S wants it right after BCLK)'], ['amp DIN', 'GP8'], ['speaker', 'its PH2.0 plug into the amp; the output is bridge tied, never tie either leg to GND']];
    return [['servo signal', 'GPIO 7'], ['servo +', '5V (USB)'], ['amp V', '5V'], ['amp G, servo -', 'GND'], ['amp BCLK', 'GPIO 5'], ['amp LRCLK', 'GPIO 6'], ['amp DIN', 'GPIO 4'], ['speaker', 'its PH2.0 plug into the amp; the output is bridge tied, never tie either leg to GND']];
  }

  /* paint guide image: front and side in the paint view with the colour key */
  async function paintGuide() {
    const prev = { mode: ST.ui.mode, paint: ST.ui.paint, xray: ST.ui.xray, section: ST.ui.section, hw: ST.ui.hw, board: ST.ui.board }, cs = VIEW.camState();
    Object.assign(ST.ui, { mode: 'assembled', paint: true, xray: false, section: false, hw: false, board: false });
    VIEW.restyle(); VIEW.fit();
    const shots = [];
    for (const [th, ph] of [[Math.PI, 0.06], [Math.PI / 2, 0.04], [2.3, 0.28]]) { VIEW.pose(th, ph); shots.push(VIEW.snapshot(900, 900)); }
    Object.assign(ST.ui, prev); VIEW.restyle(); VIEW.setCam(cs);
    const c = document.createElement('canvas'); c.width = 2700; c.height = 1180; const x = c.getContext('2d');
    x.fillStyle = '#f5f0e6'; x.fillRect(0, 0, c.width, c.height);
    for (let i = 0; i < 3; i++) { const im = new Image(); im.src = shots[i]; await im.decode(); x.drawImage(im, i * 900, 60); }
    x.fillStyle = '#1a1a1a'; x.font = '44px "Permanent Marker", cursive'; x.fillText('BUCK paint guide', 30, 52);
    const P = BUCKSDF.PAL, key = [['coat', P.coat], ['saddle, forehead', P.coatDark], ['neck, ear backs', P.coatGrey], ['white: muzzle band, chin, eye ring, throat', P.white], ['black: nose, eyes, lid line', P.black], ['lips, mouth', P.mouth]];
    x.font = '26px "IBM Plex Mono", monospace';
    key.forEach(([nm, cc], i) => { const px = 30 + (i % 3) * 880, py = 1000 + Math.floor(i / 3) * 70; x.fillStyle = 'rgb(' + cc.map(v => v * 255 | 0).join(',') + ')'; x.fillRect(px, py, 50, 50); x.strokeStyle = '#1a1a1a'; x.strokeRect(px, py, 50, 50); x.fillStyle = '#1a1a1a'; x.fillText(nm, px + 66, py + 35); });
    return await new Promise(r => c.toBlob(r, 'image/png'));
  }

  // test hook
  globalThis.BENCH = {
    state: () => ST, result: () => R, view: VIEW,
    preset: k => { applyPreset(k); UI.refresh(); R = BUCK.build(M, ST, CACHE); builtRev = rev; freshQ = ST.print.quality; VIEW.setResult(R); UI.afterBuild(); return R.info; },
    set: (path, v) => { setP(path, v); UI.refresh(); rev++; },
    exportBytes: async kind => {
      let blob;
      if (kind === '3mf') { const f = await exportPlates(); blob = f.length === 1 ? f[0][1] : await zipFiles(f); }
      else if (kind === '3mf0') blob = (await exportPlates())[0][1];
      else if (kind === 'parts') blob = await zipFiles(await exportParts());
      else if (kind === 'stl') blob = await exportStl();
      else if (kind === 'card') blob = new Blob([printCard()]);
      else if (kind === 'paint') blob = await paintGuide();
      else if (kind === 'json') blob = new Blob([JSON.stringify({ app: 'buck-bench', v: 2, state: design() })]);
      const b = new Uint8Array(await blob.arrayBuffer()); let s = ''; for (let i = 0; i < b.length; i += 0x8000) s += String.fromCharCode.apply(null, b.subarray(i, i + 0x8000)); return btoa(s);
    },
    view: VIEW, ready: false
  };

  /* ---------------------------------------------------------------- talk */
  const TALK = { raf: 0, mic: null };
  function setJaw(deg) { VIEW.jaw = Math.max(0, Math.min(ST.jaw.open, deg)); $('#jawA').value = Math.round(VIEW.jaw / ST.jaw.open * 100); $('#jawV').textContent = VIEW.jaw.toFixed(0) + ' deg'; }
  function stopTalk() { cancelAnimationFrame(TALK.raf); TALK.raf = 0; try { speechSynthesis.cancel(); } catch (_) { } $('#bSay').classList.remove('on'); }
  function syllables(text) {
    const ev = []; let t = 0;
    for (const w of text.split(/(\s+|[,.!?;:])/)) {
      if (!w || /^\s+$/.test(w)) { t += 0.06; continue; }
      if (/[,.!?;:]/.test(w)) { t += 0.28; continue; }
      const n = Math.max(1, (w.toLowerCase().match(/[aeiouy]+/g) || []).length);
      for (let i = 0; i < n; i++) { ev.push([t, 0.55 + 0.45 * Math.random()]); t += 0.19; }
    }
    return { ev, dur: t + 0.2 };
  }
  function talk() {
    stopTalk();
    const text = $('#sayText').value || 'hello', env = syllables(text);
    try { const u = new SpeechSynthesisUtterance(text); u.rate = 1.0; u.pitch = 0.75; u.onboundary = () => { TALK.boost = performance.now(); }; speechSynthesis.speak(u); } catch (_) { }
    const t0 = performance.now(); $('#bSay').classList.add('on');
    const step = () => {
      const t = (performance.now() - t0) / 1000; let a = 0;
      for (const [te, amp] of env.ev) { const d = t - te; if (d > -0.05 && d < 0.2) a = Math.max(a, amp * Math.sin(Math.max(0, d + 0.05) / 0.25 * Math.PI)); }
      if (TALK.boost && performance.now() - TALK.boost < 140) a = Math.max(a, 0.8);
      setJaw(a * ST.jaw.open);
      if (t < env.dur || (window.speechSynthesis && speechSynthesis.speaking)) TALK.raf = requestAnimationFrame(step); else { setJaw(0); $('#bSay').classList.remove('on'); TALK.raf = 0; }
    };
    TALK.raf = requestAnimationFrame(step);
  }
  async function mic() {
    if (TALK.mic) { TALK.mic.stop(); TALK.mic = null; $('#bMic').classList.remove('on'); setJaw(0); return; }
    try {
      const s = await navigator.mediaDevices.getUserMedia({ audio: true });
      const ac = new (window.AudioContext || window.webkitAudioContext)(), an = ac.createAnalyser(); an.fftSize = 1024; ac.createMediaStreamSource(s).connect(an);
      const buf = new Float32Array(an.fftSize); let lev = 0, run = true;
      TALK.mic = { stop: () => { run = false; s.getTracks().forEach(t => t.stop()); ac.close(); } };
      $('#bMic').classList.add('on');
      const step = () => { if (!run) return; an.getFloatTimeDomainData(buf); let r = 0; for (const v of buf) r += v * v; r = Math.sqrt(r / buf.length); lev += ((r > 0.015 ? Math.min(1, r * 9) : 0) - lev) * 0.35; setJaw(lev * ST.jaw.open); requestAnimationFrame(step); };
      step();
    } catch (e) { UI.status('microphone not available here', 'warn'); }
  }
  function wiggle() { stopTalk(); const t0 = performance.now(); const step = () => { const t = (performance.now() - t0) / 1000; setJaw((0.5 - 0.5 * Math.cos(t * 2 * Math.PI * 0.8)) * ST.jaw.open); if (t < 2.5) TALK.raf = requestAnimationFrame(step); else setJaw(0); }; TALK.raf = requestAnimationFrame(step); }

  /* ---------------------------------------------------------------- UI */
  const UI = {};
  const GUIDE = [
    ['STEP 1 HEAD', 'shape the head and choose how the eyes, nose, antlers and ears are made. sliders rebuild on release and rerun the fit audit.'],
    ['STEP 2 GUTS', 'set the jaw swing, the boards and the speaker. drag the jaw slider or hit talk to watch the mouth.'],
    ['STEP 3 MOUNT', 'size the plaque and choose how it hangs. the pegboard behind it is to scale on a 1 inch grid.'],
    ['STEP 4 PRINT', 'read the audit, assign filaments, check each plate in print bed view, export. amber faces on the bed are overhangs.']];
  function getP(path) { return path.split('.').reduce((o, k) => (o == null ? o : o[k]), ST); }
  function setP(path, v) { const ks = path.split('.'), last = ks.pop(); const o = ks.reduce((a, k) => a[k], ST); o[last] = v; }
  function go(step) {
    ST.ui.step = step;
    $$('#steps button').forEach((b, i) => { b.classList.toggle('on', i === step); if (i < step) b.classList.add('done'); });
    $$('.pane').forEach((p, i) => p.classList.toggle('on', i === step));
    $('#guideHead').textContent = GUIDE[step][0]; $('#guideText').textContent = GUIDE[step][1];
  }
  UI.status = function (msg, kind) { const c = $('#sChips'); const el = document.createElement('span'); el.className = 'c ' + (kind || ''); el.textContent = msg; c.prepend(el); setTimeout(() => el.remove(), 6000); };
  function bindAll() {
    $$('[data-p]').forEach(el => {
      const p = el.dataset.p, isNum = el.type === 'range' || el.type === 'number';
      el.addEventListener('input', () => {
        if (!isNum) return;
        const v = parseFloat(el.value); if (!isFinite(v)) return;
        setP(p, v); $$('[data-p="' + p + '"]').forEach(o => { if (o !== el) o.value = v; });
      });
      el.addEventListener('change', () => {
        let v;
        if (el.type === 'checkbox') v = el.checked;
        else if (isNum || /print\.layer/.test(p)) { v = parseFloat(el.value); if (!isFinite(v)) return; }
        else v = el.value;
        setP(p, v); $$('[data-p="' + p + '"]').forEach(o => { if (o !== el && o.type !== 'checkbox') o.value = v; });
        if (/^print\.(bedW|bedD)$/.test(p)) { VIEW.setResult(R); UI.afterBuild(); snapshot(); return; }
        if (/^print\.(printer|process|pattern|writeFilaments|layer)$/.test(p)) { snapshot(); return; }
        UI.toggles(); commit();
      });
    });
    const chipGroup = (sel, path, after) => $$(sel + ' .chip').forEach(b => b.addEventListener('click', () => { setP(path, b.dataset.v); UI.refresh(); if (after) after(); else commit(); }));
    chipGroup('#antStyle', 'antlers.style'); chipGroup('#eyeMode', 'eyes.mode'); chipGroup('#noseMode', 'nose.mode'); chipGroup('#plShape', 'mount.shape'); chipGroup('#plEdge', 'mount.edge');
    chipGroup('#hangMode', 'mount.hang'); chipGroup('#attach', 'mount.attach'); chipGroup('#jawShell', 'jaw.shell'); chipGroup('#pegBoard', 'mount.board'); chipGroup('#qual', 'print.quality');
    chipGroup('#printMode', 'print.mode', () => { ST.ui.plate = 0; VIEW.restyle(); UI.afterBuild(); snapshot(); });
    $$('#steps button').forEach(b => b.addEventListener('click', () => go(+b.dataset.step)));
    $$('[data-go]').forEach(b => b.addEventListener('click', () => go(+b.dataset.go)));
    $$('#cams button').forEach(b => b.addEventListener('click', () => { $$('#cams button').forEach(x => x.classList.toggle('on', x === b)); VIEW.preset(b.dataset.cam); }));
    $$('#modes [data-mode]').forEach(b => b.addEventListener('click', () => { ST.ui.mode = b.dataset.mode; $$('#modes [data-mode]').forEach(x => x.classList.toggle('on', x === b)); VIEW.apply(); VIEW.legend(); VIEW.fit(); }));
    $$('#modes [data-tog]').forEach(b => b.addEventListener('click', () => { const k = b.dataset.tog; ST.ui[k] = !ST.ui[k]; b.classList.toggle('on', ST.ui[k]); if (k === 'section' && ST.ui.section) VIEW.preset('side'); if (k === 'paint') VIEW.restyle(); else VIEW.apply(); }));
    $('#plPrev').addEventListener('click', () => VIEW.showPlate(ST.ui.plate - 1));
    $('#plNext').addEventListener('click', () => VIEW.showPlate(ST.ui.plate + 1));
    $('#secX').addEventListener('input', e => { ST.ui.secX = parseFloat(e.target.value); $('#secV').textContent = ST.ui.secX.toFixed(1); VIEW.apply(); });
    $('#jawA').addEventListener('input', e => { stopTalk(); setJaw(parseFloat(e.target.value) / 100 * ST.jaw.open); });
    $('#bSay').addEventListener('click', talk); $('#bMic').addEventListener('click', mic); $('#bWiggle').addEventListener('click', wiggle);
    $('#bUndo').addEventListener('click', undo); $('#bRedo').addEventListener('click', redo);
    window.addEventListener('keydown', e => { const t = document.activeElement; if (t && /INPUT|SELECT|TEXTAREA/.test(t.tagName) && t.type !== 'range') return; if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z') { e.preventDefault(); e.shiftKey ? redo() : undo(); } else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'y') { e.preventDefault(); redo(); } });
    $('#bSave').addEventListener('click', () => save(stamp() + '.json', JSON.stringify({ app: 'buck-bench', v: 2, state: design() }, null, 1), 'application/json'));
    $('#bOpen').addEventListener('click', () => $('#fOpen').click());
    $('#fOpen').addEventListener('change', e => { const f = e.target.files[0]; if (!f) return; f.text().then(loadDesign); e.target.value = ''; });
    document.addEventListener('dragover', e => e.preventDefault());
    document.addEventListener('drop', e => { e.preventDefault(); const f = e.dataTransfer.files[0]; if (f && /json/.test(f.type + f.name)) f.text().then(loadDesign); });
    $('#bGuide').addEventListener('click', () => $('#welcome').classList.remove('hide'));
    $$('#presetBtns [data-preset]').forEach(b => b.addEventListener('click', () => { applyPreset(b.dataset.preset); VIEW._fitted = false; $('#welcome').classList.add('hide'); UI.refresh(); rev++; snapshot(); schedule(0); }));
    $$('[data-role]').forEach(sel => sel.addEventListener('change', () => { ST.roles[sel.dataset.role] = +sel.value; VIEW.restyle(); UI.afterBuild(); snapshot(); }));
    $('#b3mf').addEventListener('click', async () => { UI.status('exporting', ''); const f = await exportPlates(); if (f.length === 1) await save(f[0][0], f[0][1]); else await save(stamp() + '-plates.zip', await zipFiles(f)); });
    $('#b3mfParts').addEventListener('click', async () => { UI.status('exporting', ''); await save(stamp() + '-parts.zip', await zipFiles(await exportParts())); });
    $('#bStl').addEventListener('click', async () => { UI.status('exporting', ''); await save(stamp() + '-stl.zip', await exportStl()); });
    $('#bCard').addEventListener('click', () => save(stamp() + '-print-card.txt', printCard(), 'text/plain'));
    $('#bPaint').addEventListener('click', async () => save(stamp() + '-paint-guide.png', await paintGuide(), 'image/png'));
  }
  function loadDesign(txt) {
    try { const j = JSON.parse(txt); const s = j.state || j; const ui = ST.ui; ST = merge(BUCK.defaults(), s); ST.ui = ui; VIEW._fitted = false; UI.refresh(); rev++; snapshot(); schedule(0); $('#welcome').classList.add('hide'); }
    catch (e) { UI.status('could not read that design file', 'err'); }
  }
  function renderSlots() {
    const box = $('#slots'); box.innerHTML = '';
    const n = single() ? 1 : ST.slots.length;
    for (let i = 0; i < n; i++) {
      const s = ST.slots[i], d = document.createElement('div'); d.className = 'slot';
      d.innerHTML = '<span class="n">' + (i + 1) + '</span><input type="color" value="' + s.color + '" aria-label="slot ' + (i + 1) + ' colour"><input type="text" value="' + s.name + '" aria-label="slot ' + (i + 1) + ' name"><select aria-label="slot ' + (i + 1) + ' material">' + ['PLA', 'PETG', 'ABS', 'ASA', 'TPU'].map(t => '<option' + (t === s.type ? ' selected' : '') + '>' + t + '</option>').join('') + '</select>';
      const [c, t, m] = d.querySelectorAll('input[type=color],input[type=text],select');
      c.addEventListener('input', () => { s.color = c.value.toUpperCase(); VIEW.restyle(); });
      c.addEventListener('change', snapshot);
      t.addEventListener('change', () => { s.name = t.value; snapshot(); UI.refresh(); VIEW.legend(); });
      m.addEventListener('change', () => { s.type = m.value; snapshot(); UI.afterBuild(); });
      box.appendChild(d);
    }
    $('#roleRows').style.display = single() ? 'none' : '';
    $$('[data-role]').forEach(sel => { sel.innerHTML = ST.slots.map((s, i) => '<option value="' + (i + 1) + '">' + (i + 1) + ' ' + s.name + '</option>').join(''); sel.value = ST.roles[sel.dataset.role]; });
  }
  UI.toggles = function () {
    $('#rowBoardC').style.display = ST.board.type === 'CUSTOM' ? '' : 'none';
    $('#rowHole').style.display = ST.mount.hang === 'holes' ? '' : 'none';
    $('#rowSnap').style.display = ST.mount.attach === 'snap' ? '' : 'none';
    $('#rowJawWall').style.display = ST.jaw.shell === 'solid' ? 'none' : '';
  };
  UI.refresh = function () {
    $$('[data-p]').forEach(el => { const v = getP(el.dataset.p); if (el.type === 'checkbox') el.checked = !!v; else if (v !== undefined) el.value = v; });
    const chip = (sel, v) => $$(sel + ' .chip').forEach(b => b.classList.toggle('on', b.dataset.v === v));
    chip('#antStyle', ST.antlers.style); chip('#eyeMode', ST.eyes.mode); chip('#noseMode', ST.nose.mode); chip('#plShape', ST.mount.shape); chip('#plEdge', ST.mount.edge);
    chip('#hangMode', ST.mount.hang); chip('#attach', ST.mount.attach); chip('#jawShell', ST.jaw.shell || 'channel'); chip('#pegBoard', ST.mount.board); chip('#qual', ST.print.quality); chip('#printMode', ST.print.mode);
    renderSlots(); UI.toggles();
    $('#wiring').innerHTML = wiringRows().map(r => '<tr><td>' + r[0] + '</td><td>' + r[1] + '</td></tr>').join('');
    $('#bom').innerHTML = bomRows().map(r => '<tr><td>' + r[0] + '</td><td>' + r[1] + '</td></tr>').join('');
    $('#asm').innerHTML = assemblySteps().map(s => '<li>' + s + '</li>').join('');
    if (R) VIEW.legend();
  };
  UI.afterBuild = function () {
    const ck = $('#checks'), rows = [];
    for (const e of R.errs) rows.push('<div class="bad"><b>FIX</b><span>' + e + '</span></div>');
    for (const c of R.checks) rows.push('<div class="' + (c.ok ? 'ok' : 'bad') + '"><b>' + (c.ok ? 'OK' : 'HIT') + '</b><span>' + c.k + (c.ok ? '' : ' (' + c.v.toFixed(2) + (c.unit ? ' mm' : ' mm3') + ')') + '</span></div>');
    for (const n of R.notes) rows.push('<div class="ok"><b>INFO</b><span>' + n + '</span></div>');
    ck.innerHTML = rows.join('');
    const plates = PLATES.layout(R);
    let tris = 0; for (const O of R.objects) tris += O.world.tris;
    const ro = ['<div>plates</div><span>' + plates.length + ' on ' + ST.print.bedW + ' x ' + ST.print.bedD + '</span>'];
    const grams = {}; for (const O of R.objects) { const s = slotOf(O.role), f = ST.slots[s - 1] || {}; grams[s] = (grams[s] || 0) + O.print.volume / 1000 * ((Orca3MF.MATERIALS[f.type] || { density: 1.27 }).density) * 0.6; }
    for (const s in grams) ro.push('<div>' + ((ST.slots[s - 1] || {}).name || s) + '</div><span>~' + grams[s].toFixed(0) + ' g</span>');
    ro.push('<div>plaque</div><span>' + R.info.plaque.w.toFixed(0) + ' x ' + R.info.plaque.h.toFixed(0) + ' mm</span>');
    $('#readout').innerHTML = ro.join('');
    $('#partsT').innerHTML = R.objects.map(O => '<tr><td>' + O.name + '</td><td>' + O.size.map(v => v.toFixed(0)).join(' x ') + ' mm, ' + orientOf(O.name) + ', ' + ((ST.slots[slotOf(O.role) - 1] || {}).name || '') + '</td></tr>').join('');
    const head = R.objects.find(o => o.name === 'head');
    $('#sDims').textContent = 'head ' + head.size.map(v => v.toFixed(0)).join(' x ') + ' mm';
    $('#sTris').textContent = (tris / 1000).toFixed(0) + 'k tris';
    $('#sMs').textContent = R.info.ms + ' ms';
    const fails = R.checks.filter(c => !c.ok).length + R.errs.length;
    $('#sChips').innerHTML = '<span class="c ' + (fails ? 'err' : 'ok') + '">' + (fails ? fails + ' fit problem' + (fails > 1 ? 's' : '') : 'audit: ' + R.checks.length + ' checks pass') + '</span><span class="c ok">' + R.objects.length + ' parts</span><span class="c ' + (plates.length > (single() ? 1 : 4) ? 'warn' : 'ok') + '">' + plates.length + ' plate' + (plates.length > 1 ? 's' : '') + '</span><span class="c ' + (builtRev === rev ? 'ok' : 'warn') + '">' + (freshQ === 'fine' ? 'fine mesh' : 'draft mesh') + '</span>';
    const hs = R.objects.find(o => o.name === 'head').size[0];
    $('#secX').min = (-hs / 2 - 5).toFixed(0); $('#secX').max = (hs / 2 + 5).toFixed(0);
    globalThis.BENCH.ready = true;
  };

  /* ---------------------------------------------------------------- boot */
  (async function boot() {
    const sel = (id, tbl) => { $(id).innerHTML = Object.keys(tbl).map(k => '<option value="' + k + '">' + tbl[k].name + ' (' + tbl[k].L + ' x ' + tbl[k].W + ')</option>').join('') + '<option value="CUSTOM">custom</option>'; };
    sel('#p_board', BUCK.HW.board);
    bindAll(); go(0); UI.refresh();
    try {
      const b = atob(globalThis.BUCK_WASM_B64); const u = new Uint8Array(b.length); for (let i = 0; i < b.length; i++) u[i] = b.charCodeAt(i);
      M = await globalThis.ManifoldModule({ wasmBinary: u.buffer }); M.setup();
    } catch (e) { console.error(e); UI.status('geometry kernel failed to load: ' + (e && e.message || e), 'err'); return; }
    applyPreset('buck'); UI.refresh(); lastSnap = JSON.stringify(design());
    runBuild();
  })();
})();
