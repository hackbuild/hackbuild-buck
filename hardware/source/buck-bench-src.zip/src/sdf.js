/* BUCK head field, sculpted. Mounted frame: x right, y out of the wall, z up, mm.
 * d(x,y,z) > 0 outside, < 0 inside; close to a true distance near the surface.
 * The skull is modelled in an unscaled head frame and posed nose down by `tilt` about a pivot at the top of the neck.
 * Every landmark the engine needs (eyes, nose, mouth line, antler pedicles, ear roots) is published in that frame. */
(function (root) {
  'use strict';
  const sq = v => v * v;
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  function ell(px, py, pz, cx, cy, cz, rx, ry, rz) {
    const x = (px - cx) / rx, y = (py - cy) / ry, z = (pz - cz) / rz;
    const k0 = Math.sqrt(x * x + y * y + z * z);
    const k1 = Math.sqrt(x * x / (rx * rx) + y * y / (ry * ry) + z * z / (rz * rz));
    return k1 > 1e-9 ? k0 * (k0 - 1) / k1 : -Math.min(rx, ry, rz);
  }
  // round cone between a (radius ra) and b (radius rb), after Inigo Quilez
  function rcone(px, py, pz, ax, ay, az, bx, by, bz, ra, rb) {
    const bax = bx - ax, bay = by - ay, baz = bz - az;
    const l2 = bax * bax + bay * bay + baz * baz, rr = ra - rb, a2 = l2 - rr * rr, il2 = 1 / l2;
    const pax = px - ax, pay = py - ay, paz = pz - az;
    const y = pax * bax + pay * bay + paz * baz, z = y - l2;
    const xx = sq(pax * l2 - bax * y) + sq(pay * l2 - bay * y) + sq(paz * l2 - baz * y);
    const y2 = y * y * l2, z2 = z * z * l2;
    const k = Math.sign(rr) * rr * rr * xx;
    if (Math.sign(z) * a2 * z2 > k) return Math.sqrt(xx + z2) * il2 - rb;
    if (Math.sign(y) * a2 * y2 < k) return Math.sqrt(xx + y2) * il2 - ra;
    return (Math.sqrt(xx * a2 * il2) + y * rr) * il2 - ra;
  }
  function capsule(px, py, pz, ax, ay, az, bx, by, bz, r) {
    const pax = px - ax, pay = py - ay, paz = pz - az, bax = bx - ax, bay = by - ay, baz = bz - az;
    const h = clamp((pax * bax + pay * bay + paz * baz) / (bax * bax + bay * bay + baz * baz), 0, 1);
    return Math.hypot(pax - bax * h, pay - bay * h, paz - baz * h) - r;
  }
  function smin(a, b, k) { const h = Math.max(k - Math.abs(a - b), 0) / k; return Math.min(a, b) - h * h * k * 0.25; }
  function smax(a, b, k) { return -smin(-a, -b, k); }
  const norm = v => { const l = Math.hypot(v[0], v[1], v[2]) || 1; return [v[0] / l, v[1] / l, v[2] / l]; };
  const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
  const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];

  /* 2D almond (deer eye): a vesica, pointed at the nasal corner, rounder at the back. u along the eye, v up. */
  function almond2(u, v, a, b) {
    // blend a vesica (pointed) toward an ellipse for u < 0 so the back corner is soft
    const t = clamp(-u / a, 0, 1) * 0.55;
    const r = (a * a + b * b) / (2 * b), dd = r - b;
    const au = Math.abs(u), av = Math.abs(v);
    const ves = ((av + dd) * a > au * dd) ? Math.hypot(au, av + dd) - r : Math.hypot(au - a, av);
    const k = Math.hypot(u / a, v / b), elp = (k - 1) * Math.min(a, b);
    return ves * (1 - t) + elp * t;
  }

  /* shape: {s, muzzle, neck, crown, cheek, tilt, eye, eyeMode: 'separate'|'sculpted'} */
  function makeHead(shape) {
    const s = shape.s, mz = shape.muzzle, nk = shape.neck, cr = shape.crown, ck = shape.cheek || 1, es = shape.eye || 1;
    const t = (shape.tilt || 0) * Math.PI / 180, ct = Math.cos(t), st = Math.sin(t);
    const PY = 46, PZ = 6;
    const L = 47 * mz;                    // eye line to nose
    const yN = 70 + L;                    // nose bulb, head frame
    const F = { L, yN };
    function headLocal(y, z) { const dy = y - PY, dz = z - PZ; return [PY + dy * ct - dz * st, PZ + dy * st + dz * ct]; }
    function headWorld(y, z) { const dy = y - PY, dz = z - PZ; return [PY + dy * ct + dz * st, PZ - dy * st + dz * ct]; }

    /* ---- landmarks, unscaled head frame ---- */
    F.orbit = [19.8 * ck, 70.5, 18.5];
    F.muzA = [0, 74, 12]; F.muzB = [0, yN, 1.5];
    F.pedicle0 = [10.2 * cr, 60, 30 * cr];
    F.pedicleDir = norm([0.40, 0.02, 1]);
    F.earRoot0 = [14.5 * cr, 50, 27 * cr];
    F.earDir = norm([0.84, -0.26, 0.62]);
    F.throat = [0, 18, -31];
    F.commissure = [8.4, yN - 21, -2.2];

    // the skull without eyes or carvings: used to seat the eyes, and as the cavity field
    function skullBase(ax, y, z) {
      let d = ell(ax, y, z, 0, 51, 21, 22.5 * cr, 22, 18.5 * cr);                              // braincase
      d = smin(d, ell(ax, y, z, 0, 71, 24, 20, 18, 9.2), 10);                                    // broad flat forehead
      d = smin(d, ell(ax, y, z, F.orbit[0], F.orbit[1], F.orbit[2], 8.2, 11.5, 9.2), 7);         // orbits, widest point
      d = smin(d, rcone(ax, y, z, 17 * ck, 62, 8, 12, 89, 5, 6.0, 3.4), 6);                     // cheekbone
      d = smin(d, ell(ax, y, z, 14.4 * ck, 55, 0.5, 10.6, 14.5, 12.5), 8);                       // masseter: the widest part of the lower head
      d = smin(d, ell(ax, y, z, 11.5 * ck, 49, -9, 8, 10, 8), 7);                                // jowl, the angle of the jaw
      // muzzle: deep and laterally pinched, straight nasal bridge
      d = smin(d, rcone(ax / 0.74, y, z / 1.06, 0, 74, 11.5, 0, yN, 1.5, 16.2, 11.2) * 0.74, 10);
      d = smin(d, rcone(ax / 0.92, y, z, 0, 72, 23.5, 0, yN - 3, 10, 8.6, 6.0) * 0.92, 8);
      d = smin(d, ell(ax, y, z, 0, yN + 2.2, 4.4, 9.8, 8.0, 7.6), 6);                            // nose bulb
      d = smin(d, ell(ax, y, z, 0, yN - 1.5, -3.0, 9.4, 10, 5.0), 5);                            // upper lip
      d = smin(d, rcone(ax / 0.84, y, z, 0, 55, -5, 0, yN - 6, -8.8, 12, 6.8) * 0.84, 8);       // mandible
      d = smin(d, ell(ax, y, z, 0, yN - 4.5, -10.6, 6.8, 7.2, 4.4), 4);                          // chin
      return d;
    }
    // seat the eye on the orbit surface
    F.eyeN = norm([0.88, 0.26, 0.40]);
    {
      const o = F.orbit; let t0 = 0, t1 = 20;
      for (let i = 0; i < 40; i++) { const tm = (t0 + t1) / 2; const p = [o[0] + F.eyeN[0] * tm, o[1] + F.eyeN[1] * tm, o[2] + F.eyeN[2] * tm]; if (skullBase(p[0], p[1], p[2]) > 0) t1 = tm; else t0 = tm; }
      F.eyeC = [o[0] + F.eyeN[0] * (t0 - 1.3), o[1] + F.eyeN[1] * (t0 - 1.3), o[2] + F.eyeN[2] * (t0 - 1.3)];
    }
    F.eyeU = norm(cross([0, 0, 1], F.eyeN)); if (F.eyeU[1] < 0) F.eyeU = F.eyeU.map(v => -v);   // along the eye, toward the nose
    // tip the almond so the nasal corner drops toward the tear groove
    { const a = -0.16, c = Math.cos(a), sn = Math.sin(a), V = cross(F.eyeN, F.eyeU); F.eyeU = norm(F.eyeU.map((u, i) => u * c + V[i] * sn)); }
    F.eyeV = cross(F.eyeN, F.eyeU); if (F.eyeV[2] < 0) F.eyeV = F.eyeV.map(v => -v);
    F.eyeA = 6.6 * es; F.eyeB = 3.5 * es; F.lidR = 0.85 * es;
    F.eyeR = 7.6 * es; F.eyeProud = 1.9 * es; F.socket = 0.9 * es;          // eyeball sphere radius, apex height over the lid plane, socket floor
    const E = F.eyeC, EN = F.eyeN, EU = F.eyeU, EV = F.eyeV;
    const eyeLocal = (ax, y, z) => { const dx = ax - E[0], dy = y - E[1], dz = z - E[2]; return [dx * EU[0] + dy * EU[1] + dz * EU[2], dx * EV[0] + dy * EV[1] + dz * EV[2], dx * EN[0] + dy * EN[1] + dz * EN[2]]; };
    // antler pedicle and ear root seated on the skull
    const seat = (o, dir, back) => { let t0 = 0, t1 = 40; for (let i = 0; i < 40; i++) { const tm = (t0 + t1) / 2; if (skullBase(o[0] + dir[0] * tm, o[1] + dir[1] * tm, o[2] + dir[2] * tm) > 0) t1 = tm; else t0 = tm; } return [o[0] + dir[0] * (t0 + back), o[1] + dir[1] * (t0 + back), o[2] + dir[2] * (t0 + back)]; };
    // the antler leans out with the spread setting; its pedicle is cut square to that lean so the antler seats flat
    F.antV = norm([F.pedicleDir[0] + 0.32 * ((shape.spread || 1) - 0.4), F.pedicleDir[1], F.pedicleDir[2]]);
    F.pedicle = seat(F.pedicle0, F.antV, 3.2);
    F.earRoot = seat(F.earRoot0, F.earDir, 2.6);

    function features(ax, y, z, d, fine) {
      { // pedicle: a bony stub with a flat seat square to the antler
        const P = F.pedicle, A = F.antV;
        const pd = rcone(ax, y, z, P[0] - A[0] * 9, P[1] - A[1] * 9, P[2] - A[2] * 9, P[0] + A[0] * 3, P[1] + A[1] * 3, P[2] + A[2] * 3, 6.4, 5.3);
        d = smin(d, smax(pd, (ax - P[0]) * A[0] + (y - P[1]) * A[1] + (z - P[2]) * A[2], 0.8), 4);
      }
      { // ear root, flat seat square to the ear
        const P = F.earRoot, A = F.earDir;
        const pd = rcone(ax, y, z, P[0] - A[0] * 8, P[1] - A[1] * 8, P[2] - A[2] * 8, P[0] + A[0] * 3, P[1] + A[1] * 3, P[2] + A[2] * 3, 6.6, 4.9);
        d = smin(d, smax(pd, (ax - P[0]) * A[0] + (y - P[1]) * A[1] + (z - P[2]) * A[2], 0.8), 4);
      }
      const [eu, ev, ew] = eyeLocal(ax, y, z);
      if (Math.abs(ew) < 14 && Math.abs(eu) < 22 && Math.abs(ev) < 16) {
        const alm = almond2(eu, ev, F.eyeA, F.eyeB);
        d = smin(d, ell(eu, ev, ew, -1.0, 4.4 * es, -1.9, 8.6 * es, 3.2 * es, 3.4), 3.2);   // brow hood over the upper lid
        d = smin(d, Math.hypot(alm, ew) - F.lidR, 1.4);                                      // lids
        // socket: a shallow flat floored opening inside the lids
        d = smax(d, -smax(alm + 0.1, -(ew + F.socket), 0.5), 0.6);
        if (fine && shape.eyeMode === 'sculpted') d = Math.min(d, Math.max(Math.hypot(eu, ev, ew + F.eyeR - F.eyeProud) - F.eyeR, alm - 0.1));
        if (fine) { // tear groove from the nasal corner, forward and down
          const g0 = [F.eyeA * 0.8, -0.4, -0.2], g1 = [F.eyeA + 8.5 * es, -4.8 * es, -1.2];
          d = smax(d, -capsule(eu, ev, ew, g0[0], g0[1], g0[2], g1[0], g1[1], g1[2], 1.0), 1.0);
        }
      }
      if (fine) {
        d = smax(d, -ell(ax, y, z, F.commissure[0], F.commissure[1], F.commissure[2], 1.6, 3.8, 1.1), 1.2);           // corner of the mouth
        if (y > yN - 4) {
          d = smax(d, -capsule(ax, y, z, 4.0, yN + 9.4, 6.6, 7.0, yN + 6.2, 1.8, 1.2), 0.9);                           // nostril slit
          d = smax(d, -ell(ax, y, z, 4.3, yN + 9.2, 7.0, 2.0, 1.5, 1.8), 0.8);                                          // nostril
          d = smax(d, -capsule(ax, y, z, 0, yN + 10.0, 3.0, 0, yN + 4.6, -5.4, 0.7), 0.6);                              // philtrum
        }
      }
      return d;
    }
    function neck(x, y0, z0) {
      const xn = x / (0.86 * nk);
      let dn = rcone(xn, y0, z0, 0, -14, -10, 0, 30, 9, 40 * nk, 23) * 0.86;
      dn = smin(dn, ell(x, y0, z0, 0, -3, -4, 37 * nk, 6, 44 * nk), 10);                    // shoulder flare at the plaque
      dn = smin(dn, rcone(x, y0, z0, 0, -2, 30 * nk, 0, 34, 30, 9, 8), 10);                 // nape crest
      dn = smin(dn, rcone(x, y0, z0, 0, 0, -35 * nk, 0, 38, -15, 8, 5.5), 8);              // windpipe
      return dn;
    }
    // cheap bounds so the level set only pays for the full sculpt near the skin
    const bA = headWorld(40, 16), bB = headWorld(yN + 12, 2);
    function make(fine) {
      return function (px, py, pz) {
        const x = px / s, y0 = py / s, z0 = pz / s, ax = Math.abs(x);
        const dn = neck(x, y0, z0);
        const bh = capsule(ax, y0, z0, 0, bA[0], bA[1], 0, bB[0], bB[1], 34);
        if (bh > 6 && dn > 6) return (Math.min(bh, dn) - 4) * s;
        const [y, z] = headLocal(y0, z0);
        const sk = features(ax, y, z, skullBase(ax, y, z), fine);
        return smin(dn, sk, 13) * s;
      };
    }
    return { d: make(true), dCoarse: make(false), F, s, PY, PZ, tilt: t, headLocal, headWorld, eyeLocal, almond2 };
  }

  /* ---- printable round-section antler. Every stroke is round on top and drops at 45 degrees to a flat
   * bottom that sits on the bed, so the part prints flat with no supports. strokes: [[u, v, r], ...] polylines */
  function antlerField(strokes, knobs) {
    const segs = [];
    for (const L of strokes) for (let i = 0; i < L.length - 1; i++) segs.push([L[i], L[i + 1]]);
    return function (u, v, z) {
      let best = 1e9;
      for (const [A, B] of segs) {
        const bu = B[0] - A[0], bv = B[1] - A[1];
        const h = clamp(((u - A[0]) * bu + (v - A[1]) * bv) / (bu * bu + bv * bv || 1), 0, 1);
        const q = Math.hypot(u - A[0] - bu * h, v - A[1] - bv * h);
        const r = A[2] + (B[2] - A[2]) * h;
        const zc = 0.62 * r, hz = z - zc;
        let dd;
        if (hz >= 0) dd = Math.hypot(q, hz) - r;
        else dd = Math.max((q - r - hz) * Math.SQRT1_2, -z);
        best = smin(best, dd, 1.4);
      }
      for (const [ku, kv, kr] of knobs || []) {
        const q = Math.hypot(u - ku, v - kv), zc = 0.62 * kr, hz = z - zc;
        const dd = hz >= 0 ? Math.hypot(q, hz) - kr : Math.max((q - kr - hz) * Math.SQRT1_2, -z);
        best = smin(best, dd, 0.8);
      }
      return Math.max(best, -z);
    };
  }

  /* ---- cupped ear, printed standing on its tenon. v along the ear (0 at the root), u across, w toward the opening. */
  function earField(Le, We, cup) {
    const halfW = v => {
      const t = clamp(v / Le, 0, 1);
      const leaf = (We / 2) * Math.pow(Math.sin(Math.PI * Math.min(1, t * 1.08)), 0.72);
      return Math.max(leaf, 3.4 * (1 - t));
    };
    const f = function (u, v, w) {
      const hw = halfW(v);
      // outline in (u, v): a leaf that rounds off at the tip
      let d2 = Math.abs(u) - hw;
      d2 = Math.max(d2, v - Le, -v);
      // shell: curved like a scoop, thicker at the root, thinner at the rim and tip
      const tn = clamp(v / Le, 0, 1);
      const th = 3.0 - 1.3 * Math.sqrt(tn) - 0.5 * clamp(Math.abs(u) / Math.max(hw, 1e-3), 0, 1);
      const wc = -cup * (1 - sq(clamp(u / Math.max(hw, 1e-3), -1, 1))) * clamp(v / 6, 0, 1);
      const ds = Math.abs(w - wc) - th / 2;
      return smax(d2, ds, 0.9);
    };
    f.halfW = halfW;
    f.wc = (u, v) => { const hw = halfW(v); return -cup * (1 - sq(clamp(u / Math.max(hw, 1e-3), -1, 1))) * clamp(v / 6, 0, 1); };
    return f;
  }


  /* ---- ear that prints lying on its back: the front is the same cupped scoop, the back is a flat plane that
   * rises to the rim in a 1.2:1 bevel, so it sits flat on the bed and nothing overhangs past 45 degrees */
  function earFieldFlat(Le, We, cup) {
    const base = earField(Le, We, cup), halfW = base.halfW, B = cup + 1.5, k = 1.2;
    const f = function (u, v, w) {
      const hw = halfW(v);
      let d2 = Math.abs(u) - hw;
      d2 = Math.max(d2, v - Le, -v);
      const db = Math.max(Math.abs(u) - hw, v - Le);
      const tn = clamp(v / Le, 0, 1);
      const th = 3.0 - 1.3 * Math.sqrt(tn) - 0.5 * clamp(Math.abs(u) / Math.max(hw, 1e-3), 0, 1);
      const wf = base.wc(u, v) + th / 2;
      const back = -B + Math.max(0, cup + k * db);
      const ds = Math.max(back - w, w - wf);
      return smax(d2, ds, 0.9);
    };
    f.halfW = halfW; f.wc = base.wc; f.B = B;
    return f;
  }

  /* ---- paint guide: a white-tailed deer, as a painter would block it in. Returns [r,g,b] 0..1 for a point
   * on the head or jaw skin (mounted frame). */
  const hex = h => [parseInt(h.slice(1, 3), 16) / 255, parseInt(h.slice(3, 5), 16) / 255, parseInt(h.slice(5, 7), 16) / 255];
  const PAL = { coat: hex('#8E5E38'), coatDark: hex('#4A2F1D'), coatGrey: hex('#6E5643'), white: hex('#EEE8DC'), black: hex('#141211'), lip: hex('#2A2220'), mouth: hex('#7A3B3B') };
  const ss = (a, b, x) => { const t = clamp((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); };
  const mix = (a, b, t) => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t];
  function paintHead(H, px, py, pz, jawFace) {
    const s = H.s, F = H.F;
    const x = px / s, y0 = py / s, z0 = pz / s;
    const [y, z] = H.headLocal(y0, z0);
    const ax = Math.abs(x);
    let c = PAL.coat;
    // greyer neck, warmer face
    c = mix(PAL.coatGrey, c, ss(30, 55, y));
    // dark saddle down the forehead and nasal bridge, the darker V between the eyes
    const ridge = ss(8, 3, ax) * ss(18, 26, z) * ss(46, 60, y) * ss(F.yN + 4, F.yN - 10, y);
    c = mix(c, PAL.coatDark, 0.85 * ridge);
    // eye ring
    const [eu, ev, ew] = H.eyeLocal(ax, y, z);
    const alm = H.almond2(eu, ev, F.eyeA, F.eyeB);
    if (ew > -5) c = mix(c, PAL.white, 0.7 * ss(3.8, 1.6, alm) * ss(-5, -2.5, ew));
    // the eye itself and the dark lid line and tear groove
    if (ew > -5) c = mix(c, PAL.black, ss(1.3, 0.55, alm) * ss(-5, -3, ew));
    // tear groove, dark
    if (ew > -5) { const gu = eu - F.eyeA, gv = ev + 2.4 * (gu / 8); c = mix(c, PAL.coatDark, 0.8 * ss(1.8, 0.6, Math.hypot(Math.max(0, Math.abs(gu - 3) - 4), gv + 1.6)) * ss(-0.5, 1, eu - F.eyeA * 0.8)); }
    // mouth corner and lip line
    c = mix(c, PAL.lip, ss(3.2, 1.2, Math.hypot((ax - F.commissure[0]) * 0.9, (y - F.commissure[1]) / 2.4, (z - F.commissure[2]) * 0.9)));
    // muzzle: white band behind the black nose
    const A = F.muzA, B = F.muzB, bx = B[1] - A[1], bz = B[2] - A[2], bl = Math.hypot(bx, bz);
    const tAx = ((y - A[1]) * bx + (z - A[2]) * bz) / (bl * bl);
    const band = ss(0.70, 0.78, tAx) * ss(0.97, 0.90, tAx);
    c = mix(c, PAL.white, 0.92 * band * ss(-9, -2, z));
    // nose pad, black: the bulb front and the strip down to the lip
    const nose = ss(0.93, 0.98, tAx) * ss(-4.5, -1.5, z);
    c = mix(c, PAL.black, nose);
    // chin and lower lip, white
    c = mix(c, PAL.white, ss(-4, -8, z) * ss(F.yN - 22, F.yN - 12, y));
    // lip line, near black, both lips
    if (jawFace) c = mix(PAL.mouth, PAL.lip, ss(F.yN - 30, F.yN - 10, y));
    // throat patch: a white crescent under the jaw
    const tp = Math.hypot(x / 15, (y0 - F.throat[1]) / 11, (z0 - F.throat[2]) / 9);
    c = mix(c, PAL.white, 0.95 * ss(1.15, 0.85, tp));
    // lighter belly of the jaw
    c = mix(c, PAL.white, 0.35 * ss(-6, -14, z) * ss(55, 75, y));
    return c;
  }
  function paintAntler(t) { // t = 0 at the burr, 1 at the tip
    return mix(mix(hex('#5E4630'), hex('#B49C76'), ss(0, 0.35, t)), hex('#F1E8D4'), ss(0.55, 1, t));
  }
  function paintEar(u, v, w, hw, Le, front) {
    let c = mix(PAL.coatGrey, PAL.coat, 0.4);
    if (front) {
      const rim = Math.abs(u) / Math.max(hw, 1e-3);
      c = mix(hex('#EADBD2'), PAL.white, 0.3);
      c = mix(c, PAL.coatDark, ss(0.78, 0.95, rim));
    }
    c = mix(c, PAL.coatDark, ss(0.82, 1.0, v / Le));
    return c;
  }

  function antlerSkel(style) {
    if (style === 'spike') return { strokes: [[[0, 0, 4.0], [-2.2, 14, 3.3], [-0.5, 28, 2.4], [3.6, 40, 1.3]]], tip: 40 };
    if (style === 'fork') return { strokes: [
      [[0, 0, 4.3], [-4.2, 12, 3.8], [-3.4, 26, 3.2], [3.4, 37, 2.4], [12.5, 43, 1.5]],
      [[-2.4, 6, 2.5], [0.6, 12.5, 1.9], [1.6, 17, 1.2]],
      [[-4.2, 23, 2.7], [-4.2, 35, 2.0], [-2.4, 45, 1.2]]], tip: 46 };
    return { strokes: [
      [[0, 0, 4.5], [-5, 10, 4.1], [-7, 22, 3.7], [-3.2, 34, 3.2], [5.5, 43, 2.7], [16.5, 48, 2.1], [26.5, 49.5, 1.4]],
      [[-2.6, 5.5, 2.7], [0.8, 12.5, 2.1], [2.2, 18.5, 1.3]],
      [[-6.6, 25, 2.9], [-7.4, 37, 2.2], [-6.2, 48.5, 1.3]],
      [[3.0, 40, 2.6], [5.0, 51, 1.9], [6.0, 60, 1.2]],
      [[14.5, 47, 2.0], [17.2, 54, 1.5], [18.2, 59.5, 1.0]]], tip: 60 };
  }
  function antlerBurr(r0) { // coronet: a ring wider than the beam just above the root, with knobs round its rim
    const strokes = [[[0, 0.4, r0 + 1.1], [0, 2.4, r0 + 1.3]]];
    const knobs = [];
    for (let i = 0; i < 9; i++) { const a = (i / 8 - 0.5) * 2.2; knobs.push([Math.sin(a) * (r0 + 1.6), 1.4 + Math.cos(a) * 0.6, 1.0 + 0.35 * ((i * 7) % 3) / 2]); }
    return { strokes, knobs };
  }
  root.BUCKSDF = { makeHead, antlerField, earField, earFieldFlat, antlerSkel, antlerBurr, ell, rcone, capsule, smin, smax, almond2, paintHead, paintAntler, paintEar, PAL };
})(typeof globalThis !== 'undefined' ? globalThis : this);
