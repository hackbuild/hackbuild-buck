/* BUCK engine v2: builds every printed part, every hardware stand-in and the fit audit from the state.
 * Every part is a single material: print each in its own filament, or everything in one and paint.
 * Needs manifold-3d (WASM) passed in as M, and BUCKSDF. Plain script, works from file://.
 * Mounted frame: x right, y out of the wall, z up, mm. Plaque front face is y = 0. */
(function (root) {
  'use strict';
  const D2R = Math.PI / 180;

  /* ---------------------------------------------------------------- hardware */
  // SG90 numbers from the TowerPro drawing, then widened where clones vary: window +0.6, horn groove +0.7 in x
  const HW = {
    servo: {
      SG90: { name: 'SG90 / MG90S 9 g micro', L: 22.8, W: 12.4, H: 22.7, flZ: 15.9, flT: 2.5, flL: 32.3, holeSpan: 27.8,
        shaftOff: 6.0, towerD: 11.8, towerTop: 26.6, shaftTop: 29.8, hubD: 7.0, hubH: 2.1, plateT: 1.6, plateLen: 15.5,
        plateW0: 6.4, plateW1: 4.2, headD: 4.8, headH: 1.6 }
    },
    board: {
      S3MINI: { name: 'ESP32-S3 SuperMini', L: 22.6, W: 18.0, t: 1.2 },
      RP2040Z: { name: 'Waveshare RP2040-Zero', L: 23.5, W: 18.0, t: 1.2 },
      S3ZERO: { name: 'Waveshare ESP32-S3-Zero', L: 23.5, W: 18.0, t: 1.2 },
      XIAO: { name: 'Seeed XIAO ESP32S3', L: 21.0, W: 17.8, t: 1.2 },
      QTPY: { name: 'Adafruit QT Py ESP32-S3', L: 22.8, W: 17.8, t: 1.6 }
    },
    // NULLLAB NS4168 I2S DAC amp, from the vendor CAD drawing (nulllaborg/i2s_audio_amplifier_module):
    // 38.4 x 22.4, two 4.7 mm holes 16.0 apart on one line 15.2 from the input end, 3.2 in from each long edge.
    // Input is a 5 pin PH2.0 on the end; the far end has the speaker PH2.0 and a 2 way screw terminal.
    // Component heights are not on the drawing: 10 mm covers the screw terminal, 6 mm the PH housings.
    amp: {
      NS4168: { name: 'NULLLAB NS4168 I2S amp (3W kit)', L: 38.4, W: 22.4, t: 1.6, holeD: 4.7, holeX: 15.2, holeY: [3.2, 19.2], comp: 10.0, ph: 6.0, under: 2.0 }
    },
    // pegboard: hole diameter, board thickness, hole pitch (US hardboard)
    peg: {
      '1/4': { name: '1/4 in pegboard', hole: 6.35, board: 6.35, pitch: 25.4, shank: 4.6, cham: 1.0, tip: 5.5 },
      '1/8': { name: '1/8 in pegboard', hole: 4.76, board: 3.2, pitch: 25.4, shank: 3.4, cham: 0.7, tip: 4.5 }
    }
  };

  function defaults() {
    return {
      shape: { scale: 1.15, muzzle: 1.0, neck: 1.1, crown: 1.0, cheek: 1.0, tilt: 12, wall: 2.4, eye: 1.0 },
      eyes: { mode: 'separate', fit: 0.10 },
      nose: { mode: 'separate', fit: 0.15 },
      jaw: { open: 22, gap: 0.5, shell: 'channel', wall: 2.2 },
      ears: { on: true, size: 1.0 },
      antlers: { style: 'crown', size: 1.0, spread: 1.0 },
      servo: { type: 'SG90' },
      board: { type: 'S3MINI', custom: { L: 22.6, W: 18.0, t: 1.2 } },
      amp: { type: 'NS4168' },
      // the kit's 3W speaker: square frame with two ears. Taken off the listing photo, not calipered
      speaker: { frame: 30, span: 39, hole: 2.2, depth: 7.5, cone: 20.8, dome: 2.0 },
      mount: { shape: 'shield', thick: 8, fill: 0.62, attach: 'screws', margin: 14, edge: 'ogee', groove: true, hang: 'hooks', board: '1/4', pitchIn: 4, holeD: 7.0, keyholes: false, snap: 0.7 },
      slots: [
        { color: '#8A5A36', type: 'PETG', name: 'brown' },
        { color: '#EAE0CA', type: 'PETG', name: 'bone' },
        { color: '#1A1A1A', type: 'PETG', name: 'black' },
        { color: '#3B2618', type: 'PETG', name: 'walnut' }
      ],
      roles: { body: 1, antler: 2, eye: 3, nose: 3, plaque: 4, pin: 4 },
      print: { mode: 'filament', layer: 0.24, quality: 'draft', bedW: 256, bedD: 256, writeFilaments: true,
        printer: 'Flashforge Creator 5 Pro 0.4 nozzle', process: '0.24mm Standard @FF C5', pattern: 'Generic {TYPE} @FF C5P' }
    };
  }

  /* ---------------------------------------------------------------- small maths */
  const v3 = {
    add: (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]],
    sub: (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]],
    mul: (a, k) => [a[0] * k, a[1] * k, a[2] * k],
    dot: (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2],
    cross: (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]],
    len: a => Math.hypot(a[0], a[1], a[2]),
    norm: a => { const l = Math.hypot(a[0], a[1], a[2]) || 1; return [a[0] / l, a[1] / l, a[2] / l]; }
  };
  const basis = (u, v, w, o) => [u[0], u[1], u[2], 0, v[0], v[1], v[2], 0, w[0], w[1], w[2], 0, o[0], o[1], o[2], 1];
  function mat4mul(a, b) { const r = new Array(16).fill(0); for (let c = 0; c < 4; c++) for (let rI = 0; rI < 4; rI++) { let s = 0; for (let k = 0; k < 4; k++) s += a[k * 4 + rI] * b[c * 4 + k]; r[c * 4 + rI] = s; } return r; }
  function mat4apply(m, p) { return [m[0] * p[0] + m[4] * p[1] + m[8] * p[2] + m[12], m[1] * p[0] + m[5] * p[1] + m[9] * p[2] + m[13], m[2] * p[0] + m[6] * p[1] + m[10] * p[2] + m[14]]; }
  function mat4inv(m) { // rigid inverse (rotation + translation)
    const r = [m[0], m[4], m[8], 0, m[1], m[5], m[9], 0, m[2], m[6], m[10], 0, 0, 0, 0, 1];
    const t = mat4apply(r, [m[12], m[13], m[14]]); r[12] = -t[0]; r[13] = -t[1]; r[14] = -t[2]; return r;
  }
  function rotX(deg) { const c = Math.cos(deg * D2R), s = Math.sin(deg * D2R); return [1, 0, 0, 0, 0, c, s, 0, 0, -s, c, 0, 0, 0, 0, 1]; }
  function trans(t) { return [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, t[0], t[1], t[2], 1]; }
  function alignMat(a, b) { // rotation taking unit a onto unit b
    const v = v3.cross(a, b), c = v3.dot(a, b);
    if (c < -0.999999) return rotX(180);
    const k = 1 / (1 + c), [x, y, z] = v;
    const R = [[c + x * x * k, x * y * k - z, x * z * k + y], [y * x * k + z, c + y * y * k, y * z * k - x], [z * x * k - y, z * y * k + x, c + z * z * k]];
    return [R[0][0], R[1][0], R[2][0], 0, R[0][1], R[1][1], R[2][1], 0, R[0][2], R[1][2], R[2][2], 0, 0, 0, 0, 1];
  }

  /* mesh repair for export: collapse zero length edges and flip away zero area caps, keeping the mesh manifold */
  function cleanMesh(P, I) {
    I = Array.from(I);
    const nv = P.length / 3;
    const rep = new Int32Array(nv); for (let i = 0; i < nv; i++) rep[i] = i;
    const find = v => { while (rep[v] !== v) { rep[v] = rep[rep[v]]; v = rep[v]; } return v; };
    const d2 = (a, b) => { const x = P[a * 3] - P[b * 3], y = P[a * 3 + 1] - P[b * 3 + 1], z = P[a * 3 + 2] - P[b * 3 + 2]; return x * x + y * y + z * z; };
    const area2 = (a, b, c) => { const ux = P[b * 3] - P[a * 3], uy = P[b * 3 + 1] - P[a * 3 + 1], uz = P[b * 3 + 2] - P[a * 3 + 2], vx = P[c * 3] - P[a * 3], vy = P[c * 3 + 1] - P[a * 3 + 1], vz = P[c * 3 + 2] - P[a * 3 + 2]; const x = uy * vz - uz * vy, y = uz * vx - ux * vz, z = ux * vy - uy * vx; return x * x + y * y + z * z; };
    let fixed = 0;
    for (let pass = 0; pass < 8; pass++) {
      let changed = false;
      for (let t = 0; t < I.length; t += 3) for (let k = 0; k < 3; k++) {
        const a = find(I[t + k]), b = find(I[t + (k + 1) % 3]);
        if (a !== b && d2(a, b) < 1e-14) { rep[b] = a; changed = true; fixed++; }
      }
      if (changed) {
        const J = [];
        for (let t = 0; t < I.length; t += 3) { const a = find(I[t]), b = find(I[t + 1]), c = find(I[t + 2]); if (a !== b && b !== c && a !== c) J.push(a, b, c); }
        I = J;
      }
      const edge = new Map(); const key = (a, b) => a * 4194304 + b;
      for (let t = 0; t < I.length; t += 3) for (let k = 0; k < 3; k++) edge.set(key(I[t + k], I[t + (k + 1) % 3]), t);
      for (let t = 0; t < I.length; t += 3) {
        const v = [I[t], I[t + 1], I[t + 2]];
        if (area2(v[0], v[1], v[2]) > 1e-12) continue;
        let k = 0, best = -1; for (let j = 0; j < 3; j++) { const l = d2(v[j], v[(j + 1) % 3]); if (l > best) { best = l; k = j; } }
        const a = v[k], b = v[(k + 1) % 3], c = v[(k + 2) % 3];
        const u = edge.get(key(b, a)); if (u === undefined) continue;
        const w = [I[u], I[u + 1], I[u + 2]]; const dd = w.find(x => x !== a && x !== b);
        if (dd === undefined || dd === c || edge.has(key(c, dd)) || edge.has(key(dd, c))) continue;
        if (area2(a, dd, c) < 1e-12 || area2(dd, b, c) < 1e-12) continue;
        I[t] = a; I[t + 1] = dd; I[t + 2] = c; I[u] = dd; I[u + 1] = b; I[u + 2] = c;
        edge.delete(key(a, b)); edge.delete(key(b, a));
        edge.set(key(a, dd), t); edge.set(key(dd, c), t); edge.set(key(c, a), t);
        edge.set(key(dd, b), u); edge.set(key(b, c), u); edge.set(key(c, dd), u);
        changed = true; fixed++;
      }
      if (!changed && pass < 7) {
        // caps that could not be flipped: snap the middle vertex onto the nearer end of the long edge
        for (let t = 0; t < I.length; t += 3) {
          const v = [find(I[t]), find(I[t + 1]), find(I[t + 2])];
          if (v[0] === v[1] || v[1] === v[2] || v[0] === v[2] || area2(v[0], v[1], v[2]) > 1e-12) continue;
          let k = 0, best = -1; for (let j = 0; j < 3; j++) { const l = d2(v[j], v[(j + 1) % 3]); if (l > best) { best = l; k = j; } }
          const a = v[k], b = v[(k + 1) % 3], c = v[(k + 2) % 3];
          if (d2(c, a) < d2(c, b)) rep[c] = a; else rep[c] = b;
          changed = true; fixed++;
        }
        if (changed) { const J = []; for (let t = 0; t < I.length; t += 3) { const a = find(I[t]), b = find(I[t + 1]), c = find(I[t + 2]); if (a !== b && b !== c && a !== c) J.push(a, b, c); } I = J; continue; }
      }
      if (!changed) break;
    }
    const map = new Int32Array(nv).fill(-1), pos = []; let n = 0;
    const out = new Uint32Array(I.length);
    for (let i = 0; i < I.length; i++) { const v = I[i]; if (map[v] < 0) { map[v] = n++; pos.push(P[v * 3], P[v * 3 + 1], P[v * 3 + 2]); } out[i] = map[v]; }
    // pinches: two surface sheets touching at one point leave distinct vertices at the same place, which a slicer
    // welds into a non manifold vertex. Pull each such vertex 0.6 microns inward along its own normal.
    const Q = new Float32Array(pos), buckets = new Map();
    for (let i = 0; i < n; i++) { const k = Math.round(Q[i * 3] * 1e4) + ',' + Math.round(Q[i * 3 + 1] * 1e4) + ',' + Math.round(Q[i * 3 + 2] * 1e4); const b = buckets.get(k); if (b) b.push(i); else buckets.set(k, [i]); }
    let pinched = null;
    for (const b of buckets.values()) if (b.length > 1) { if (!pinched) pinched = new Set(); for (const i of b) pinched.add(i); }
    if (pinched) {
      // move each pinched vertex a hair into its own fan of faces, which always separates the sheets
      const cen = new Float64Array(n * 3), cnt = new Uint32Array(n);
      for (let t = 0; t < out.length; t += 3) {
        const a = out[t], b = out[t + 1], c = out[t + 2];
        if (!pinched.has(a) && !pinched.has(b) && !pinched.has(c)) continue;
        const cx = (Q[a * 3] + Q[b * 3] + Q[c * 3]) / 3, cy = (Q[a * 3 + 1] + Q[b * 3 + 1] + Q[c * 3 + 1]) / 3, cz = (Q[a * 3 + 2] + Q[b * 3 + 2] + Q[c * 3 + 2]) / 3;
        for (const v of [a, b, c]) { cen[v * 3] += cx; cen[v * 3 + 1] += cy; cen[v * 3 + 2] += cz; cnt[v]++; }
      }
      for (const i of pinched) {
        const dx = cen[i * 3] / cnt[i] - Q[i * 3], dy = cen[i * 3 + 1] / cnt[i] - Q[i * 3 + 1], dz = cen[i * 3 + 2] / cnt[i] - Q[i * 3 + 2], l = Math.hypot(dx, dy, dz) || 1;
        const k = Math.min(8e-4, l * 0.25) / l;
        Q[i * 3] += dx * k; Q[i * 3 + 1] += dy * k; Q[i * 3 + 2] += dz * k; fixed++;
      }
    }
    return { positions: Q, indices: out, fixed };
  }

  /* ---------------------------------------------------------------- build */
  function build(M, st, cache) {
    cache = cache || {};
    const { Manifold, CrossSection } = M;
    const T0 = Date.now(); const TM = {}; let tm0 = Date.now(); const mark = k => { const n = Date.now(); TM[k] = (TM[k] || 0) + n - tm0; tm0 = n; };
    const track = [];
    const K = m => { track.push(m); return m; };
    const notes = [], warns = [], errs = [];
    const S = st.shape.scale, wall = st.shape.wall, g = st.jaw.gap;
    const fine = st.print.quality === 'fine';
    const edge = fine ? 0.8 : 1.15;
    const SV = HW.servo[st.servo.type] || HW.servo.SG90;
    const BD = st.board.type === 'CUSTOM' ? Object.assign({ name: 'custom board' }, st.board.custom) : HW.board[st.board.type];
    const AM = HW.amp.NS4168;
    const PEG = HW.peg[st.mount.board] || HW.peg['1/4'];
    const BIG = 400;
    const sepEyes = st.eyes.mode === 'separate', sepNose = st.nose.mode === 'separate';

    const shp = { s: S, muzzle: st.shape.muzzle, neck: st.shape.neck, crown: st.shape.crown, cheek: st.shape.cheek, tilt: st.shape.tilt, eye: st.shape.eye, eyeMode: sepEyes ? 'separate' : 'sculpted', spread: st.antlers.spread };
    const HD = BUCKSDF.makeHead(shp), F = HD.F;
    const d = HD.d, dC = HD.dCoarse;
    const tilt = st.shape.tilt;
    const PIV = [0, 46 * S, 6 * S];
    const L2Wm = mat4mul(trans(PIV), mat4mul(rotX(-tilt), trans(v3.mul(PIV, -1))));
    const lw = p => mat4apply(L2Wm, p);                      // head frame (scaled) -> world
    const lwv = v => v3.sub(lw(v), lw([0, 0, 0]));
    const fw = p => lw(v3.mul(p, S));                        // head frame (unscaled landmark) -> world
    const L2W = m => K(m.transform(L2Wm));
    const surfAlong = (f, o, dir, maxT) => { dir = v3.norm(dir); let t0 = 0, t1 = maxT || 120; if (f(...o) > 0) return o; for (let t = 0; t < (maxT || 120); t += 0.5) { if (f(...v3.add(o, v3.mul(dir, t))) > 0) { t1 = t; break; } t0 = t; } for (let i = 0; i < 30; i++) { const tm = (t0 + t1) / 2; if (f(...v3.add(o, v3.mul(dir, tm))) > 0) t1 = tm; else t0 = tm; } return v3.add(o, v3.mul(dir, (t0 + t1) / 2)); };

    /* primitives */
    const box = (x0, x1, y0, y1, z0, z1) => K(Manifold.cube([x1 - x0, y1 - y0, z1 - z0]).translate([x0, y0, z0]));
    const cylX = (r, x0, x1, y, z, seg) => K(Manifold.cylinder(x1 - x0, r, r, seg || 40).rotate([0, 90, 0]).translate([x0, y, z]));
    const cylY = (r, y0, y1, x, z, seg) => K(Manifold.cylinder(y1 - y0, r, r, seg || 40).rotate([-90, 0, 0]).translate([x, y0, z]));
    const cylZ = (r, z0, z1, x, y, seg) => K(Manifold.cylinder(z1 - z0, r, r, seg || 40).translate([x, y, z0]));
    // the mount prints plaque down, so engine +y is up on the bed: anything round about z gets a 45 degree point toward -y
    const tearZ = (r, z0, z1, x, y, clip) => { let cs = K(CrossSection.hull([K(CrossSection.circle(r, 40).translate([x, y])), K(CrossSection.circle(0.05, 8).translate([x, y - r * Math.SQRT2]))]));
      if (clip !== undefined) cs = K(cs.intersect(K(CrossSection.square([4 * r, 2 * r + clip], false).translate([x - 2 * r, y - clip]))));
      return K(K(Manifold.extrude(cs, z1 - z0)).translate([0, 0, z0])); };
    const U = arr => { const a = arr.filter(m => m && !m.isEmpty()); return a.length ? K(Manifold.union(a)) : null; };
    const YZ = [0, 1, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 1];
    function yzExtrude(cs, x0, x1) { return K(K(Manifold.extrude(cs, x1 - x0)).transform(YZ).translate([x0, 0, 0])); }
    function xzExtrude(cs, y0, y1) { return K(K(Manifold.extrude(cs, y1 - y0)).transform([1, 0, 0, 0, 0, 0, 1, 0, 0, -1, 0, 0, 0, 0, 0, 1]).translate([0, y1, 0])); }
    const CS = pts => K(new CrossSection([pts], 'Positive'));
    function fixWind(pts) { let a = 0; for (let i = 0; i < pts.length; i++) { const p = pts[i], q = pts[(i + 1) % pts.length]; a += p[0] * q[1] - q[0] * p[1]; } return CS(a < 0 ? pts.slice().reverse() : pts); }
    function fixWindPts(p) { let s = 0; for (let i = 0; i < p.length; i++) { const A = p[i], B = p[(i + 1) % p.length]; s += A[0] * B[1] - B[0] * A[1]; } return s < 0 ? p.slice().reverse() : p; }
    function halfPlane2(P, n) { const t = [-n[1], n[0]]; return fixWind([[P[0] + t[0] * BIG, P[1] + t[1] * BIG], [P[0] + t[0] * BIG + n[0] * BIG, P[1] + t[1] * BIG + n[1] * BIG], [P[0] - t[0] * BIG + n[0] * BIG, P[1] - t[1] * BIG + n[1] * BIG], [P[0] - t[0] * BIG, P[1] - t[1] * BIG]]); }
    const circ2 = (r, cx, cy, seg) => K(CrossSection.circle(r, seg || 48).translate([cx, cy]));
    const vol = m => (m && !m.isEmpty()) ? m.volume() : 0;
    const hit = (A, B) => { if (!A || !B) return 0; return vol(K(A.intersect(B))); };

    /* ------------------------------------------------ the skin and the cavity, cached by shape */
    const axW = v3.norm(v3.sub(fw(F.muzB), fw(F.muzA)));
    const tipW = surfAlong(d, fw(F.muzB), axW);
    const noseLen = 9.5 * S;
    const noseP = v3.sub(tipW, v3.mul(axW, noseLen));
    const nC = v3.norm([0, 1, -1]);
    const cC = v3.dot(nC, v3.sub(noseP, v3.mul(axW, 6.5)));
    const dIn0 = (x, y, z) => Math.max(dC(x, y, z) + wall, (nC[0] * x + nC[1] * y + nC[2] * z) - cC);
    // the head prints rim down: wherever the cavity roof would lean past 45 degrees, cap it with a 45 degree plane
    const roofCaps = [];
    {
      const r45 = Math.SQRT1_2;
      const zTop = y => { for (let z = 95 * S; z > -50 * S; z -= 0.4) if (dIn0(0, y, z) < 0) return z; return null; };
      let best = -1e9, yb = 0; for (let y = 5; y < 165 * S; y += 1) { const zt = zTop(y); if (zt !== null && zt > best) { best = zt; yb = y; } }
      for (let y = yb; y < 165 * S; y += 0.5) { const z1 = zTop(y), z2 = zTop(y + 0.5); if (z1 === null || z2 === null) break; if ((z2 - z1) / 0.5 < -1) { roofCaps.push([0, r45, r45, r45 * y + r45 * z1]); break; } }
      for (const zq of [0.0, 0.5]) {
        const xHalf = (y, z) => { if (dIn0(0, y, z) >= 0) return null; let a0 = 0, a1 = 80; for (let i = 0; i < 24; i++) { const m = (a0 + a1) / 2; if (dIn0(m, y, z) < 0) a0 = m; else a1 = m; } return a0; };
        const zz = zq * best;
        let bw = -1, yw = 0; for (let y = 5; y < 165 * S; y += 1) { const w = xHalf(y, zz); if (w !== null && w > bw) { bw = w; yw = y; } }
        for (let y = yw; y < 165 * S; y += 0.5) { const w1 = xHalf(y, zz), w2 = xHalf(y + 0.5, zz); if (w1 === null || w2 === null) break; if ((w2 - w1) / 0.5 < -1) { roofCaps.push([r45, r45, 0, r45 * w1 + r45 * y]); roofCaps.push([-r45, r45, 0, r45 * w1 + r45 * y]); break; } }
      }
    }
    const dIn = (x, y, z) => { let v = dIn0(x, y, z); for (const c of roofCaps) v = Math.max(v, c[0] * x + c[1] * y + c[2] * z - c[3]); return v; };
    mark('roof');
    const shapeKey = JSON.stringify([shp, wall, edge]);
    let outerFull, inner, bnd;
    if (cache.shapeKey === shapeKey && cache.outerFull) { outerFull = cache.outerFull; inner = cache.inner; bnd = cache.bnd; }
    else {
      if (cache.outerFull) { try { cache.outerFull.delete(); cache.inner.delete(); } catch (e) { } }
      bnd = (() => {
        const mn = [1e9, 1e9, 1e9], mx = [-1e9, -1e9, -1e9], s3 = 3;
        for (let x = 0; x <= 90 * S; x += s3) for (let y = -2; y <= 175 * S; y += s3) for (let z = -95 * S; z <= 95 * S; z += s3) {
          if (d(x, y, z) < s3) { mn[0] = Math.min(mn[0], -x); mx[0] = Math.max(mx[0], x); mn[1] = Math.min(mn[1], y); mx[1] = Math.max(mx[1], y); mn[2] = Math.min(mn[2], z); mx[2] = Math.max(mx[2], z); }
        }
        return { min: [mn[0] - 3, -3, mn[2] - 3], max: [mx[0] + 3, mx[1] + 3, mx[2] + 3] };
      })();
      const tol = fine ? 0.02 : 0.04;
      // a coarse sampled copy of each field answers for points far from the skin; only the band near it pays for the sculpt
      const accel = (f, step, band) => {
        const nx = Math.ceil((bnd.max[0] - bnd.min[0]) / step) + 2, ny = Math.ceil((bnd.max[1] - bnd.min[1]) / step) + 2, nz = Math.ceil((bnd.max[2] - bnd.min[2]) / step) + 2;
        const x0 = bnd.min[0] - step / 2, y0 = bnd.min[1] - step / 2, z0 = bnd.min[2] - step / 2, G = new Float32Array(nx * ny * nz);
        for (let i = 0; i < nx; i++) for (let j = 0; j < ny; j++) for (let k = 0; k < nz; k++) G[(i * ny + j) * nz + k] = f(x0 + i * step, y0 + j * step, z0 + k * step);
        return (x, y, z) => {
          const fx = (x - x0) / step, fy = (y - y0) / step, fz = (z - z0) / step;
          const i = Math.floor(fx), j = Math.floor(fy), k = Math.floor(fz);
          if (i < 0 || j < 0 || k < 0 || i >= nx - 1 || j >= ny - 1 || k >= nz - 1) return f(x, y, z);
          const u = fx - i, v = fy - j, w = fz - k, b = (i * ny + j) * nz + k, sy = nz, sx = ny * nz;
          const c00 = G[b] * (1 - w) + G[b + 1] * w, c01 = G[b + sy] * (1 - w) + G[b + sy + 1] * w, c10 = G[b + sx] * (1 - w) + G[b + sx + 1] * w, c11 = G[b + sx + sy] * (1 - w) + G[b + sx + sy + 1] * w;
          const c = (c00 * (1 - v) + c01 * v) * (1 - u) + (c10 * (1 - v) + c11 * v) * u;
          return Math.abs(c) > band ? c : f(x, y, z);
        };
      };
      mark('bnd');
      const dA = accel(d, 2.5, 3.5), dInA = accel(dIn, 2.5, 3.5);
      mark('accel');
      const o0 = Manifold.levelSet(p => -dA(p[0], p[1], p[2]), bnd, edge, 0); mark('lsOuter'); outerFull = o0.simplify(tol); o0.delete(); mark('simp');
      const i0 = Manifold.levelSet(p => -dInA(p[0], p[1], p[2]), bnd, Math.max(edge, 1.25), 0); inner = i0.simplify(tol * 1.5); i0.delete();
      cache.shapeKey = shapeKey; cache.outerFull = outerFull; cache.inner = inner; cache.bnd = bnd;
    }
    const outer = K(outerFull.trimByPlane([0, 1, 0], 0));
    mark('skin');

    /* ------------------------------------------------ jaw geometry, head frame (scaled) */
    const RHUB = 6.0, Rb = 8.5;
    const hbMin = Math.max(Rb + wall + g + 0.6, SV.W / 2 + wall + g + 0.8);
    const yhL = 50 * S;
    let zBotL; { // underside of the head below the hinge
      for (let z = 0; z > -90 * S; z -= 0.25) { const p = lw([0, yhL, z]); if (d(p[0], p[1], p[2]) > 0) { zBotL = z; break; } }
    }
    const zhL = Math.max(2.5 * S, zBotL + hbMin);
    const H = lw([0, yhL, zhL]);
    const mouthRise = 3.5;
    const mouth0 = [yhL, zhL + mouthRise];
    const mouth1 = [(F.yN + 8) * S, -6.2 * S];
    const md = v3.norm([0, mouth1[0] - mouth0[0], mouth1[1] - mouth0[1]]);
    const mN = [-md[2], md[1]];
    const mNup = mN[1] < 0 ? [-mN[0], -mN[1]] : mN;
    const phiR = -90 + st.jaw.open + 4;
    const insAng = 135;
    const ins = [Math.cos(insAng * D2R), Math.sin(insAng * D2R)];
    function jawRegion(off) {
      const a = halfPlane2([mouth0[0] + mNup[0] * off, mouth0[1] + mNup[1] * off], [-mNup[0], -mNup[1]]);
      const rd = [Math.cos(phiR * D2R), Math.sin(phiR * D2R)], rn = [-rd[1], rd[0]];
      const b = halfPlane2([yhL - rn[0] * off, zhL - rn[1] * off], rn);
      const c = halfPlane2([yhL - off, zhL], [1, 0]);
      return K(K(K(a.intersect(b)).intersect(c)).subtract(circ2(Math.max(1, Rb - off), yhL, zhL, 64)));
    }
    function wedge() {
      const r0 = Rb - g, a1 = (-93) * D2R, a2 = (phiR + 0.5) * D2R, pts = [[yhL - g, zhL]];
      for (let i = 0; i <= 12; i++) { const a = a1 + (a2 - a1) * i / 12; pts.push([yhL + Math.cos(a) * BIG * 0.3, zhL + Math.sin(a) * BIG * 0.3]); }
      return K(fixWind(pts).subtract(circ2(r0, yhL, zhL, 64)));
    }
    const J = jawRegion(0), Jg = jawRegion(g), Wg = wedge();
    const Jm = L2W(yzExtrude(J, -BIG / 4, BIG / 4));
    const Jgm = L2W(yzExtrude(K(Jg.add(Wg)), -BIG / 4, BIG / 4));

    /* arm inset: how far apart the jaw arms can sit and still swing and slide in */
    const armDir = -20, hornDir = -20, Rarm = Rb + 4.8;
    let aMin = 1e9;
    {
      const caps = [[0, 0, RHUB + 0.6], [armDir, Rarm, 5.6]], pts = [];
      for (const [dir, len, rr] of caps) {
        const dv = [Math.cos(dir * D2R), Math.sin(dir * D2R)], nv = [-dv[1], dv[0]];
        for (let t = 0; t <= len + 0.01; t += 1) for (let o = -rr; o <= rr + 0.01; o += 1) pts.push([dv[0] * t + nv[0] * o, dv[1] * t + nv[1] * o]);
      }
      const poses = [[0, 0], [st.jaw.open / 2, 0], [st.jaw.open, 0], [0, 3], [0, 6], [0, 10], [0, 15], [0, 21]];
      for (const [th, sl] of poses) {
        const c = Math.cos(-th * D2R), sn = Math.sin(-th * D2R);
        for (const [py, pz] of pts) {
          const ry = py * c - pz * sn - ins[0] * sl, rz = py * sn + pz * c - ins[1] * sl;
          const an = Math.atan2(rz, ry) / D2R;
          if (Math.hypot(ry, rz) > Rb - g && an > -93 && an < 60) continue;
          const p = lw([0, yhL + ry, zhL + rz]); if (dIn(0, p[1], p[2]) >= 0) continue;
          let x0 = 0, x1 = 80; for (let i = 0; i < 26; i++) { const xm = (x0 + x1) / 2; if (dIn(xm, p[1], p[2]) < 0) x0 = xm; else x1 = xm; }
          aMin = Math.min(aMin, x0);
        }
      }
    }
    const tR = 5.0, tL = 3.6, spT = 3.2;
    const pinD = 4.0, pinBarb = 1.5;
    const aReq = (tR - 0.1 + SV.hubH + SV.towerTop + tL + pinBarb + 0.8) / 2;
    const aMax = aMin - g - 0.2;
    const a = Math.min(aMax, aReq + 0.6);
    const hpX0 = a - tR + 0.1;
    const towerX = hpX0 - SV.hubH;
    const xs = towerX - spT / 2 - (SV.towerTop - SV.flZ);
    const servoBot = xs + spT / 2 - SV.flZ;
    if (aMax < aReq) errs.push('head too narrow at the jaw hinge for the servo and pivot pin: raise the scale to about ' + (S * (aReq + g + 0.2) / Math.max(1, aMax + g + 0.2)).toFixed(2) + ' or widen the cheeks (short by ' + (2 * (aReq - aMax)).toFixed(1) + ' mm)');
    notes.push('jaw arms at +-' + a.toFixed(1) + ' mm, room for +-' + aMax.toFixed(1));

    /* servo + horn stand-ins, head frame */
    const sv = {};
    {
      const off = SV.shaftOff, Lb = SV.L, cyL = yhL + off - Lb / 2;
      const body = box(servoBot, servoBot + SV.H, yhL + off - Lb, yhL + off, zhL - SV.W / 2, zhL + SV.W / 2);
      const fl = box(servoBot + SV.flZ, servoBot + SV.flZ + SV.flT, cyL - SV.flL / 2, cyL + SV.flL / 2, zhL - SV.W / 2, zhL + SV.W / 2);
      const holes = U([cylX(1.0, servoBot + SV.flZ - 1, servoBot + SV.flZ + SV.flT + 1, cyL - SV.holeSpan / 2, zhL, 16), cylX(1.0, servoBot + SV.flZ - 1, servoBot + SV.flZ + SV.flT + 1, cyL + SV.holeSpan / 2, zhL, 16)]);
      const tower = cylX(SV.towerD / 2, servoBot + SV.H - 0.1, servoBot + SV.towerTop, yhL, zhL);
      const spline = cylX(2.4, servoBot + SV.towerTop - 0.1, servoBot + SV.shaftTop, yhL, zhL, 20);
      sv.servoL = U([K(U([body, fl]).subtract(holes)), tower, spline]);
      const hornCS = K(K(CrossSection.hull([circ2(SV.hubD / 2, 0, 0, 32), circ2(SV.plateW1 / 2, SV.plateLen - SV.plateW1 / 2, 0, 24)])).rotate(hornDir).translate([yhL, zhL]));
      sv.hornCS = hornCS;
      const plate = yzExtrude(hornCS, hpX0, hpX0 + SV.plateT);
      const hub = cylX(SV.hubD / 2, towerX - 0.05, hpX0 + 0.05, yhL, zhL);
      const head = cylX(SV.headD / 2, hpX0 + SV.plateT - 0.05, hpX0 + SV.plateT + SV.headH, yhL, zhL, 24);
      sv.hornL = U([plate, hub, head]);
      sv.flHolesL = [[cyL - SV.holeSpan / 2, zhL], [cyL + SV.holeSpan / 2, zhL]];
      sv.bodyL = { y0: yhL + off - Lb, y1: yhL + off, z0: zhL - SV.W / 2, z1: zhL + SV.W / 2, fy0: cyL - SV.flL / 2, fy1: cyL + SV.flL / 2 };
    }
    const servoW = L2W(sv.servoL), hornW = L2W(sv.hornL);

    /* ------------------------------------------------ jaw */
    function armCS() {
      const ad = [Math.cos(armDir * D2R), Math.sin(armDir * D2R)];
      const bar = K(CrossSection.hull([circ2(5.4, yhL, zhL, 32), circ2(5.2, yhL + ad[0] * Rarm, zhL + ad[1] * Rarm, 32)]));
      return K(K(circ2(RHUB, yhL, zhL, 48).add(bar)).intersect(halfPlane2([mouth0[0] - mNup[0] * 0.03, mouth0[1] - mNup[1] * 0.03], [-mNup[0], -mNup[1]])));
    }
    let jawW, jawSolidVol = 0, jawVoid = null, jawRemoved = 0, jawOpen = false;
    {
      const aCS = armCS();
      const solid = K(outerFull.intersect(Jm));
      const armR = yzExtrude(aCS, a - tR, a);
      const armLft = yzExtrude(aCS, -a, -a + tL);
      // servo body pocket, swept along the insertion path so the jaw slides past the servo onto the horn
      const Rk = 13.4;
      const stub = K(CrossSection.hull([circ2(Rk, yhL, zhL, 64), circ2(Rk, yhL + ins[0] * 60, zhL + ins[1] * 60, 64)]));
      const pocket = yzExtrude(stub, servoBot - 1.2, a - tR + 0.01);
      // horn groove in the right arm: plate, hub and screw head swept along the insertion path; 0.7 of x slack for servo clones
      const hr = K(sv.hornCS.offset(0.3, 'Round'));
      const gr1 = K(CrossSection.hull([hr, K(hr.translate([ins[0] * 40, ins[1] * 40]))]));
      const groove = yzExtrude(gr1, a - tR - 0.5, hpX0 + SV.plateT + 0.6);
      const hd = K(CrossSection.hull([circ2(SV.headD / 2 + 0.5, yhL, zhL, 24), circ2(SV.headD / 2 + 0.5, yhL + ins[0] * 40, zhL + ins[1] * 40, 24)]));
      const headPk = yzExtrude(hd, hpX0 + SV.plateT - 0.1, hpX0 + SV.plateT + SV.headH + 0.5);
      // left arm: bore for the printed pivot pin, teardropped toward the jaw's print-up so it prints round
      const upJ = [-mNup[0], -mNup[1]];
      const bore = K(CrossSection.hull([circ2(pinD / 2 + 0.25, yhL, zhL, 32), circ2(0.2, yhL + upJ[0] * (pinD / 2 + 0.25) * 1.414, zhL + upJ[1] * (pinD / 2 + 0.25) * 1.414, 8)]));
      const boreM = yzExtrude(bore, -a - 1, -a + tL + 1);
      jawW = K(K(Manifold.union([solid, L2W(armR), L2W(armLft)])).subtract(L2W(U([pocket, groove, headPk, boreM]))));
      jawSolidVol = jawW.volume();
      // shell: the lower jaw is a skin of even wall. 'channel' opens it through the mouth face like a real lower jaw,
      // a U trough between the two sides with a thicker lip rim and the tongue groove down the middle; 'sealed'
      // keeps a solid mouth face over a closed void. The jaw prints mouth face down, so the trough's floor (its
      // ceiling on the bed) is tented at 45 degrees up to a 10 mm bridged strip: no support either way.
      const jawShell = st.jaw.shell || (st.jaw.hollow === false ? 'solid' : 'channel');
      if (jawShell !== 'solid') {
        const open = jawShell === 'channel';
        const jw = Math.max(1.6, st.jaw.wall);
        const bridgeW = 8;   // the roof's ridge is a flat strip this wide: a short internal bridge any slicer prints
        const invL = mat4inv(L2Wm);
        const hOf = q => -((q[1] - mouth0[0]) * mNup[0] + (q[2] - mouth0[1]) * mNup[1]);
        const sOf = q => (q[1] - mouth0[0]) * md[1] + (q[2] - mouth0[1]) * md[2];
        const fIn = p => d(p[0], p[1], p[2]) + jw;
        const rimW = open ? 1.0 : 0, rimH = 3.0;   // lip rim: the wall widens by rimW over the last rimH at the mouth
        const sLen = Math.hypot(mouth1[0] - mouth0[0], mouth1[1] - mouth0[1]) + 20;
        const top = [];
        for (let si = 0; si <= Math.ceil(sLen); si++) {
          let best = -5;
          for (let h = 0; h < 70 * S; h += 0.25) { const ql = [0, mouth0[0] + md[1] * si - mNup[0] * h, mouth0[1] + md[2] * si - mNup[1] * h]; if (fIn(lw(ql)) < 0) best = h; else if (best > 0) break; }
          top.push(best);
        }
        const topH = sv0 => { const t = Math.max(0, Math.min(top.length - 1.001, sv0)), i = Math.floor(t), f = t - i; return top[i] * (1 - f) + top[i + 1] * f; };
        const V = p => { const q = mat4apply(invL, p); const h = hOf(q), sv0 = sOf(q); return Math.max(fIn(p) + rimW * Math.max(0, 1 - Math.max(0, h) / rimH), (h + Math.max(0, Math.abs(p[0]) - bridgeW / 2) - topH(sv0)) * Math.SQRT1_2); };
        const jb = jawW.boundingBox();
        const vb = { min: [jb.min[0] - 2, jb.min[1] - 2, jb.min[2] - 2], max: [jb.max[0] + 2, jb.max[1] + 2, jb.max[2] + 2] };
        let voidM = K(Manifold.levelSet(p => -V(p), vb, fine ? 0.9 : 1.2, 0));
        // keep-outs: the servo pocket's reach round the hinge for the full width, and the arms' reach at the sides only
        const armIn = Math.min(a - tR, a - tL) - jw;
        const keep = U([cylX(13.4 + jw, -BIG / 4, BIG / 4, yhL, zhL, 64), cylX(Rarm + 5.6 + jw, armIn, BIG / 4, yhL, zhL, 64), cylX(Rarm + 5.6 + jw, -BIG / 4, -armIn, yhL, zhL, 64)]);
        let reg = jawRegion(-jw);
        if (open) {   // the mouth plane is not kept: the trough breaks through the mouth face
          const rd = [Math.cos(phiR * D2R), Math.sin(phiR * D2R)], rn = [-rd[1], rd[0]], off = -jw;
          const bP = halfPlane2([yhL - rn[0] * off, zhL - rn[1] * off], rn), cP = halfPlane2([yhL - off, zhL], [1, 0]);
          const aP = halfPlane2([mouth0[0] + mNup[0] * 4, mouth0[1] + mNup[1] * 4], [-mNup[0], -mNup[1]]);
          reg = K(K(K(aP.intersect(bP)).intersect(cP)).subtract(circ2(Rb + jw, yhL, zhL, 64)));
        }
        voidM = K(K(voidM.intersect(L2W(yzExtrude(reg, -BIG / 4, BIG / 4)))).subtract(L2W(keep)));
        voidM = K(voidM.subtract(L2W(U([K(pocket), K(groove), K(boreM)]))));
        { const parts = voidM.decompose(); for (const q of parts) track.push(q); const big = parts.filter(q => q.volume() > 400); voidM = big.length ? U(big) : K(Manifold.cube([0.001, 0.001, 0.001])); }   // drop slivers left between keep-outs
        if (!voidM.isEmpty() && voidM.volume() > 50) { const before = jawW.volume(); jawW = K(jawW.subtract(voidM)); jawVoid = voidM; jawRemoved = before - jawW.volume(); jawOpen = open; }
      }
    }
    mark('jaw');

    /* ------------------------------------------------ shell features */
    const shellAdd = [], shellSub = [];
    const yUp = [0, 1, 0];
    const rampBoss = (m, outward, len) => K(Manifold.hull([m, K(m.translate(v3.add(v3.mul(yUp, -len), v3.mul(outward, len))))]));
    // hinge pads: left carries the pivot pin, right gives the horn screw a way in
    let xSkinL;
    {
      const pr = 7.2;
      const pR = rampBoss(L2W(cylX(pr, a + g, a + 30, yhL, zhL, 40)), [1, 0, 0], 8);
      const pL = rampBoss(L2W(cylX(pr, -a - 30, -a - g, yhL, zhL, 40)), [-1, 0, 0], 8);
      shellAdd.push(pR, pL);
      xSkinL = -surfAlong(d, [0, H[1], H[2]], [-1, 0, 0])[0];          // outer skin, left, at the hinge
      shellSub.push(cylX(pinD / 2 + 0.05, -xSkinL - 5, -a - g + 0.01, H[1], H[2], 28));    // snug: holes print 0.15 small
      shellSub.push(cylX(3.75, -xSkinL - 5, -xSkinL + 1.5, H[1], H[2], 36));             // counterbore for the pin head
      // no hole on the right cheek: the jaw arm's groove keeps the horn on the spline, so the horn screw is optional
    }
    // mortise + boss for a keyed tenon; frame columns u (width), v (out of the head), w (thickness)
    const MORT = 0.2;
    function mortise(Mw, tw, tt, depth, w0, w1) {
      const lo = box(-tw / 2 - MORT, tw / 2 + MORT, -depth - 0.5, 8, w0 - MORT, w1 + MORT);
      const bo = box(-tw / 2 - 2.6, tw / 2 + 2.6, -depth - 2.6, 3, w0 - 2.6, w1 + 2.6);
      const vdir = v3.norm([Mw[4], Mw[5], Mw[6]]);
      const bm = rampBoss(K(bo.transform(Mw)), vdir, depth + 2), lm = K(lo.transform(Mw));
      shellAdd.push(bm, K(bm.mirror([1, 0, 0])));
      shellSub.push(lm, K(lm.mirror([1, 0, 0])));
    }
    /* antlers */
    const antOn = st.antlers.style !== 'none';
    const pegDepth = 8, antTW = 6.4, antTT = 4.4;
    const kA = S * st.antlers.size;
    let antFrames = [], antInfo = null;
    if (antOn) {
      const sk = BUCKSDF.antlerSkel(st.antlers.style), burr = BUCKSDF.antlerBurr(sk.strokes[0][0][2]);
      const rr = r => Math.max(1.15, r * Math.min(1.25, kA));
      const strokes = sk.strokes.concat(burr.strokes).map(L => L.map(([u, v, r]) => [u * kA, v * kA, rr(r)]));
      const knobs = burr.knobs.map(([u, v, r]) => [u * kA, v * kA, r * Math.min(1.25, kA)]);
      const r0 = strokes[0][0][2];
      antInfo = { strokes, knobs, tip: sk.tip * kA, zc: 0.62 * r0, r0 };
      const o = fw(F.pedicle);
      for (const sg of [1]) {
        const V = v3.norm(lwv(F.antV));
        let Uu = v3.norm(lwv([-0.42, 1, 0.1])); Uu = v3.norm(v3.sub(Uu, v3.mul(V, v3.dot(Uu, V))));
        const W = v3.cross(Uu, V);
        antFrames.push({ sg, M: basis(Uu, V, W, v3.add(o, v3.mul(V, 0.25))) });
      }
      for (const f of antFrames) mortise(mat4mul(f.M, trans([0, 0, -antInfo.zc])), antTW, antTT, pegDepth, 0, antTT);
    }
    /* ears */
    const earOn = st.ears.on;
    const kE = S * st.ears.size, Le = 42 * kE, We = 21 * kE, cup = 3.2 * kE;
    const earTU = 5.6, earTW = 2.6, earDepth = 7, earB = 3.2 * kE + 1.5;   // earB: the flat back plane of the lying-down ear
    let earFrames = [];
    if (earOn) {
      const o = fw(F.earRoot);
      const V = v3.norm(lwv(F.earDir));
      let Wf = v3.norm(lwv([0.55, 1, 0.3])); Wf = v3.norm(v3.sub(Wf, v3.mul(V, v3.dot(Wf, V))));
      const Uu = v3.cross(V, Wf);                 // (u, v, w) right handed: u x v = w
      earFrames.push({ sg: 1, M: basis(Uu, V, Wf, o) });
      for (const f of earFrames) mortise(f.M, earTU, earTW, earDepth, -earB, earTW / 2);   // tenon runs down to the ear's back so it lies on the bed too
    }
    /* eyes: separate almond eyes press into pockets; sculpted eyes are already in the skin */
    const eyeFr = (() => { const E = fw(F.eyeC), Uu = v3.norm(lwv(F.eyeU)), Vv = v3.norm(lwv(F.eyeV)), N = v3.norm(lwv(F.eyeN)); return { E, Uu, Vv, N, M: basis(Uu, Vv, N, E) }; })();
    const eA = F.eyeA * S, eB = F.eyeB * S, eSock = F.socket * S, eR = F.eyeR * S, eProud = F.eyeProud * S;
    const pocketDepth = 2.6;
    const almondCS = (aa, bb, off) => {
      const pts = []; const n = 72;
      for (let i = 0; i < n; i++) { // trace the almond iso-line by bisection along rays
        const th = i / n * 2 * Math.PI, dx = Math.cos(th), dy = Math.sin(th);
        let r0 = 0, r1 = aa * 2; for (let k = 0; k < 30; k++) { const rm = (r0 + r1) / 2; if (BUCKSDF.almond2(dx * rm, dy * rm, aa, bb) - off < 0) r0 = rm; else r1 = rm; }
        pts.push([dx * r0, dy * r0]);
      }
      return fixWind(pts);
    };
    let eyePocketW = null;
    if (sepEyes) {
      const fit = st.eyes.fit;
      const pk = K(K(Manifold.extrude(almondCS(eA, eB, fit), pocketDepth + 8)).translate([0, 0, -eSock - pocketDepth]));
      const bossM = K(K(Manifold.extrude(almondCS(eA, eB, 2.4), pocketDepth + 1.6)).translate([0, 0, -eSock - pocketDepth - 1.6]));
      const pR = K(pk.transform(eyeFr.M));
      eyePocketW = K(pR.add(K(pR.mirror([1, 0, 0]))));
      const bR = rampBoss(K(bossM.transform(eyeFr.M)), eyeFr.N, 6);
      shellAdd.push(bR, K(bR.mirror([1, 0, 0])));
      shellSub.push(eyePocketW);
    }
    /* nose: separate cap keyed onto a peg on the muzzle */
    const noseHalf = K(K(Manifold.cube([BIG, BIG, BIG])).translate([-BIG / 2, -BIG / 2, 0]).transform(basis(...(() => { const w = axW; const u = [1, 0, 0]; const v = v3.cross(w, u); return [u, v, w, noseP]; })())));
    const noseUp = v3.norm(v3.cross([1, 0, 0], axW));   // perpendicular to the muzzle, pointing up
    let pegC = null, pegM = null, sockM = null;
    const pegD = 5.0, pegH = 4.0;
    if (sepNose) {
      // centre the peg in the solid part of the cut face, above the mouth seam
      let best = null, bd = -1;
      for (let t = -6; t <= 10; t += 0.25) {
        const p = v3.add(noseP, v3.mul(noseUp, t));
        let r = 0; for (let k = 0; k < 16; k++) { const an = k / 16 * 2 * Math.PI; const q = v3.add(p, v3.add(v3.mul([1, 0, 0], Math.cos(an) * (r + 0.5)), v3.mul(noseUp, Math.sin(an) * (r + 0.5)))); }
        // radius of solid around p in the cut plane: inside skin by the margin and clear of the jaw cut
        let rad = 0; for (let rr2 = 0.5; rr2 < 12; rr2 += 0.25) { let ok = true; for (let k = 0; k < 24 && ok; k++) { const an = k / 24 * 2 * Math.PI; const q = v3.add(p, v3.add(v3.mul([1, 0, 0], Math.cos(an) * rr2), v3.mul(noseUp, Math.sin(an) * rr2))); if (d(q[0], q[1], q[2]) > -0.2) ok = false; const ql = mat4apply(mat4inv(L2Wm), q); if ((ql[1] - mouth0[0]) * mNup[0] + (ql[2] - mouth0[1]) * mNup[1] < g + 0.4) ok = false; } if (!ok) break; rad = rr2; }
        if (rad > bd) { bd = rad; best = p; }
      }
      pegC = best;
      const Mpeg = basis([1, 0, 0], noseUp, axW, pegC);
      if (bd < pegD / 2 + 1.6) warns.push('nose peg has only ' + (bd - pegD / 2).toFixed(1) + ' mm of wall around it');
      const pegShape = K(K(Manifold.cylinder(pegH, pegD / 2, pegD / 2 - 0.3, 40)).transform(Mpeg));
      pegM = K(K(pegShape.add(K(K(Manifold.cylinder(1.2, pegD / 2, pegD / 2, 40)).translate([0, 0, -1.19]).transform(Mpeg)))));
      sockM = K(K(Manifold.cylinder(pegH + 0.4, pegD / 2 + st.nose.fit, pegD / 2 + st.nose.fit, 40)).translate([0, 0, -0.01]).transform(Mpeg));
    }

    /* speaker and amp stack, low in the neck against the plaque.
     * The speaker lies face down on a seat ring and its two ears screw to bosses; it slides in from the side.
     * Above it a shelf carries the NS4168 on two posts whose spigots sit in the board's 4.7 mm holes. */
    const SPK = st.speaker;
    const fr = SPK.frame, span = SPK.span, coneR = SPK.cone / 2, spDepth = SPK.depth;
    const spFl = 1.6, seatH = Math.max(1.2, SPK.dome + 0.6), earDrop = 3.0, earR = 3.2, spHead = SPK.dome + 0.6;
    const spY = 1.4 + fr / 2, spY1 = spY + fr / 2;
    const amStand = 3.5, shT = 2.0, lipClearY = 4.5 + 0.4;
    const ampDX = 0;
    const xA0 = -AM.L / 2 + ampDX, xA1 = AM.L / 2 + ampDX, yA0 = 3.6, yA1 = yA0 + AM.W, shY1 = yA1 + 1.2, shXa = xA0 - 1.5, shXb = xA1 + 1.5;
    function cavFree(x0, x1, z0, z1, y1, y0) {
      const nx = Math.max(1, Math.ceil((x1 - x0) / 1.5)), nz = Math.max(1, Math.ceil((z1 - z0) / 1.5));
      for (let i = 0; i <= nx; i++) for (let k = 0; k <= nz; k++) { const x = x0 + (x1 - x0) * i / nx, z = z0 + (z1 - z0) * k / nz;
        for (let y = y0 || 0; y <= y1 + 0.01; y += 1.5) if (dIn(x, y, z) > -g - 0.5) return false; }
      return true;
    }
    const stackAt = z => {
      const sTop = z + spFl + seatH + spDepth, shZ0 = sTop + spHead + 0.4, shZ1 = shZ0 + shT, pcbZ0 = shZ1 + amStand, pcbZ1 = pcbZ0 + AM.t;
      return { z, sTop, shZ0, shZ1, pcbZ0, pcbZ1, compZ1: pcbZ1 + AM.comp };
    };
    let trayZ = null, SK = null;
    for (let z = -80 * S; z < 0; z += 0.5) {
      const k = stackAt(z);
      if (!cavFree(-fr / 2 - 1.6, fr / 2 + 1.6, z - earDrop, k.sTop + 0.5, spY1 + 1.2)) continue;
      if (!cavFree(-span / 2 - earR, span / 2 + earR, z - earDrop, z + spFl + seatH + 1.0, spY + earR)) continue;
      if (!cavFree(shXa, shXb, k.shZ0, k.compZ1 + 0.5, shY1)) continue;                        // shelf, board, terminal
      if (!cavFree(xA0 - 8, xA1 + 8, k.pcbZ1, k.pcbZ1 + AM.ph + 0.5, yA0 + 18)) continue;      // the two PH plugs off the ends
      trayZ = z; SK = k; break;
    }
    if (trayZ === null) { errs.push('the speaker and the NS4168 do not fit in the neck: raise the scale or the neck'); trayZ = -20; SK = stackAt(trayZ); }
    // the amp goes in from the +x side, so only its -x half (the input PH, posts and chip) ever crosses the fin plane:
    // the fin is cut away under that, plus the 1.5 mm lift over the spigots
    const finKeepZ = SK.pcbZ1 + AM.ph + 2.0;
    const ampHoles = AM.holeY.map(hy => [xA0 + AM.holeX, yA0 + hy]);
    const grilleR = coneR - 0.4;
    function grille(z0, z1) {
      const sl = [];
      for (let x = -grilleR + 1.2; x <= grilleR - 1.2 + 0.01; x += 3.2) { const hl = Math.sqrt(Math.max(0, grilleR * grilleR - x * x)) - 1.0; if (hl < 2) continue; sl.push(box(x - 0.8, x + 0.8, spY - hl, spY + hl, z0, z1)); }
      return U(sl);
    }
    shellSub.push(grille(-90 * S, trayZ - earDrop - 0.6));

    /* assemble the head */
    const cavity = K(inner.subtract(U(shellAdd)));
    const headCut = U([cavity, Jgm, ...shellSub, sepNose ? noseHalf : null]);
    let shell = K(outer.subtract(headCut));
    if (pegM) shell = K(shell.add(K(pegM.subtract(Jgm))));
    let nose = null;
    if (sepNose) { nose = K(K(outer.intersect(K(noseHalf.translate(v3.mul(axW, 0.001))))).subtract(Jgm)); nose = K(nose.subtract(sockM)); }
    mark('head');

    /* ------------------------------------------------ controller on the fin */
    // The controller sticks (foam tape or hot glue) onto a narrow plinth on the left face of the fin, USB toward
    // the plaque. The plinth is narrower than the pin rows, so every pin and edge pad is left open for wiring.
    const spineX0 = xs - spT / 2, spineX1 = xs + spT / 2;
    const so = 3.6, comp = 4.2, yb0 = 10;
    const svBB = servoW.boundingBox();
    const usbHalfZ = 3.3;
    function boardSlot(B, side) {
      const pcbT = B.t || 1.6, face = side < 0 ? spineX0 : spineX1, pcbMid = face + side * (so + pcbT / 2);
      let best = null;
      const xa = Math.min(face, pcbMid + side * (pcbT / 2 + comp)), xb = Math.max(face, pcbMid + side * (pcbT / 2 + comp));
      for (let zc = 60 * S; zc > -40 * S; zc -= 0.5) {
        const z0 = zc - B.W / 2 - 1.0, z1 = zc + B.W / 2 + 1.0, y1 = yb0 + B.L + 1;
        if (z0 < SK.pcbZ1 + 2.6 || zc - Math.min(4.5, B.W / 2 - 3.5) < finKeepZ + 0.2) break;   // board over the amp's screw heads, plinth on solid fin
        if (yb0 < spY1 + 1 && z0 < SK.sTop + 0.8) continue;
        const hitsServo = !(xb < svBB.min[0] - 0.6 || xa > svBB.max[0] + 0.6 || y1 < svBB.min[1] - 0.6 || yb0 > svBB.max[1] + 0.6 || z1 < svBB.min[2] - 0.6 || z0 > svBB.max[2] + 0.6) && hit(box(xa - 0.6, xb + 0.6, yb0, y1 + 0.6, z0 - 0.6, z1 + 0.6), servoW) > 0.01;
        if (hitsServo) continue;
        if (cavFree(xa, xb, z0 - 1.8, z1 + 1.8, y1)) { best = zc; break; }
      }
      return { B, side, face, pcbMid, pcbT, zc: best };
    }
    const esp = boardSlot(BD, -1);
    if (esp.zc === null) errs.push('controller board does not fit on the fin above the amp: raise the scale or the neck');
    let plinth = null;
    if (esp.zc !== null) {
      const hw2 = Math.min(4.5, BD.W / 2 - 3.5), f = esp.face;
      plinth = K(Manifold.hull([box(f - so, f + 0.4, yb0 + 3, yb0 + BD.L - 1, esp.zc - hw2, esp.zc + hw2), box(f - 0.01, f + 0.4, yb0 + 3 - so, yb0 + BD.L - 1, esp.zc - hw2, esp.zc + hw2)]));   // 45 degree underside
      // a gap where the screwdriver comes down onto the amp screw below
      plinth = K(plinth.subtract(U(ampHoles.map(([hx, hy]) => cylZ(2.1, -BIG, BIG, hx, hy, 20)))));
    }

    /* fin */
    const flP = sv.flHolesL.map(q => lw([0, q[0], q[1]]));
    const bb = sv.bodyL;
    const corners = [[bb.fy0, bb.z0 - 3.2], [bb.fy1, bb.z0 - 3.2], [bb.fy1, bb.z1 + 3.2], [bb.fy0, bb.z1 + 3.2]].map(q => lw([0, q[0], q[1]]));
    let topZ = Math.max(...corners.map(q => q[2]), SK.compZ1 + 9);
    if (esp.zc !== null) topZ = Math.max(topZ, esp.zc + BD.W / 2 + 1.6);
    const botZ = Math.min(...corners.map(q => q[2]), SK.shZ0);
    let spineCS = K(CrossSection.hull([CS(fixWindPts([[-0.5, botZ], [corners[0][1], corners[0][2]], [corners[1][1], corners[1][2]], [corners[2][1], corners[2][2]], [corners[3][1], corners[3][2]], [-0.5, topZ]]))]));
    const railTopY = yb0 + BD.L + 1.7;
    spineCS = K(spineCS.add(CS(fixWindPts([[-0.5, SK.shZ0], [railTopY, SK.shZ0], [railTopY, topZ], [-0.5, topZ]]))));
    const hingeYZ = [H[1], H[2]], ct = Math.cos(tilt * D2R), stt = Math.sin(tilt * D2R);
    spineCS = K(spineCS.intersect(K(halfPlane2(hingeYZ, [-ct, stt]).add(circ2(12.2, hingeYZ[0], hingeYZ[1], 64)))));
    const wc = [[0, 0], [1, 0], [1, 1], [0, 1]].map(([i, j]) => { const y = yhL + SV.shaftOff - SV.L - 0.3 + i * (SV.L + 0.6), z = zhL - SV.W / 2 - 0.3 + j * (SV.W + 0.6); const w = lw([0, y, z]); return [w[1], w[2]]; });
    {
      const zz0 = Math.floor(botZ) - 1, zz1 = Math.ceil(topZ) + 1, prof = [];
      for (let z = zz0; z <= zz1; z += 0.75) {
        let y = 0;
        for (; y < 160 * S; y += 0.5) { let ok = true; for (const x of [spineX0 - g, xs, spineX1 + g]) if (dIn(x, y, z) > -g) { ok = false; break; } if (!ok) break; }
        prof.push([Math.max(0, y - 0.5), z]);
      }
      spineCS = K(spineCS.intersect(CS(fixWindPts([[-1, zz0], ...prof, [-1, zz1]]))));
    }
    spineCS = K(spineCS.subtract(CS(fixWindPts(wc))));
    // keep-outs: the amp and its slide-in path above the shelf, and the speaker and its lift under it
    const rect = (y0, y1, z0, z1) => CS(fixWindPts([[y0, z0], [y1, z0], [y1, z1], [y0, z1]]));
    spineCS = K(spineCS.subtract(rect(-5, yA1 + (lipClearY - yA0) + 0.5, SK.shZ1 - 0.01, finKeepZ)));
    spineCS = K(spineCS.subtract(rect(-5, spY1 + (lipClearY - (spY - fr / 2)) + 0.6, -200, SK.shZ0 + 0.01)));
    let spine = yzExtrude(spineCS, spineX0, spineX1);
    for (const q of flP) spine = K(spine.subtract(cylX(0.85, spineX0 - 1, spineX1 + 1, q[1], q[2], 16)));     // pilots for the servo's own 2 mm screws
    for (const zt of [topZ - 6]) spine = K(spine.subtract(box(spineX0 - 1, spineX1 + 1, 4, 7.5, zt - 1.5, zt + 1.5)));   // wire tie-down slot

    /* speaker seat */
    let tray;
    const seatTop = trayZ + spFl + seatH;
    const earXs = [-span / 2, span / 2];
    {
      const z0 = trayZ, zF = z0 + spFl;
      const floor = box(-fr / 2 - 1.5, fr / 2 + 1.5, -0.5, spY1 + 1.0, z0, zF);
      const bridges = U(earXs.map(ex => box(Math.min(ex, 0), Math.max(ex, 0), spY - earR, spY + earR, z0, zF)));
      const pads = U(earXs.map(ex => tearZ(earR, z0 - earDrop, seatTop, ex, spY)));
      const ringHole = K(K(Manifold.extrude(K(CrossSection.hull([K(CrossSection.circle(coneR + 1.2, 64).translate([0, spY])), K(CrossSection.circle(0.05, 8).translate([0, spY + (coneR + 1.2) * Math.SQRT2]))])), seatTop - zF + 2)).translate([0, 0, zF - 1]));
      const ring = K(box(-fr / 2 + 0.3, fr / 2 - 0.3, -0.5, spY + fr / 2 - 0.3, zF - 0.01, seatTop).subtract(ringHole));   // pointed toward print-up so the arch needs no support
      const stop = box(-fr / 2 + 2, fr / 2 - 2, -0.5, 1.0, zF - 0.01, seatTop + 2.5);
      const ribs = U([-1, 1].map(sx => box(sx * (coneR + 1.0) - 0.8, sx * (coneR + 1.0) + 0.8, -0.5, spY1 + 1.0, z0 - earDrop, z0 + 0.01)));
      const pil = U(earXs.map(ex => cylZ(SPK.hole / 2 - 0.25, z0 - earDrop + 0.8, seatTop + 1, ex, spY, 16)));
      tray = K(U([floor, bridges, pads, ring, stop, ribs]).subtract(U([grille(z0 - earDrop - 1, zF + 0.1), pil])));
    }
    /* amp shelf */
    let ampShelf;
    {
      let plate = box(shXa, shXb, -0.5, shY1, SK.shZ0, SK.shZ1);
      // screwdriver holes over the speaker's ear screws (the speaker goes in first)
      plate = K(plate.subtract(U(earXs.map(ex => K(tearZ(3.0, SK.shZ0 - 1, SK.shZ1 + 1, ex, spY).mirror([0, 1, 0]).translate([0, 2 * spY, 0]))))));
      // posts and spigots print lying down: teardrop posts, spigots with a flat underside that stays inside the hole
      const posts = U(ampHoles.map(([hx, hy]) => U([tearZ(3.4, SK.shZ1 - 0.01, SK.pcbZ0, hx, hy), tearZ(AM.holeD / 2 - 0.15, SK.pcbZ0 - 0.01, SK.pcbZ0 + 1.3, hx, hy, AM.holeD / 2 - 0.25)])));
      const pil = U(ampHoles.map(([hx, hy]) => cylZ(1.25, SK.shZ0 + 0.6, SK.pcbZ0 + 2, hx, hy, 20)));
      ampShelf = K(U([plate, posts]).subtract(pil));
    }

    /* ------------------------------------------------ plaque */
    const T = st.mount.thick;
    const neckSl = K(K(outer.rotate([90, 0, 0])).slice(0.35));
    const nbx = neckSl.bounds();
    const nx0 = nbx.min[0], nx1 = nbx.max[0], nz0 = -nbx.max[1], nz1 = -nbx.min[1];
    // sized off the neck: the neck takes up 'fill' of the plaque width, the margins follow from that so the
    // plaque frames the head like a trophy shield instead of hugging the neck
    const pitch = st.mount.pitchIn * 25.4;
    const hookMode = st.mount.hang;
    const hookBand = hookMode === 'hooks' ? 16 : hookMode === 'holes' ? 4 : 0;
    const hn = Math.max(-nx0, nx1), fill = Math.min(0.85, Math.max(0.45, st.mount.fill || 0.62));
    const phw = Math.max(hn / fill, hookMode !== 'none' ? pitch / 2 + 9 : 0);
    const margin = phw - hn;
    const zTop = nz1 + Math.max(0.85 * margin, hookBand + 6), zBot = nz0 - 0.45 * margin;
    let outline;
    if (st.mount.shape === 'shield') {
      const r = Math.max(7, margin * 0.3);
      outline = K(CrossSection.hull([circ2(r, -phw + r, zTop - r, 40), circ2(r, phw - r, zTop - r, 40), circ2(r, -phw + r, zBot + (zTop - zBot) * 0.3, 40), circ2(r, phw - r, zBot + (zTop - zBot) * 0.3, 40), circ2(r * 0.8, 0, nz0 - 1.6 * margin, 40)]));
    } else if (st.mount.shape === 'oval') {
      const cz = (zTop + zBot - 8) / 2, rz = (zTop - zBot + 8) / 2;
      outline = K(K(CrossSection.circle(1, 128).scale([phw * 1.06, rz])).translate([0, cz]));
    } else {
      const r = 10;
      outline = K(CrossSection.hull([circ2(r, -phw + r, zTop - r, 32), circ2(r, phw - r, zTop - r, 32), circ2(r, -phw + r, zBot - 4 + r, 32), circ2(r, phw - r, zBot - 4 + r, 32)]));
    }
    const ob = outline.bounds();
    { const pw = ob.max[0] - ob.min[0], ph = ob.max[1] - ob.min[1], lim = Math.min(st.print.bedW, st.print.bedD) - 12; if (Math.max(pw, ph) > lim || Math.min(pw, ph) > Math.max(st.print.bedW, st.print.bedD) - 12) warns.push('plaque is ' + pw.toFixed(0) + ' x ' + ph.toFixed(0) + ' mm, bigger than the bed: raise neck fill or lower the scale'); }
    // routed edge profile, layer exact: straight from the back, then the profile steps in toward the face
    let plaque;
    {
      const lh = 0.24, prof = st.mount.edge;
      const hE = prof === 'square' ? 0 : Math.min(4.08, T - 2.4), base = T - hE;
      const slabs = [xzExtrude(outline, -T, -hE + 0.02)];
      const nst = Math.round(hE / lh);
      for (let i = 0; i < nst; i++) {
        const t = (i + 0.5) / nst;
        let ins = 0;
        if (prof === 'ogee') ins = 3.0 * (t - Math.sin(2 * Math.PI * t) / (2 * Math.PI));
        else if (prof === 'chamfer') ins = 3.0 * t;
        else if (prof === 'round') ins = 3.0 * (1 - Math.sqrt(Math.max(0, 1 - t * t)));
        const y0 = -hE + i * lh, y1 = Math.min(0, y0 + lh + 0.02);
        slabs.push(xzExtrude(ins > 0.01 ? K(outline.offset(-ins, 'Round', 2, 48)) : outline, y0, y1));
      }
      plaque = U(slabs);
      void base;
      if (st.mount.groove) { // a V line routed into the face, 0.72 deep, layer stepped
        const gi = Math.min(10, Math.max(6, 0.24 * margin)), steps = 3;
        const cuts = [];
        for (let i = 0; i < steps; i++) { const w = 0.2 + i * 0.22; cuts.push(xzExtrude(K(K(outline.offset(-gi + w, 'Round', 2, 48)).subtract(K(outline.offset(-gi - w, 'Round', 2, 48)))), -0.72 + i * 0.24, 0.5)); }
        plaque = K(plaque.subtract(U(cuts)));
      }
    }
    // locating lip the neck rim slides over, with the snap bead on its flanks
    const lipH = 4.5, lipT = 2.0;
    let lipInfo = {}, screwPts = null, screwInfo = null;
    {
      const inSl = K(K(inner.rotate([90, 0, 0])).slice(lipH + 0.2));
      const inCS = K(inSl.scale([1, -1]));
      const lipOut = K(inCS.offset(-g, 'Round')), lipIn = K(inCS.offset(-g - lipT, 'Round'));
      let lipCS = K(lipOut.subtract(lipIn));
      const lb = lipOut.bounds();
      // screw points: three bosses inside the neck rim (two high, one low) take M3 screws driven from the back of the
      // plaque. Found by casting rays from the middle of the rim to its inside wall at fixed angles.
      if (st.mount.attach !== 'snap') {
        const polys = inCS.toPolygons(); let big = polys[0], ba = 0;
        for (const pl of polys) { let a2 = 0; for (let i = 0; i < pl.length; i++) { const P1 = pl[i], P2 = pl[(i + 1) % pl.length]; a2 += P1[0] * P2[1] - P2[0] * P1[1]; } if (Math.abs(a2) > ba) { ba = Math.abs(a2); big = pl; } }
        const cx0 = 0, cz0 = (lb.min[1] + lb.max[1]) / 2;
        const rayHit = (th) => { const dx = Math.cos(th), dz = Math.sin(th); let best = 1e9; for (let i = 0; i < big.length; i++) { const A = big[i], B = big[(i + 1) % big.length]; const ex = B[0] - A[0], ez = B[1] - A[1]; const den = dx * ez - dz * ex; if (Math.abs(den) < 1e-9) continue; const t = ((A[0] - cx0) * ez - (A[1] - cz0) * ex) / den, u = ((A[0] - cx0) * dz - (A[1] - cz0) * dx) / den; if (t > 0 && u >= 0 && u <= 1) best = Math.min(best, t); } return best; };
        const bossR = 4.6, ang = [90, 232, 308];   // top centre over the fin, two low ones either side of the grille
        screwPts = ang.map(a3 => { const th = a3 * D2R, t = rayHit(th) - (bossR - 1.4); return [cx0 + Math.cos(th) * t, cz0 + Math.sin(th) * t]; });
        lipCS = K(lipCS.subtract(K(CrossSection.union(screwPts.map(([x, z]) => circ2(bossR + 0.8, x, z, 32))))));
        screwInfo = { bossR, bossL: 12.5, pilotR: 1.25, holeR: 1.75, sinkR: 3.2 };
      }
      plaque = K(plaque.add(xzExtrude(lipCS, -0.02, lipH)));
      lipInfo = { lipOut, lb };
      // snap beads on the left and right flanks: layer stepped, 45 degree flanks both ways
      const b1 = st.mount.snap * 0.55, sideX = (lb.max[0] - lb.min[0]) * 0.5 * 0.55;
      const sideBox = K(K(CrossSection.square([BIG, (lb.max[1] - lb.min[1]) * 0.45], false)).translate([sideX, (lb.max[1] + lb.min[1]) / 2 - (lb.max[1] - lb.min[1]) * 0.225]));
      const sides = K(sideBox.add(K(sideBox.mirror([1, 0]))));
      const steps = [];
      const yc = 3.0, nB = Math.max(1, Math.round(b1 / 0.12));
      for (let i = 0; i < nB; i++) {
        const o = b1 * (1 - i / nB), h = b1 - o;   // ring width o at distance h from the bead centre
        const ring = K(K(K(lipOut.offset(o, 'Round')).subtract(lipIn)).intersect(sides));
        steps.push(xzExtrude(ring, yc - (b1 - o) - 0.12 - 0.01, yc + (b1 - o) + 0.12));
        void h;
      }
      const lipBead = st.mount.attach !== 'snap' ? null : U(steps);
      if (lipBead) plaque = K(plaque.add(lipBead));
      lipInfo.b1 = b1; lipInfo.sides = sides; lipInfo.yc = yc;
    }
    // holes: pegboard hook slot or store peghook holes, keyholes, usb passage
    const pSub = [];
    let hooks = null;
    const hookZ = zTop - 8.5;
    if (hookMode === 'hooks') {
      // dovetail channel across the back, open at both side edges; hooks slide in from the ends
      const D = 4.2, w0 = 7.0, w1 = 10.0, cl = 0.15;
      const dv = (c) => fixWind([[-T - 1, hookZ - w0 / 2 - c], [-T, hookZ - w0 / 2 - c], [-T + D + c, hookZ - w1 / 2 - c], [-T + D + c, hookZ + w1 / 2 + c], [-T, hookZ + w0 / 2 + c], [-T - 1, hookZ + w0 / 2 + c]]);
      pSub.push(yzExtrude(dv(cl), -BIG / 2, BIG / 2));
      hooks = { D, w0, w1, cl };
    } else if (hookMode === 'holes') {
      for (const sx of [-1, 1]) pSub.push(cylY(st.mount.holeD / 2, -T - 1, 3, sx * pitch / 2, hookZ, 40));
    }
    if (st.mount.keyholes) {
      const kz = zBot + (zTop - zBot) * 0.45;
      for (const sx of [-1, 1]) {
        const kx = sx * Math.min(phw - 9, pitch / 2);
        if (Math.abs(kx) < Math.max(-nx0, nx1) + 6) continue;
        pSub.push(cylY(4.3, -T - 1, 2, kx, kz, 32));
        pSub.push(box(kx - 2.1, kx + 2.1, -T - 1, 2, kz, kz + 9));
        pSub.push(xzExtrude(K(CrossSection.hull([circ2(4.3, kx, kz, 32), circ2(4.3, kx, kz + 9, 32)])), -T - 1, -T + 3.2));
      }
    }
    if (screwPts) {
      const si = screwInfo, sinkH = si.sinkR - si.holeR;       // 90 degree countersink for flat head screws
      for (const [x, z] of screwPts) {
        pSub.push(cylY(si.holeR, -T - 1, 1.0, x, z, 24));
        pSub.push(K(K(Manifold.cylinder(sinkH + 0.01, si.sinkR, si.holeR, 32)).rotate([-90, 0, 0]).translate([x, -T - 0.005, z])));
      }
    }
    let usb = null;
    if (esp.zc !== null) {
      const ux = esp.pcbMid + esp.side * (esp.pcbT / 2 + 1.6), uz = esp.zc;
      usb = [ux, uz];
      pSub.push(xzExtrude(K(CrossSection.hull([circ2(4.6, ux - 2.2, uz, 32), circ2(4.6, ux + 2.2, uz, 32)])), -T - 1, 2));
      pSub.push(box(ux - 2.8, ux + 2.8, -T - 1, -T + 4.6, ob.min[1] - 5, uz));
    }
    let mount = U([plaque, spine, tray, ampShelf, plinth]);
    mount = K(mount.subtract(U(pSub)));
    // pry notch: a shallow bay in the plaque face under the bottom of the neck rim (snap only)
    if (!screwPts) {
      const lb = lipInfo.lb;
      mount = K(mount.subtract(box(-4, 4, -1.2, 0.6, lb.min[1] - 5.5, lb.min[1] - 0.2)));
    }
    mark('mount');

    /* ------------------------------------------------ head side of the snap */
    let headBead = null;
    const beadYc = 1.4;
    {
      const inSl = K(K(cavity.rotate([90, 0, 0])).slice(beadYc));
      const inCS = K(inSl.scale([1, -1]));
      const b2 = st.mount.snap * 0.45 + g;     // reaches past the gap so the overlap with the lip bead equals the snap setting
      const steps = [], nB = Math.max(1, Math.round(b2 / 0.12));
      for (let i = 0; i < nB; i++) {
        const o = b2 * (1 - i / nB);
        const band = K(K(inCS.subtract(K(inCS.offset(-o, 'Round')))).intersect(lipInfo.sides));
        steps.push(xzExtrude(band, Math.max(0, beadYc - (b2 - o) - 0.12), beadYc + (b2 - o) + 0.12));   // 45 degree flanks
      }
      headBead = screwPts ? null : U(steps);
      lipInfo.b2 = b2;
    }
    if (screwPts) {
      const si = screwInfo;
      const bosses = U(screwPts.map(([x, z]) => cylY(si.bossR, 0, si.bossL, x, z, 36)));
      shell = K(K(shell.add(K(bosses.intersect(outer)))).subtract(U(screwPts.map(([x, z]) => cylY(si.pilotR, -1, si.bossL - 1.5, x, z, 20)))));
    }
    const shellNoBead = shell;
    if (headBead) shell = K(shell.add(K(headBead.intersect(outer))));

    /* ------------------------------------------------ printed small parts */
    // pivot pin: printed lying on a flat, slit and barbed at the tip; head sits in a counterbore at the cheek
    let pinPrint, pinPlace;
    {
      const x0 = -xSkinL + 0.2, xTip = -a + tL + pinBarb;   // world x span: head (outer) to tip (inner)
      const Lp = xTip - x0;
      const r = pinD / 2, flat = r - 0.3;
      const shaft = K(Manifold.cylinder(Lp, r, r, 40).rotate([0, 90, 0]));
      const headD = 7.0, headT = 1.2;
      const headM = K(Manifold.cylinder(headT, headD / 2, headD / 2, 48).rotate([0, 90, 0]));
      const barb = K(Manifold.cylinder(pinBarb, r + 0.45, r - 0.25, 40).rotate([0, 90, 0]).translate([Lp - pinBarb, 0, 0]));
      let pin = U([shaft, headM, barb]);
      pin = K(pin.intersect(box(-1, Lp + 1, -10, 10, -flat, flat)));                  // flats top and bottom: prints on a flat
      pin = K(pin.subtract(box(Lp - 7.5, Lp + 1, -0.5, 0.5, -10, 10)));               // slit: the prongs flex sideways, in the layers
      pinPrint = K(pin.translate([0, 0, flat]));
      pinPlace = mat4mul(trans([x0, H[1], H[2]]), trans([0, 0, -flat]));
    }
    // pegboard hooks: printed on their side so the hook profile lies in the layers. They clip into the pegboard
    // first, then the plaque's dovetail channel slides on over both from the side.
    let hookPrint = null, hookPlaces = [];
    if (hooks) {
      const tb = PEG.board, sh = PEG.shank, ch = PEG.cham, tip = PEG.tip, D = hooks.D, w0 = hooks.w0, w1 = hooks.w1, cl = hooks.cl;
      // profile in (y, z): y = 0 is the plaque back face (the board face), +y into the plaque, z = 0 the hole centre.
      // The prong is a circular arc about a centre C above the hole: it rolls in through the hole along itself,
      // and the head's weight (which presses the plaque bottom into the board) winds it tighter.
      const Rc = 12, yC = -tb / 2, zC = Rc, ri = Rc - sh / 2, ro = Rc + sh / 2, phiTip = -150 * D2R;
      const tongue = fixWind([[0.1, -w0 / 2 + cl], [D - cl, -w1 / 2 + cl + 0.1], [D - cl, w1 / 2 - cl - 0.1], [0.1, w0 / 2 - cl]]);
      const a0 = -Math.acos(Math.min(1, (0.6 - yC) / Rc)), n = 56, ap = [];
      for (let i = 0; i <= n; i++) { const an = a0 + (phiTip - a0) * i / n; ap.push([yC + ro * Math.cos(an), zC + ro * Math.sin(an)]); }
      for (let i = n; i >= 0; i--) { const an = a0 + (phiTip - a0) * i / n; ap.push([yC + ri * Math.cos(an), zC + ri * Math.sin(an)]); }
      const tipC = [yC + Rc * Math.cos(phiTip), zC + Rc * Math.sin(phiTip)];
      const prof = K(K(tongue.add(fixWind(ap))).add(circ2(sh / 2, tipC[0], tipC[1], 32)));
      const sL = tb;
      void tip;
      // 45 degree chamfers on the long edges, layer stepped, so the square shank passes the round hole
      const lh = 0.2, nC = Math.max(1, Math.round(ch / lh)), wx = sh, slabs = [];
      slabs.push(K(K(Manifold.extrude(prof, wx - 2 * ch + 0.04)).translate([0, 0, ch - 0.02])));
      for (let i = 0; i < nC; i++) {
        const o = ch - (i + 0.5) * (ch / nC), z0 = i * (ch / nC), z1 = z0 + ch / nC + 0.02;
        const pc = K(prof.offset(-o, 'Round'));
        slabs.push(K(K(Manifold.extrude(pc, z1 - z0)).translate([0, 0, z0])), K(K(Manifold.extrude(pc, z1 - z0)).translate([0, 0, wx - z1])));
      }
      hookPrint = U(slabs);
      hooks.sL = sL; hooks.prof = prof; hooks.wx = wx;
      for (const sx of [-1, 1]) hookPlaces.push(basis([0, 1, 0], [0, 0, 1], [1, 0, 0], [sx * pitch / 2 - wx / 2, -T, hookZ]));
    }
    mark('small');

    /* ------------------------------------------------ ears and antlers (cached level sets) */
    const flatKey = JSON.stringify([st.antlers, st.ears, S, fine]);
    if (cache.flatKey !== flatKey) {
      if (cache.antPrint) try { cache.antPrint.delete(); } catch (e) { }
      if (cache.earPrint) try { cache.earPrint.delete(); } catch (e) { }
      cache.antPrint = null; cache.earPrint = null;
      const ed = fine ? 0.45 : 0.6;
      if (antOn) {
        const af = BUCKSDF.antlerField(antInfo.strokes, antInfo.knobs);
        let umin = 1e9, umax = -1e9, vmax = -1e9; for (const L of antInfo.strokes) for (const [u, v, r] of L) { umin = Math.min(umin, u - r - 2); umax = Math.max(umax, u + r + 2); vmax = Math.max(vmax, v + r + 2); }
        const m0 = Manifold.levelSet(p => -Math.max(af(p[0], p[1], p[2]), -p[1]), { min: [umin, -1, -0.6], max: [umax, vmax, antInfo.r0 * 1.7 + 2] }, ed, 0);
        const body = m0.simplify(0.02); m0.delete();
        const ten = Manifold.cube([antTW, pegDepth + 1.2, antTT]).translate([-antTW / 2, -pegDepth, 0]);
        cache.antPrint = Manifold.union([body, ten]); body.delete(); ten.delete();
      }
      if (earOn) {
        // prints lying on its flat back, cup up: print x = u, y = v + depth, z = w + B
        const ef = BUCKSDF.earFieldFlat(Le, We, cup), B = ef.B;
        const m0 = Manifold.levelSet(p => -Math.max(ef(p[0], p[1] - earDepth, p[2] - B), -p[2]), { min: [-We / 2 - 2, earDepth - 1, -0.6], max: [We / 2 + 2, earDepth + Le + 1, B + 4] }, ed, 0);
        const body = m0.simplify(0.02); m0.delete();
        const ten = Manifold.cube([earTU, earDepth + 0.6, B + earTW / 2]).translate([-earTU / 2, 0, 0]);
        cache.earPrint = Manifold.union([body, ten]); body.delete(); ten.delete();
        cache.earField = ef;
      }
      cache.flatKey = flatKey;
    }
    mark('flats');

    /* ------------------------------------------------ hardware stand-ins (viewer only) */
    const hw = { servo: servoW, horn: hornW };
    {
      // speaker: flange on the seat ring, ears on the bosses, dome dropping into the ring, can on the back
      {
        const zf = seatTop, ins = 0.05;
        const flange = box(-fr / 2 + ins, fr / 2 - ins, spY - fr / 2 + ins, spY + fr / 2 - ins, zf + ins, zf + 0.8);
        const ears = U(earXs.map(ex => K(box(Math.min(ex * 1.12, ex > 0 ? fr / 2 - 1 : -fr / 2 + 1), Math.max(ex * 1.12, ex > 0 ? fr / 2 - 1 : -fr / 2 + 1), spY - 3.5, spY + 3.5, zf + ins, zf + 0.8).subtract(cylZ(SPK.hole / 2, zf - 1, zf + 2, ex, spY, 16)))));
        const basket = box(-fr / 2 + 1.5, fr / 2 - 1.5, spY - fr / 2 + 1.5, spY + fr / 2 - 1.5, zf + 0.79, zf + spDepth * 0.55);
        const can = cylZ(fr * 0.36, zf + spDepth * 0.5, zf + spDepth - ins, 0, spY, 40);
        const dome = cylZ(coneR * 0.45, zf - SPK.dome + ins, zf + 0.81, 0, spY, 32);
        hw.speaker = U([flange, ears, basket, can, dome]);
      }
      // NS4168: board with its holes, PH input on the -x end with the plug, terminal and speaker PH on the +x end
      {
        const z0 = SK.pcbZ0, z1 = SK.pcbZ1, ins = 0.05;
        let pcb = box(xA0, xA1, yA0, yA1, z0 + ins, z1);
        pcb = K(pcb.subtract(U(ampHoles.map(([hx, hy]) => cylZ(AM.holeD / 2, z0 - 1, z1 + 1, hx, hy, 32)))));
        const phIn = box(xA0 - 1.5, xA0 + 5.5, yA0 + 3, yA0 + 19.4, z1, z1 + AM.ph);
        const plugIn = box(xA0 - 8, xA0 - 1.5, yA0 + 5, yA0 + 17.4, z1 + 0.5, z1 + AM.ph - 0.5);
        const term = box(xA1 - 7.5, xA1, yA1 - 9, yA1, z1, z1 + AM.comp);
        const phOut = box(xA1 - 6, xA1 + 1.5, yA0 + 4.8, yA0 + 12.7, z1, z1 + AM.ph);
        const plugOut = box(xA1 + 1.5, xA1 + 8, yA0 + 5.6, yA0 + 11.9, z1 + 0.5, z1 + AM.ph - 0.5);
        const chip = box(xA0 + 20, xA0 + 26, yA0 + 8, yA0 + 14.4, z1, z1 + 1.7);
        const pins = box(xA0 + 0.5, xA0 + 4, yA0 + 4, yA0 + 18.4, z0 - AM.under + 0.6, z0);
        hw.amp = U([pcb, phIn, plugIn, term, phOut, plugOut, chip, pins]);
      }
      if (esp.zc !== null) {
        const B = esp.B, pm = esp.pcbMid, pt = esp.pcbT, sd = esp.side;
        const pcb = box(pm - pt / 2, pm + pt / 2, yb0, yb0 + B.L, esp.zc - B.W / 2, esp.zc + B.W / 2);
        const chip = box(Math.min(pm + sd * pt / 2, pm + sd * (pt / 2 + 1.0)), Math.max(pm + sd * pt / 2, pm + sd * (pt / 2 + 1.0)), yb0 + B.L * 0.35, yb0 + B.L * 0.75, esp.zc - B.W * 0.3, esp.zc + B.W * 0.3);
        const rc = box(Math.min(pm + sd * pt / 2, pm + sd * (pt / 2 + 3.2)), Math.max(pm + sd * pt / 2, pm + sd * (pt / 2 + 3.2)), yb0 - 0.6, yb0 + 7.3, esp.zc - 4.5, esp.zc + 4.5);
        hw.esp = U([pcb, chip, rc]);
      }
      if (usb) hw.usb = U([box(usb[0] - 4.2, usb[0] + 4.2, yb0 - 17, yb0 + 0.6, usb[1] - 3.3, usb[1] + 3.3), cylY(2.0, -T - 30, yb0 - 16, usb[0], usb[1], 16)]);
    }
    mark('hw');

    /* ------------------------------------------------ world placements of the small parts */
    const mirrorX = m => K(m.mirror([1, 0, 0]));
    const smalls = [];   // {name, role, print: Manifold, world: Manifold, kind}
    if (sepNose && nose) smalls.push({ name: 'nose', role: 'nose', world: nose, pose: alignMat(v3.mul(axW, -1), [0, 0, -1]) });
    if (sepEyes) {
      const fit = 0;
      const prism = K(Manifold.extrude(almondCS(eA, eB, -0.0), pocketDepth + 6));
      const sphere = K(Manifold.sphere(eR, 96).translate([0, 0, pocketDepth + eSock - (eR - eProud)]));
      let eye = K(prism.intersect(sphere));                       // print frame: flat back on the bed, dome up
      void fit;
      const place = mat4mul(eyeFr.M, trans([0, 0, -eSock - pocketDepth]));
      const eyeW = K(eye.transform(place));
      smalls.push({ name: 'eye R', role: 'eye', print: eye, world: eyeW });
      smalls.push({ name: 'eye L', role: 'eye', print: mirrorX(eye), world: mirrorX(eyeW) });
    }
    if (antOn && cache.antPrint) {
      const Mw = mat4mul(antFrames[0].M, trans([0, 0, -antInfo.zc]));
      const wR = K(cache.antPrint.transform(Mw));
      smalls.push({ name: 'antler R', role: 'antler', print: cache.antPrint, world: wR, frame: Mw });
      smalls.push({ name: 'antler L', role: 'antler', print: mirrorX(cache.antPrint), world: mirrorX(wR), frame: Mw, mirror: true });
    }
    if (earOn && cache.earPrint) {
      // print frame (x = u, y = w, z = v + depth) -> ear frame (u, v, w)
      const P2E = [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, -earDepth, -earB, 1];
      const Mw = mat4mul(earFrames[0].M, P2E);
      const wR = K(cache.earPrint.transform(Mw));
      smalls.push({ name: 'ear R', role: 'body', print: cache.earPrint, world: wR, frame: Mw });
      smalls.push({ name: 'ear L', role: 'body', print: mirrorX(cache.earPrint), world: mirrorX(wR), frame: Mw, mirror: true });
    }
    smalls.push({ name: 'pivot pin', role: 'pin', print: pinPrint, world: K(pinPrint.transform(pinPlace)) });
    if (hookPrint) for (let i = 0; i < hookPlaces.length; i++) smalls.push({ name: 'hook ' + (i ? 'R' : 'L'), role: 'pin', print: hookPrint, world: K(hookPrint.transform(hookPlaces[i])) });

    /* ------------------------------------------------ checks */
    const checks = [];
    const H3 = [0, H[1], H[2]];
    const near3 = (m, ref, pad) => { const b = ref.boundingBox(); return K(m.intersect(box(b.min[0] - pad, b.max[0] + pad, b.min[1] - pad, b.max[1] + pad, b.min[2] - pad, b.max[2] + pad))); };
    const rotJ = (m, deg) => K(m.translate([0, -H3[1], -H3[2]]).rotate([-deg, 0, 0]).translate([0, H3[1], H3[2]]));
    const pinW = smalls.find(s => s.name === 'pivot pin').world;
    {
      const R0 = 38, hb0 = box(-70, 70, H[1] - R0, H[1] + R0, H[2] - R0, H[2] + R0);
      const near = K(shell.intersect(hb0));
      const fixedNear = K(U([mount, servoW]).intersect(hb0));
      const jawNear = K(jawW.intersect(box(-70, 70, H[1] - R0 + 8, H[1] + R0 - 8, H[2] - R0 + 8, H[2] + R0 - 8)));
      for (const f of [0, 0.5, 1]) {
        const deg = st.jaw.open * f, jr = rotJ(jawNear, deg);
        const v = hit(jr, near) + hit(jr, fixedNear) + hit(jr, pinW);
        checks.push({ k: 'jaw at ' + deg.toFixed(0) + ' deg clears head, fin, servo and pin', v, ok: v < 0.5, group: 'jaw' });
      }
      { const v = hit(hornW, jawW); checks.push({ k: 'servo horn sits in the jaw groove', v, ok: v < 0.3, group: 'jaw' }); }
      { const v = hit(servoW, near); checks.push({ k: 'servo clear of the head', v, ok: v < 0.3, group: 'jaw' }); }
      let bad = 0;
      const inW = lwv([0, ins[0], ins[1]]);
      for (const sd of [1.5, 4, 8, 14, 22]) { const jt = K(jawNear.translate(v3.mul(inW, -sd))); bad = Math.max(bad, hit(jt, near), hit(jt, fixedNear), hit(jt, hornW)); }
      checks.push({ k: 'jaw slides up through the mouth onto the horn', v: bad, ok: bad < 0.5, group: 'jaw' });
      // pivot pin: passes the cheek pad and the arm bore, tip clears the servo
      const pinVsHead = hit(pinW, near3(shell, pinW, 1)), pinVsJaw = hit(pinW, near3(jawW, pinW, 1)), pinVsServo = hit(pinW, servoW);
      checks.push({ k: 'pivot pin: snug in the cheek, free in the jaw arm, clear of the servo', v: pinVsJaw + pinVsServo + Math.max(0, pinVsHead - 0.5), ok: pinVsJaw < 0.2 && pinVsServo < 0.05 && pinVsHead < 0.5, group: 'jaw' });
      // and the barb actually catches behind the arm
      checks.push({ k: 'pin barb reaches ' + pinBarb.toFixed(1) + ' mm past the arm, ' + (servoBot - (-a + tL + pinBarb)).toFixed(1) + ' mm short of the servo', v: 0, ok: servoBot - (-a + tL + pinBarb) > 0.4, group: 'jaw' });
    }
    // hollow jaw: the void keeps its wall everywhere (sampled on the void surface against the sculpt field)
    if (jawVoid) {
      const vm = jawVoid.getMesh(), np = vm.numProp, nv = vm.vertProperties.length / np;
      let thin = 1e9; for (let i = 0; i < nv; i += 3) { const x = vm.vertProperties[i * np], y = vm.vertProperties[i * np + 1], z = vm.vertProperties[i * np + 2]; thin = Math.min(thin, -d(x, y, z)); }
      const jw = Math.max(1.6, st.jaw.wall), saved = jawRemoved;
      checks.push({ k: 'jaw ' + (jawOpen ? 'channelled through the mouth' : 'hollowed inside') + ': ' + (saved / 1000).toFixed(1) + ' of ' + (jawSolidVol / 1000).toFixed(1) + ' cm3 taken out, skin wall ' + thin.toFixed(1) + ' mm or more', v: Math.max(0, jw - 0.35 - thin), ok: thin > jw - 0.35, group: 'jaw' });
    }
    // eyes: pocket stays inside its boss, does not break into the cavity
    if (sepEyes) {
      const brk = hit(eyePocketW, near3(cavity, eyePocketW, 1));
      checks.push({ k: 'eye pockets are blind (wall behind them)', v: brk, ok: brk < 0.05, group: 'parts' });
      const eW = smalls.find(s => s.name === 'eye R').world;
      const ev = hit(eW, near3(shell, eW, 1));
      checks.push({ k: 'eyes press in with ' + st.eyes.fit.toFixed(2) + ' mm design clearance', v: ev, ok: ev < 0.3, group: 'parts' });
    }
    if (sepNose && nose) {
      const sockWall = hit(K(sockM.translate([0, 0, 0])), headCut);
      const pegIn = 0;
      const nv = hit(nose, near3(shell, nose, 1));
      checks.push({ k: 'nose cap keys onto the muzzle peg', v: nv, ok: nv < 0.3 && pegIn < 0.5, group: 'parts' });
      void sockWall;
    }
    for (const s2 of smalls.filter(s => s.role === 'antler' || s.name.startsWith('ear'))) {
      if (s2.mirror) continue;
      const v = hit(s2.world, near3(shell, s2.world, 1));
      checks.push({ k: s2.name.split(' ')[0] + ' tenon fits its socket (' + MORT.toFixed(2) + ' mm per side)', v, ok: v < 0.4, group: 'parts' });
    }
    // snap: the head's bead must ride over the lip's bead
    if (screwPts) {
      // each screw: clear hole through the plaque, 2.5 mm pilot into a boss on the head, nothing else in the way
      const si = screwInfo;
      const screws = U(screwPts.map(([x, z]) => cylY(1.5, -T, si.bossL - 2.5, x, z, 16)));
      let v = hit(screws, K(U([spine, tray, ampShelf, plinth]))) + hit(screws, U(Object.values(hw).filter(Boolean)));
      if (hooks) for (const [, z] of screwPts) if (Math.abs(z - hookZ) < hooks.w1 / 2 + si.sinkR + 0.6) v += 1;
      let wall = 1e9; for (const [x, z] of screwPts) for (let k = 0; k < 16; k++) { const an = k / 16 * 2 * Math.PI; for (const y of [2, 6, 10]) { const px = x + Math.cos(an) * (si.pilotR + 1.2), pz = z + Math.sin(an) * (si.pilotR + 1.2); wall = Math.min(wall, -d(px, y, pz)); } }
      checks.push({ k: 'head held by 3 x M3 x 16 flat head screws from the back of the plaque into bosses in the neck rim', v, ok: v < 0.05, group: 'mount' });
      checks.push({ k: 'screw bosses have at least 1.2 mm of plastic round each pilot', v: Math.max(0, -wall), ok: wall > 0, group: 'mount' });
    } else {
      const snapOver = st.mount.snap;
      checks.push({ k: 'head snaps on: ' + snapOver.toFixed(2) + ' mm bead overlap on each flank', v: 0, ok: snapOver >= 0.3 && snapOver <= 1.2, group: 'mount' });
    }
    // electronics: each part sits on its seat without overlap, and goes in along the path the instructions give
    {
      // path: lift off the seat, back away from the plaque past the locating lip, then out sideways
      const sweepHit = (m, lift, dist, target) => {
        const b0 = m.boundingBox(), dy = Math.max(0, lipClearY - b0.min[1]);
        const T2 = K(target.intersect(box(b0.min[0] - 1, b0.max[0] + dist + 1, b0.min[1] - 1, b0.max[1] + dy + 1, b0.min[2] - 1, b0.max[2] + lift + 1)));
        if (T2.isEmpty()) return 0;
        const poses = [];
        for (let t = 0; t <= lift + 0.001; t += 0.25) poses.push([0, 0, t]);
        for (let t = 0.5; t <= dy + 0.001; t += 0.5) poses.push([0, t, lift]);
        for (let t = 1; t <= dist + 0.001; t += 2) poses.push([t, dy, lift]);
        let worst = 0; for (const p of poses) worst = Math.max(worst, hit(K(m.translate(p)), T2));
        return worst;
      };
      const vS = hit(hw.speaker, mount);
      checks.push({ k: 'speaker sits on its seat ring, ears on the screw bosses (' + span.toFixed(1) + ' mm span)', v: vS, ok: vS < 0.3, group: 'guts' });
      const spBody = K(hw.speaker.subtract(box(-BIG, BIG, -BIG, BIG, -BIG, seatTop + 0.1)));
      const vSi = sweepHit(spBody, SPK.dome + 0.2, 45, mount);
      checks.push({ k: 'speaker slides in from the side, lifted ' + (SPK.dome + 0.2).toFixed(1) + ' mm over the seat ring', v: vSi, ok: vSi < 0.3, group: 'guts' });
      const vA = hit(hw.amp, mount);
      checks.push({ k: 'NS4168 sits on its two posts, spigots in its 4.7 mm holes', v: vA, ok: vA < 0.3, group: 'guts' });
      const ampBoard = K(hw.amp.intersect(box(xA0 - 0.01, xA1 + 0.01, -BIG, BIG, SK.pcbZ0 - 0.01, BIG)));
      const vAi = sweepHit(ampBoard, 1.5, 40, mount);
      checks.push({ k: 'NS4168 slides in from the side, lifted 1.5 mm over the spigots', v: vAi, ok: vAi < 0.3, group: 'guts' });
      // a screwdriver goes straight down onto every screw: speaker ears before the amp, amp before the controller
      const driver = (x, y, z0) => cylZ(1.7, z0, z0 + 60, x, y, 16);
      const vDs = hit(U(earXs.map(ex => driver(ex, spY, seatTop + 0.8))), mount);
      checks.push({ k: 'screwdriver reaches both speaker ear screws through the shelf', v: vDs, ok: vDs < 0.05, group: 'guts' });
      const vDa = hit(U(ampHoles.map(([hx, hy]) => driver(hx, hy, SK.pcbZ1 + 0.1))), mount);
      checks.push({ k: 'screwdriver reaches both amp screws past the fin and plinth', v: vDa, ok: vDa < 0.05, group: 'guts' });
      const vSA = hit(hw.speaker, hw.amp) + hit(hw.speaker, ampShelf);
      checks.push({ k: 'speaker clear of the amp shelf (' + (SK.shZ0 - SK.sTop).toFixed(1) + ' mm over its back)', v: vSA, ok: vSA < 0.05, group: 'guts' });
      if (hw.esp) {
        const vE = hit(hw.esp, mount) + hit(hw.esp, servoW) + hit(hw.esp, hw.amp) + (hw.usb ? hit(hw.usb, hw.amp) + hit(hw.usb, mount) : 0);
        checks.push({ k: 'controller on its plinth, pins open, clear of the servo, the amp and the USB plug path', v: vE, ok: vE < 0.3, group: 'guts' });
      }
    }
    mark('checks');

    /* ------------------------------------------------ print poses */
    const rimDown = rotX(90);
    const mouthNW = v3.norm(lwv([0, mNup[0], mNup[1]]));
    const jawPose = alignMat(mouthNW, [0, 0, -1]);
    const mountPose = mat4mul(trans([0, 0, T]), rotX(90));
    const objects = [];
    objects.push({ name: 'head', role: 'body', world: shell, pose: rimDown });
    objects.push({ name: 'jaw', role: 'body', world: jawW, pose: jawPose });
    objects.push({ name: 'mount', role: 'plaque', world: mount, pose: mountPose });
    // explode directions, mounted frame
    const exOf = s2 => {
      const n = s2.name;
      if (n === 'nose') return v3.mul(axW, 26);
      if (n.startsWith('eye')) { const N = eyeFr.N; return v3.mul([n.endsWith('L') ? -N[0] : N[0], N[1], N[2]], 22); }
      if (n.startsWith('antler')) { const V = [s2.frame[4], s2.frame[5], s2.frame[6]]; return v3.mul([n.endsWith('L') ? -V[0] : V[0], V[1], V[2]], 34); }
      if (n.startsWith('ear')) { const V = [s2.frame[4], s2.frame[5], s2.frame[6]]; return v3.mul([n.endsWith('L') ? -V[0] : V[0], V[1], V[2]], 30); }
      if (n === 'pivot pin') return [-40, 0, 0];
      if (n.startsWith('hook')) return [0, -30, 0];
      return [0, 0, 0];
    };
    for (const s2 of smalls) { s2.ex = exOf(s2); objects.push(s2); }
    objects[0].ex = [0, 75, 10]; objects[1].ex = [0, 70, -60];

    function meshOf(m, mat) {
      const mm = K((mat ? K(m.transform(mat)) : m).simplify(0.001));
      const me = mm.getMesh(), np = me.numProp, nv = me.vertProperties.length / np;
      const pos = new Float64Array(nv * 3), q = v => Math.round(v * 1e5) / 1e5;     // quantise to the 3MF's precision first
      for (let i = 0; i < nv; i++) { pos[i * 3] = q(me.vertProperties[i * np]); pos[i * 3 + 1] = q(me.vertProperties[i * np + 1]); pos[i * 3 + 2] = q(me.vertProperties[i * np + 2]); }
      const cl = cleanMesh(pos, me.triVerts);
      return { positions: cl.positions, indices: cl.indices, tris: cl.indices.length / 3, volume: mm.volume() };
    }
    const out = { objects: [], hardware: {}, checks, notes, warns, errs, info: {} };
    for (const o of objects) {
      if (!o.world || o.world.isEmpty()) continue;
      const world = meshOf(o.world);
      let print;
      if (o.print) print = meshOf(o.print);
      else { const P = world.positions, Q = new Float32Array(P.length); for (let i = 0; i < P.length; i += 3) { const q = mat4apply(o.pose, [P[i], P[i + 1], P[i + 2]]); Q[i] = q[0]; Q[i + 1] = q[1]; Q[i + 2] = q[2]; } print = { positions: Q, indices: world.indices.slice(), tris: world.tris, volume: world.volume }; }
      // normalise print pose: on the bed, centred
      const a2 = print.positions; let mn = [1e9, 1e9, 1e9], mx = [-1e9, -1e9, -1e9];
      for (let i = 0; i < a2.length; i += 3) for (let c = 0; c < 3; c++) { mn[c] = Math.min(mn[c], a2[i + c]); mx[c] = Math.max(mx[c], a2[i + c]); }
      for (let i = 0; i < a2.length; i += 3) { a2[i] -= (mn[0] + mx[0]) / 2; a2[i + 1] -= (mn[1] + mx[1]) / 2; a2[i + 2] -= mn[2]; }
      const O = { name: o.name, role: o.role, slot: st.roles[o.role] || 1, world, print, size: [mx[0] - mn[0], mx[1] - mn[1], mx[2] - mn[2]], frame: o.frame, mirror: !!o.mirror, ex: o.ex || [0, 0, 0] };
      out.objects.push(O);
    }
    for (const k in hw) if (hw[k]) out.hardware[k] = meshOf(hw[k]);
    mark('meshes');

    /* slide-on audit: raster the head's first surface along +y against the tallest point of everything fixed to the
     * plaque. The snap beads are left out (they are meant to overlap, by the snap setting). */
    {
      const headM = meshOf(shellNoBead);
      const res = 0.4, gx0 = bnd.min[0] - 5, gz0 = bnd.min[2] - 5, nx = Math.ceil((bnd.max[0] - bnd.min[0] + 10) / res), nz = Math.ceil((bnd.max[2] - bnd.min[2] + 10) / res);
      const yMin = new Float32Array(nx * nz).fill(1e9), yMax = new Float32Array(nx * nz).fill(-1e9), who = new Int16Array(nx * nz).fill(-1);
      function raster(mesh, arr, mode, id) {
        const P = mesh.positions, I = mesh.indices;
        for (let t = 0; t < I.length; t += 3) {
          const ia = I[t] * 3, ib = I[t + 1] * 3, ic = I[t + 2] * 3;
          const ax = P[ia], ay = P[ia + 1], az = P[ia + 2], bx = P[ib], by = P[ib + 1], bz = P[ib + 2], cx = P[ic], cy = P[ic + 1], cz = P[ic + 2];
          const den = (bz - cz) * (ax - cx) + (cx - bx) * (az - cz); if (Math.abs(den) < 1e-12) continue;
          const i0 = Math.max(0, Math.floor((Math.min(ax, bx, cx) - gx0) / res)), i1 = Math.min(nx - 1, Math.ceil((Math.max(ax, bx, cx) - gx0) / res));
          const k0 = Math.max(0, Math.floor((Math.min(az, bz, cz) - gz0) / res)), k1 = Math.min(nz - 1, Math.ceil((Math.max(az, bz, cz) - gz0) / res));
          for (let i = i0; i <= i1; i++) { const px = gx0 + (i + 0.5) * res;
            for (let k = k0; k <= k1; k++) { const pz = gz0 + (k + 0.5) * res;
              const l1 = ((bz - cz) * (px - cx) + (cx - bx) * (pz - cz)) / den, l2 = ((cz - az) * (px - cx) + (ax - cx) * (pz - cz)) / den, l3 = 1 - l1 - l2;
              if (l1 < -1e-6 || l2 < -1e-6 || l3 < -1e-6) continue;
              const y = l1 * ay + l2 * by + l3 * cy, q = i * nz + k;
              if (mode < 0) { if (y < arr[q]) arr[q] = y; } else if (y > arr[q]) { arr[q] = y; who[q] = id; }
            } }
        }
      }
      raster(headM, yMin, -1);
      const fixedNames = [];
      const fx = (m, nm) => { fixedNames.push(nm); raster(m, yMax, 1, fixedNames.length - 1); };
      const beadZone = K(K(K(xzExtrude(lipInfo.sides, lipInfo.yc - 2, lipInfo.yc + 2)).intersect(xzExtrude(K(lipInfo.lipOut.offset(2, 'Round')), -1, 60))).subtract(xzExtrude(lipInfo.lipOut, -2, 61)));
      const mountNoBead = meshOf(K(mount.subtract(beadZone)));
      fx(mountNoBead, 'mount');
      for (const k of ['servo', 'esp', 'amp', 'speaker']) if (out.hardware[k]) fx(out.hardware[k], k);
      let worst = 0, wq = -1; const by = {};
      for (let q = 0; q < nx * nz; q++) {
        if (yMax[q] <= 0.05 || yMin[q] > 1e8) continue;
        const over = yMax[q] - yMin[q];
        if (over > 0.05) { const nm = fixedNames[who[q]]; by[nm] = Math.max(by[nm] || 0, over); if (over > worst) { worst = over; wq = q; } }
      }
      const at = wq >= 0 ? [gx0 + (Math.floor(wq / nz) + 0.5) * res, gz0 + (wq % nz + 0.5) * res] : null;
      checks.push({ k: 'head slides straight onto the mount', v: worst, ok: worst < 0.05, by, at, unit: 'mm', group: 'mount' });
      if (worst >= 0.05) warns.push('head hits ' + Object.keys(by).join(', ') + ' while sliding on (' + worst.toFixed(1) + ' mm)');
    }
    /* pegboard hook insertion: rotate the hook and plaque in through the hole, in the hook's centre plane */
    if (hooks) {
      const r = hookInsert(hooks.prof, PEG);
      checks.push({ k: 'hooks hold: a straight pull cannot draw them out', v: 0, ok: r.hold !== false, group: 'mount' });
      checks.push({ k: 'hooks roll into ' + PEG.name + ' (' + PEG.hole.toFixed(2) + ' mm holes, ' + PEG.board.toFixed(1) + ' mm board)', v: r.v, ok: r.ok, group: 'mount' });
      checks.push({ k: 'hook shank ' + PEG.shank.toFixed(1) + ' mm octagon, ' + octD(PEG).toFixed(2) + ' mm across corners', v: 0, ok: octD(PEG) < PEG.hole - 0.4, group: 'mount' });
    }
    for (const c of checks) if (!c.ok && c.unit !== 'mm') warns.push(c.k + ': ' + c.v.toFixed(2) + ' mm3');
    function octD(P) { const h = P.shank / 2; return 2 * Math.hypot(h, h - P.cham); }
    function hookInsert(prof, P) {
      // breadth first search over (angle, y, z) poses of a lone hook, from seated to clear of the board.
      // Board in the hook frame: y in [-tb, 0], solid where |z| > hole/2 (the hook's centre plane).
      const key = JSON.stringify([P, prof.area()]);
      if (cache.hookKey === key) return cache.hookRes;
      let hold = true;
      const polys = prof.toPolygons(), pts = [];
      for (const poly of polys) for (let i = 0; i < poly.length; i++) { const A = poly[i], B2 = poly[(i + 1) % poly.length]; const n = Math.max(1, Math.ceil(Math.hypot(B2[0] - A[0], B2[1] - A[1]) / 0.35)); for (let k = 0; k < n; k++) pts.push([A[0] + (B2[0] - A[0]) * k / n, A[1] + (B2[1] - A[1]) * k / n]); }
      const tb = P.board, hr = P.hole / 2 - 0.15;          // a little margin for the octagon corners
      const AS = 2, A0 = -120, NA = 121, RS = 0.25, Y0 = -16, NY = 184, Z0 = -16, NZ = 128;
      const seen = new Uint8Array(NA * NY * NZ);
      const idx = (a, y, z) => (a * NY + y) * NZ + z;
      const free = (ai, yi, zi) => {
        const th = (A0 + ai * AS) * D2R, c = Math.cos(th), s = Math.sin(th), ty = Y0 + yi * RS, tz = Z0 + zi * RS;
        for (let k = 0; k < pts.length; k++) { const y = pts[k][0], z = pts[k][1]; const Y = y * c - z * s + ty; if (Y < -0.02 && Y > -tb + 0.02) { const Z = y * s + z * c + tz; if (Math.abs(Z) > hr) return false; } }
        return true;
      };
      const out = (ai, yi, zi) => { const th = (A0 + ai * AS) * D2R, c = Math.cos(th), s = Math.sin(th), ty = Y0 + yi * RS; for (let k = 0; k < pts.length; k += 3) if (pts[k][0] * c - pts[k][1] * s + ty < 0.3) return false; return true; };
      const a0 = Math.round(-A0 / AS), y0 = Math.round(-Y0 / RS), z0 = Math.round(-Z0 / RS);
      let res = { ok: false, v: 1, states: 0 };
      // straight pull from seated: with no rotation the prong must jam before it clears the board
      { let yi = y0; while (yi < NY - 1 && free(a0, yi + 1, z0)) yi++; if (out(a0, yi, z0)) hold = false; }
      if (free(a0, y0, z0)) {
        const q = [idx(a0, y0, z0)]; seen[q[0]] = 1; let h = 0;
        while (h < q.length && h < 600000) {
          const id = q[h++], zi = id % NZ, yi = ((id - zi) / NZ) % NY, ai = Math.floor(id / (NY * NZ));
          if (out(ai, yi, zi)) { res = { ok: true, v: 0, states: h, angle: A0 + ai * AS }; break; }
          for (const [da, dy, dz] of [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]]) {
            const na = ai + da, ny = yi + dy, nz = zi + dz;
            if (na < 0 || na >= NA || ny < 0 || ny >= NY || nz < 0 || nz >= NZ) continue;
            const ni = idx(na, ny, nz); if (seen[ni]) continue; seen[ni] = 1;
            if (free(na, ny, nz)) q.push(ni);
          }
        }
        if (!res.ok) res = { ok: false, v: 1, states: q.length };
      }
      res.hold = hold;
      cache.hookKey = key; cache.hookRes = res;
      return res;
    }
    /* ------------------------------------------------ paint guide colours per vertex */
    const paintOf = (O) => {
      const P = O.world.positions, n = P.length / 3, col = new Float32Array(n * 3);
      const set = (i, c) => { col[i * 3] = c[0]; col[i * 3 + 1] = c[1]; col[i * 3 + 2] = c[2]; };
      if (O.name === 'head' || O.name === 'jaw') {
        // jaw faces that lie on the mouth plane read as the inside of the mouth
        for (let i = 0; i < n; i++) {
          const x = P[i * 3], y = P[i * 3 + 1], z = P[i * 3 + 2];
          let mouthFace = false;
          const ql = mat4apply(mat4inv(L2Wm), [x, y, z]);
          const sd = (ql[1] - mouth0[0]) * mNup[0] + (ql[2] - mouth0[1]) * mNup[1];
          if (O.name === 'jaw' && sd > -0.25 && d(x, y, z) < -0.3) mouthFace = true;
          if (O.name === 'jaw' && jawOpen && d(x, y, z) < -1.2) mouthFace = true;   // the channel's walls and floor read as inside the mouth
          if (O.name === 'head' && sd < g + 0.3 && sd > -0.5 && d(x, y, z) < -0.3) mouthFace = true;
          set(i, BUCKSDF.paintHead(HD, x, y, z, mouthFace));
        }
      } else if (O.name === 'nose') { for (let i = 0; i < n; i++) set(i, BUCKSDF.PAL.black); }
      else if (O.name.startsWith('eye')) { for (let i = 0; i < n; i++) set(i, [0.05, 0.04, 0.035]); }
      else if (O.name.startsWith('antler')) {
        const inv = mat4inv(O.frame);
        for (let i = 0; i < n; i++) { let p = [P[i * 3], P[i * 3 + 1], P[i * 3 + 2]]; if (O.mirror) p[0] = -p[0]; const q = mat4apply(inv, p); set(i, BUCKSDF.paintAntler(Math.max(0, q[1]) / antInfo.tip)); }
      } else if (O.name.startsWith('ear')) {
        const inv = mat4inv(O.frame), ef = cache.earField;
        for (let i = 0; i < n; i++) { let p = [P[i * 3], P[i * 3 + 1], P[i * 3 + 2]]; if (O.mirror) p[0] = -p[0]; const q = mat4apply(inv, p); const u = q[0], v = q[1] - earDepth, w = q[2] - earB; const front = w > ef.wc(u, v); set(i, BUCKSDF.paintEar(u, v, w, ef.halfW(v), Le, front && v > 1)); }
      } else return null;
      return col;
    };
    for (const O of out.objects) O.paint = paintOf(O);

    out.info = {
      hinge: H, a, xs, aMin, trayZ, esp: esp.zc, stack: SK, spY, usb, tilt, S, open: st.jaw.open,
      plaque: { w: ob.max[0] - ob.min[0], h: ob.max[1] - ob.min[1], t: T }, hookZ, pitch, hookMode, peg: PEG,
      ms: 0, insW: lwv([0, ins[0], ins[1]]), pinLen: (-a + tL + pinBarb) - (-xSkinL + 0.2),
      hornScrew: SV.headH, mouth: { mNup, mouth0 }
    };
    for (const m of track) { try { if (m && m.delete) m.delete(); } catch (e) { } }
    mark('paint'); out.info.ms = Date.now() - T0; out.info.tm = TM;
    return out;
  }

  /* ---------------------------------------------------------------- plate packing
   * Raster nesting on the real footprints (the shadow of each part on the bed), not bounding boxes, so small
   * parts tuck into the corners beside the shield's point and between antler tines. Bottom left first fit,
   * eight rotations, largest part first. */
  function pack(objs, bw, bd, opt) {
    opt = opt || {};
    const cell = opt.cell || 1, gap = opt.gap == null ? 4 : opt.gap, m = opt.margin == null ? 5 : opt.margin;
    const angles = opt.angles || [0, 90, 180, 270, 45, 135, 225, 315];
    const W = Math.floor(bw / cell), Hc = Math.floor(bd / cell), rad = Math.max(0, Math.round(gap / 2 / cell));
    const cache = new Map();
    function raster(O, a) {
      const key = O.name + '@' + a; if (cache.has(key)) return cache.get(key);
      const P = O.print.positions, I = O.print.indices, c = Math.cos(a * D2R), s = Math.sin(a * D2R), n = P.length / 3;
      const X = new Float32Array(n), Y = new Float32Array(n);
      let x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9;
      for (let i = 0; i < n; i++) { const x = P[i * 3] * c - P[i * 3 + 1] * s, y = P[i * 3] * s + P[i * 3 + 1] * c; X[i] = x; Y[i] = y; if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y; }
      const pad = rad + 1, w = Math.ceil((x1 - x0) / cell) + 2 * pad + 1, h = Math.ceil((y1 - y0) / cell) + 2 * pad + 1;
      const g = new Uint8Array(w * h), gx = x => (x - x0) / cell + pad, gy = y => (y - y0) / cell + pad;
      for (let t = 0; t < I.length; t += 3) {
        const ax = gx(X[I[t]]), ay = gy(Y[I[t]]), bx = gx(X[I[t + 1]]), by = gy(Y[I[t + 1]]), cx = gx(X[I[t + 2]]), cy = gy(Y[I[t + 2]]);
        g[Math.floor(ay) * w + Math.floor(ax)] = 1;
        const den = (by - cy) * (ax - cx) + (cx - bx) * (ay - cy); if (Math.abs(den) < 1e-9) continue;
        const i0 = Math.floor(Math.min(ax, bx, cx)), i1 = Math.ceil(Math.max(ax, bx, cx)), j0 = Math.floor(Math.min(ay, by, cy)), j1 = Math.ceil(Math.max(ay, by, cy));
        for (let j = j0; j <= j1; j++) for (let i = i0; i <= i1; i++) {
          const px = i + 0.5, py = j + 0.5;
          const l1 = ((by - cy) * (px - cx) + (cx - bx) * (py - cy)) / den, l2 = ((cy - ay) * (px - cx) + (ax - cx) * (py - cy)) / den;
          if (l1 >= -0.02 && l2 >= -0.02 && l1 + l2 <= 1.02) g[j * w + i] = 1;
        }
      }
      // dilate by half the gap so two footprints placed edge to edge end up a full gap apart
      let d = g;
      if (rad > 0) { d = new Uint8Array(w * h); for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) if (g[j * w + i]) for (let dj = -rad; dj <= rad; dj++) for (let di = -rad; di <= rad; di++) { if (di * di + dj * dj > rad * rad + rad) continue; const jj = j + dj, ii = i + di; if (jj >= 0 && jj < h && ii >= 0 && ii < w) d[jj * w + ii] = 1; } }
      const spans = []; let area = 0;
      for (let j = 0; j < h; j++) { const row = []; let st = -1; for (let i = 0; i <= w; i++) { const v = i < w && d[j * w + i]; if (v && st < 0) st = i; if (!v && st >= 0) { row.push([st, i - 1]); area += i - st; st = -1; } } spans.push(row); }
      const r = { w, h, spans, area, ox: -x0 / cell + pad, oy: -y0 / cell + pad, inner: (x1 - x0) * (y1 - y0) };
      cache.set(key, r); return r;
    }
    const plates = [];
    const newPlate = () => {
      const occ = new Uint8Array(W * Hc), b = Math.max(0, Math.round((m - gap / 2) / cell));
      for (let j = 0; j < Hc; j++) for (let i = 0; i < W; i++) if (i < b || j < b || i >= W - b || j >= Hc - b) occ[j * W + i] = 1;
      const pre = new Int32Array(Hc * (W + 1));
      const pl = { items: [], occ, pre, rows: j => { let sum = 0; pre[j * (W + 1)] = 0; for (let i = 0; i < W; i++) { sum += occ[j * W + i]; pre[j * (W + 1) + i + 1] = sum; } } };
      for (let j = 0; j < Hc; j++) pl.rows(j);
      return pl;
    };
    const fits = (pl, r, px, py) => {
      for (let j = 0; j < r.h; j++) { const row = r.spans[j], base = (py + j) * (W + 1); for (let k = 0; k < row.length; k++) { const a0 = row[k][0] + px, a1 = row[k][1] + px; if (pl.pre[base + a1 + 1] - pl.pre[base + a0] > 0) return false; } }
      return true;
    };
    const place = (pl, O) => {
      let best = null;
      for (const a of angles) {
        const r = raster(O, a); if (r.w > W || r.h > Hc) continue;
        let found = null;
        for (let py = 0; py <= Hc - r.h && !found; py++) { if (best && py > best.py) break; for (let px = 0; px <= W - r.w; px++) if (fits(pl, r, px, py)) { found = { px, py }; break; } }
        if (found && (!best || found.py < best.py || (found.py === best.py && found.px < best.px))) best = { a, r, px: found.px, py: found.py };
      }
      if (!best) return false;
      const r = best.r;
      for (let j = 0; j < r.h; j++) { for (const [a0, a1] of r.spans[j]) for (let i = a0; i <= a1; i++) pl.occ[(best.py + j) * W + best.px + i] = 1; pl.rows(best.py + j); }
      pl.items.push({ obj: O, x: (best.px + r.ox) * cell, y: (best.py + r.oy) * cell, rot: best.a });
      return true;
    };
    const order = objs.slice().sort((A, B) => raster(B, 0).area - raster(A, 0).area);
    for (const O of order) {
      let ok = false; for (const pl of plates) if (place(pl, O)) { ok = true; break; }
      if (!ok) { const pl = newPlate(); plates.push(pl); if (!place(pl, O)) pl.items.push({ obj: O, x: bw / 2, y: bd / 2, rot: 0, over: true }); }
    }
    return plates.map(pl => ({ items: pl.items }));
  }

  root.BUCK = { HW, defaults, build, pack, v3, alignMat };
})(typeof globalThis !== 'undefined' ? globalThis : this);
