#!/usr/bin/env python3
"""Assemble BUCK bench: buck.html (full document, runs from file://) and buck-artifact.html (page body for publishing)."""
import base64, os, re, sys
H = os.path.dirname(os.path.abspath(__file__))
nm = os.path.join(H, 'node_modules')
rd = lambda p: open(p, encoding='utf-8').read()
shell = rd(os.path.join(H, 'src/shell.html'))
fonts = [("Permanent Marker", "permanent-marker", "permanent-marker-latin-400-normal.woff2", 400), ("Special Elite", "special-elite", "special-elite-latin-400-normal.woff2", 400),
         ("VT323", "vt323", "vt323-latin-400-normal.woff2", 400), ("IBM Plex Mono", "ibm-plex-mono", "ibm-plex-mono-latin-400-normal.woff2", 400), ("IBM Plex Mono", "ibm-plex-mono", "ibm-plex-mono-latin-600-normal.woff2", 600)]
css = "".join("@font-face{font-family:'%s';font-style:normal;font-weight:%d;font-display:block;src:url(data:font/woff2;base64,%s) format('woff2')}\n" % (f, w, base64.b64encode(open(os.path.join(nm, '@fontsource', pk, 'files', fn), 'rb').read()).decode()) for f, pk, fn, w in fonts)
shell = shell.replace('<style>', '<style>\n' + css, 1)
head, body = shell.split('</style>', 1)
head += '</style>'
wasm = base64.b64encode(open(os.path.join(nm, 'manifold-3d/manifold.wasm'), 'rb').read()).decode()
mc = rd(os.path.join(nm, 'manifold-3d/manifold.js')).replace('import.meta.url', '"file:///manifold.js"').replace('export default Module;', 'globalThis.ManifoldModule=Module;')
scripts = [('three r128', rd(os.path.join(nm, 'three/build/three.min.js'))), ('jszip 3.10.1', rd(os.path.join(nm, 'jszip/dist/jszip.min.js'))),
           ('manifold-3d 3.5.4 (Apache-2.0), classic script', mc), ('manifold wasm', 'globalThis.BUCK_WASM_B64="' + wasm + '";'),
           ('orca3mf.js (print-forge)', rd('/mnt/skills/plugins/print-forge/assets/orca3mf.js')), ('sdf.js', rd(os.path.join(H, 'src/sdf.js'))),
           ('engine.js', rd(os.path.join(H, 'src/engine.js'))), ('app.js', rd(os.path.join(H, 'src/app.js')))]
sc = "\n".join("<script>/* %s */\n%s\n</script>" % (n, s.replace('</script', '<\\/script')) for n, s in scripts)
os.makedirs(os.path.join(H, 'out'), exist_ok=True)
full = '<!DOCTYPE html>\n<html lang="en">\n<head>\n<meta charset="utf-8">\n<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">\n' + head + '\n</head>\n<body>' + body + sc + '\n</body>\n</html>\n'
open(os.path.join(H, 'out/buck.html'), 'w', encoding='utf-8').write(full)
open(os.path.join(H, 'out/buck-artifact.html'), 'w', encoding='utf-8').write(head + '\n' + body + sc + '\n')
print('buck.html', len(full) // 1024, 'KB')
